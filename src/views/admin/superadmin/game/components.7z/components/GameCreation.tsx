import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Avatar,
  Box,
  Button,
  Divider,
  Flex,
  Grid,
  GridItem,
  Icon,
  Img,
  Input,
  List,
  ListIcon,
  ListItem,
  Progress,
  SimpleGrid,
  Step,
  StepIcon,
  StepIndicator,
  StepNumber,
  StepSeparator,
  StepStatus,
  StepTitle,
  Stepper,
  Text,
  VStack,
  useSteps,
  keyframes,
  useToast,
  Heading,
  Collapse,
  StepDescription,
  useColorModeValue,
  HStack,
  useDisclosure,
} from '@chakra-ui/react';
import { MdOutlineSubtitles } from 'react-icons/md';
import React, { useEffect, useRef, useState } from 'react';
import CharacterPreview from './CharacterPreview';
import { motion } from 'framer-motion';
import { VscVerifiedFilled } from 'react-icons/vsc';
import { GoVerified, GoUnverified, GoDotFill } from 'react-icons/go';
import Card from 'components/card/Card';
import InputField from 'components/fields/InputField';
import TextField from 'components/fields/TextField';
import Log from 'assets/img/games/log.png';
import Level from 'assets/img/games/new-level-final.png';
import Character from 'assets/img/games/select-character-final.png';
import Badges from 'assets/img/games/badges-game-read-format.png';
import GameCard from './gameCard';
import {
  getImages,
  getNonPlayer,
  getPlayer,
  updateGame,
  getGameById,
  addgame,
  createSkills,
  createCategories,
  uploadAudio,
  uploadBadge,
  createReflection,
} from 'utils/game/gameService';
import { useParams } from 'react-router-dom';
import AboutStory from './AboutStory';
import GreetingsForm from './GreetingsForm';
import Customization from './Customize';
import IconBox from 'components/icons/IconBox';
import { TbView360 } from 'react-icons/tb';
import { FaRobot } from 'react-icons/fa';
import { MdPageview } from 'react-icons/md';
import { GiBlackBook } from 'react-icons/gi';
import { FaCubes } from 'react-icons/fa';
import { MdTune } from 'react-icons/md';
import { MdRocketLaunch } from 'react-icons/md';
import { Navigate, useNavigate } from 'react-router-dom';
import {
  MdCheckCircle,
  MdSettings,
  MdMyLocation,
  MdImage,
  MdIncompleteCircle,
  MdArrowCircleRight,
  MdArrowCircleLeft,
  MdEdit,
  MdPointOfSale,
  MdShoppingBasket,
  MdArchive,
  MdLocalShipping,
} from 'react-icons/md';
import { TfiRulerPencil } from 'react-icons/tfi';
import { BsShareFill } from 'react-icons/bs';
import AddScores from './AddScores';
import CompletionScreen from './Completion';

import Background from 'assets/img/stepper/background.png';
import Block from 'assets/img/stepper/blocks.png';
import pose from 'assets/img/stepper/pose.png';
import stroy from 'assets/img/stepper/stroy.png';
import scores from 'assets/img/stepper/scores.png';
// import endflag from 'assets/img/stepper/endflag.png'
import endflag from 'assets/img/stepper/reached.png';
import summary from 'assets/img/stepper/summary.png';
import NftStepper from 'assets/img/nfts/NftStepper.png';
import Stepbg from 'assets/img/product/product-footer.png';
import Stepbg1 from 'assets/img/product/OverviewBanner.png';
import Stepbg2 from 'assets/img/ecommerce/Details.png';
import OrderStep from 'components/dataDisplay/OrderStep';
import { TbProgress } from "react-icons/tb";
import ImagePreview from './ImagePreview';
const steps = [
  { title: 'BackGround' },
  { title: 'Non Playing Charater' },
  { title: 'About Story' },
  { title: 'Blocks' },
  { title: 'Score' },
  { title: 'Summaries' },
  { title: 'Endpage' },
];
const GameCreation = () => {
  ///////////////////Navin 15-12///////////////////////////////////
  const cancelRef = React.useRef();
  const productTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
  const mediaTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
  const pricingTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
  const takeawayTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
  const welcomeTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
  const thankyouTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;

  const [showFunction, setShowFunction] = useState<any>('mediaTab');



  console.log('showFunction', showFunction);
  //////////////////navin/////////////////////////
  const [badge, setBadge] = useState(null);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const navigate = useNavigate();
  const toast = useToast();
  const [tab, setTab] = useState<number>(1);
  const [img, setImg] = useState<any[]>([]),
    [hoveredStates, setHoveredStates] = useState(Array(img.length).fill(false)),
    [showFullTextStates, setShowFullTextStates] = useState(
      Array(img.length).fill(false),
    ),
    [toggle, setToggle] = useState<any>(),
    [values, setValues] = useState<any>('Select'),
    [preview, setPreview] = useState<any>(),
    [players, setPlayers] = useState<any[]>([]);
  const [reflection, setReflection] = useState([]);
  enum SummaryState {
    Yes = 'yes',
    No = 'no',
  }

  enum feedBackForm {
    Yes = 'yes',
    No = 'no',
  }

  const [isOpenSummary, setIsOpenSummary] = useState<SummaryState>(
    SummaryState.No,
  );
  const [isEditing, setIsEditing] = useState(false);
  const [inputValue, setInputValue] = useState('');

  const [isSave, setIsSave] = useState(true);
  //////////////////////Changes-14/12/23///////////////////////////////////////
  const [selections, setSelections] = useState(Array(img.length).fill(false));
  const [selectedCardIndex, setSelectedCardIndex] = useState(null);
  ////////////////////////////////////////////////////////////////////////////
  //navin

  const [previewId, setPreviewId] = useState(null);
  //navin
  const [fetchImg, setFetchImg] = useState<any>(''),
    [fetchPlayerImg, setFetchPlayerImg] = useState<any>(''),
    [selectedPlayer, setSelectedPlayer] = useState<any>(''),
    [backgroundIndex, setBackgroundIndex] = useState<any>(),
    [sentAud, setSentAud] = useState(null),
    [tags, setTags] = useState<any[]>([]),
    [nonPlayer, setNonPlayer] = useState(),
    [clicked, setClicked] = useState(false),
    [cat, setCat] = useState([]),
    [enter, setEnter] = useState(false),
    [bgIndex, setBgIndex] = useState<number>(),
    [formData, setFormData] = useState({
      gameCategoryid: null,
      gameabstract: null,
      gameBibliography: null,
      gameDistinctionScore: null,
      gameMinScore: null,
      gameMaxScore: null,
      gameBackgroundId: null,
      gameCourseType: 'Public',
      gameNonPlayingCharacterId: null,
      //navin
      gameNonPlayerName: null,
      gameNonPlayerVoice: null,
      gamePlayerMaleVoice: null,
      gamePlayerFemaleVoice: null,
      gameNarratorVoice: null,

      //navin
      ///Afrith
      gameStoryLine: '',
      gameReflectionQuestion: null,
      ///
      gameAnimationId: null,
      gameTitle: '',
      // gameStoryLine: '',
      gameSkills: '',
      gameLearningOutcome: '',
      gameDuration: null,
      gameAuthorName: '',
      gameIsShowLeaderboard: 'false', //indu --from
      gameIsShowReflectionScreen: 'false',
      gameTakeawayContent: '',
      gameAdditionalWelcomeNote: '',
      gameThankYouMessage: '',
      gameIsCollectLearnerFeedback: 'false',
      gameIsFeedbackMandatory: 'false',
      gameIsLearnerMandatoryQuestion: 'false',
      // gameIsAddanotherQuestions:'',
      gameIsSetMinPassScore: 'false',
      gameIsSetDistinctionScore: 'false',
      gameIsSetSkillWiseScore: 'false',
      gameIsSetBadge: 'false',
      gameBadgeName: '',
      gameBadge: '',
      gameIsSetCriteriaForBadge: 'false',
      gameAwardBadgeScore: null,
      gameScreenTitle: '',
      gameIsSetCongratsSingleMessage: 'false',
      gameIsSetCongratsScoreWiseMessage: 'false',
      gameCompletedCongratsMessage: '',
      gameMinimumScoreCongratsMessage: '',
      gameLessthanDistinctionScoreCongratsMessage: '',
      gameAboveDistinctionScoreCongratsMessage: '',
      gameIsShowTakeaway: 'false',
      gameIsShowSkill: 'false',
      gameIsShowStoryline: 'false',
      gameIsShowLearningOutcome: 'false',
      gameIsShowGameDuration: 'false',
      gameIsShowAuhorName: 'false',
      gameIsShowAdditionalWelcomeNote: 'false',
      gameTotalScore: null,
      gameReplayAllowed: null,
      gameReflectionpageAllowed: null,
      gameLeaderboardAllowed: null,
      gameReflectionPageId: null,
      gamelanguageId: '',
      gameSummarizes: null,
      gameThankYouPage: null,
      gamWelcomePageText: null,
      gameScormVersion: null,
      gameSummaryScreen: null,
      gameLaunchedWithinPlatform: null,
      gameLastTab: null,
      gameLastTabArray:[],
      refQuestion: [],
      gameDownloadedAsScorm: null,
      gameDefaultFeedbackForm: null,
      gameFeedbackQuestion: null,
      gameLanguageId: null,
      gameShuffle: 'false',
      // gameIsShowInteractionFeedBack: '',
      gameDisableOptionalReplays: 'false',
      gameTrackQuestionWiseAnswers: 'false',
      gameDisableLearnerMailNotifications: 'false',
      gameIntroMusic: null,

      gameCompletionScreenId: null,
      gameLeaderboardScreenId: null,
      // gameReflectionPageId: null,
      gameReflectionScreenId: null,
      gameTakeawayScreenId: null,
      gameWelcomepageBackgroundScreenId: null,
      gameThankYouScreenId: null,
      //navin 16-12

      // gameCompletionScreenId:null,
      // gameLeaderboardScreenId:null,
      // gameTakeawayScreenId:null,
      // gameWelcomepageBackgroundScreenId:null,
      // gameThankYouScreenId:null,
      //navin
    });
  const { id } = useParams();
  const inputRef = useRef<HTMLButtonElement>(null);
  const fetchData = async () => {
    const result = await getImages(1);
    if (result?.status !== 'Success')
      return console.log('getbackruond error:' + result?.message);
    console.log('bgname', result);
    setImg(result?.data);
    const players = await getImages(2);
    if (players?.status !== 'Success')
      return console.log('getbackruond error:' + players?.message);
    setPlayers(players?.data);
  };
  interface OptionType {
    value: string;
    label: string;
  }
  useEffect(() => {
    setFormData((prev)=>({...prev,gameLastTab:tab}));
}, [tab]);
  const handleBackGroundImage = (e: any) => {
    setFormData((prev) => ({
      ...prev,
      gameWelcomepageBackground: e.target.id,
    }));
  };
  {/**************Changes-14/12/23**********************/ }
  const handleH = (i: any) => {
    setBackgroundIndex(i);
  }
  const handleL = () => {
    // setIsHovered(false)
    setBackgroundIndex('');
  }
  {/****************************************************/ }
  //////Changes-14/Dec/23//////////////////////
  const handlePreview = (img: any, backgroundIndex: any, i: any) => {
    setPreview(true)
    setFetchImg((prev: any) => {
      return { ...prev, gasId: img?.gasId, gasAssetImage: img?.gasAssetImage, gasAssetName: img?.gasAssetName, backgroundIndex, i, title: img.temp.tempTitle, stroyline: img.temp.tempStoryLine }
    });
    onOpen();

    console.log('ddimg', img.gasAssetImage);
    console.log('BackgroundIndex--', backgroundIndex);
    console.log('INDEX--', i);
    // console.log('SavedSTATE--',savedState);
  }
  ///////////////////////////////////////////////

  //////////////Changes - 12-Dec-23/////////////////////
  const handlePreviewPlayer = (player: any, backgroundIndex: any, i: any) => {
    setPreview(true);
    setFetchPlayerImg((prev: any) => {
      return {
        ...prev,
        pid: player?.gasId,
        pimg: player?.gasAssetImage,
        pname: player?.gasAssetName,
        backgroundIndex,
        i,
      };
    });
    onOpen();
    // console.log('BackgroundIndex--',backgroundIndex);
  };
  const fetchGameId = async () => {
    const gameById = await getGameById(id);
    if (gameById?.status !== 'Success')
      return alert('error:' + gameById?.message);
    setFormData(gameById?.data);
    const lastTab = gameById?.data?.gameLastTabArray[gameById.data.gameLastTabArray.length - 2];
    setTab(parseInt(lastTab));
    const storedSelectedIndex = localStorage.getItem('selectedCardIndex');
    if (storedSelectedIndex !== null) {
      setSelectedCardIndex(parseInt(storedSelectedIndex));
    }
    // setTab(gameById?.data?.gameLastTab)
  };
  const fetchGameIdUpdate = async () => {
    const gameById = await getGameById(id);
    if (gameById?.status !== 'Success')
      return alert('error:' + gameById?.message);
     
    
    const storedSelectedIndex = localStorage.getItem('selectedCardIndex');
    if (storedSelectedIndex !== null) {
      setSelectedCardIndex(parseInt(storedSelectedIndex));
    }
    // setTab(gameById?.data?.gameLastTab)
  };
  console.log('formData', formData);
  useEffect(() => {
    fetchData();
    if (id) {
      fetchGameId();
    }
  }, []);
  const handleTrans = (tabs: number) => {
    if (formData.gameLastTabArray.includes(tabs)) {
      setTab(tabs);
    }
  }
  ///navin 15-12
  const handleButtonClick = async (clickFunctionName: string) => {
    console.log('clickFunctionName', clickFunctionName);
    console.log('CLICKEDDD');

    let nextFunction: any;

    switch (clickFunctionName) {



      case 'mediaTab':
        if (badge) {
          const formDat = new FormData();
          formDat.append('gasAssetImage', badge);
          formDat.append('gasAssetName', 'badges');
          const res = await uploadBadge(formDat);
          if (res && res.status !== 'Success') {
            toast({
              title: 'Badge upload error.',
              status: 'error',
              duration: 3000,
              isClosable: true,
            });
            return false;
          }
        }
        if (mediaTab && formData.gameTotalScore === "" || formData.gameTotalScore === null) {
          console.log('formdata5-', formData);
          toast({
            title: 'Please Select Total Score.',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });
          return false;
        }
        else if (mediaTab && formData.gameIsSetMinPassScore === "true" && (formData.gameMinScore === null || formData.gameMinScore === undefined || formData.gameMinScore === '')) {

          toast({
            title: 'Please Select a Minimum Score.',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });

          return false;
        }
        else if (mediaTab && formData.gameIsSetDistinctionScore === "true" && (formData.gameDistinctionScore === null || formData.gameDistinctionScore === undefined || formData.gameDistinctionScore === '')) {
          toast({
            title: 'Please Select a Distinction Score.',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });

          return false;
        }
        else if (mediaTab && formData.gameIsSetBadge === "true" && (formData.gameBadgeName === null || formData.gameBadgeName === undefined || formData.gameBadgeName === '')) {
          toast({
            title: 'Please Select a Badge Name.',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });

          return false;
        }
        else if (mediaTab && formData.gameIsSetCriteriaForBadge === "true" && (formData.gameAwardBadgeScore === null || formData.gameAwardBadgeScore === undefined || formData.gameAwardBadgeScore === '')) {
          toast({
            title: 'Please Select Criteria for Badge',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });

          return false;
        }
        else {
          let data = JSON.stringify(formData);

          try {
            const result = await updateGame(id, data);
            if (result?.status !== 'Success') {
              toast({
                title: 'Data Not Updated.',
                status: 'error',
                duration: 3000,
                isClosable: true,
              });
              return console.log('updateBackground error :' + result?.err);
            } else {
              
              toast({
                title: 'Updated.',
                status: 'success',
                duration: 3000,
                isClosable: true,
              });
              setShowFunction('pricingTab')
              mediaTab.current.click();
            }


          } catch (error) {
            console.error('An error occurred while sending the request:', error);
          }

        }

        break;
        case 'pricingTab':
          let data = JSON.stringify(formData);

          try {
            const result = await updateGame(id, data);
            if (result?.status !== 'Success') {
              toast({
                title: 'Data Not Updated.',
                status: 'error',
                duration: 3000,
                isClosable: true,
              });
              return console.log('updateBackground error :' + result?.err);
            } else {
              toast({
                title: 'Updated.',
                status: 'success',
                duration: 3000,
                isClosable: true,
              });
              setShowFunction('takeawayTab')
              pricingTab.current.click();
            }


          } catch (error) {
            console.error('An error occurred while sending the request:', error);
          }




          break;
      case 'takeawayTab':

        if (takeawayTab && formData.gameIsShowReflectionScreen === "true") {

          reflection.forEach((item, i) => {
            console.log('lsdosdhofoanksvnoibdhinkxnzc', item);
            if (item.value === '') {
              toast({
                title: 'Please Enter Question',
                status: 'error',
                duration: 3000,
                isClosable: true,
              });
              return false;
            }
          })
          const transed = {
            gameId: parseInt(id),
            refs: reflection,
          }
          const data = JSON.stringify(transed);
          const resu = await createReflection(data);
          if (resu.status !== 'Success') {
            toast({
              title: 'Question not processed',
              status: 'error',
              duration: 3000,
              isClosable: true,
            });
            return false;
          }
          else {
            toast({
              title: 'Question stored',
              status: 'success',
              duration: 3000,
              isClosable: true,
            });
            console.log(resu);
            setShowFunction('welcomeTab')
            takeawayTab.current.click();
          }
        }
        else {
          setShowFunction('welcomeTab')
          takeawayTab.current.click();
        }
        break;
        case 'welcomeTab':
          if (welcomeTab && formData.gameIsShowTakeaway === "true" && (formData.gameTakeawayContent === null || formData.gameTakeawayContent === undefined || formData.gameTakeawayContent === '')) {
            toast({
              title: 'Please Enter TakeAway Content',
              status: 'error',
              duration: 3000,
              isClosable: true,
            });
  
            return false;
          }
          else {
            let data = JSON.stringify(formData);
  
            try {
              const result = await updateGame(id, data);
              if (result?.status !== 'Success') {
                toast({
                  title: 'Data Not Updated.',
                  status: 'error',
                  duration: 3000,
                  isClosable: true,
                });
                return console.log('updateBackground error :' + result?.err);
              } else {
                toast({
                  title: 'Updated.',
                  status: 'success',
                  duration: 3000,
                  isClosable: true,
                });
                setShowFunction('thankyouTab')
                welcomeTab.current.click();
              }
  
  
            } catch (error) {
              console.error('An error occurred while sending the request:', error);
            }
          }
        break;
      
      case 'thankyouTab':
       
        if (thankyouTab && formData.gameIsShowAdditionalWelcomeNote === "true" && (formData.gameAdditionalWelcomeNote === null || formData.gameAdditionalWelcomeNote === undefined || formData.gameAdditionalWelcomeNote === '')) {
          toast({
            title: 'Please Add Welcome Note',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });

          return false;
        }
        else {


          let data = JSON.stringify(formData);

          try {
            const result = await updateGame(id, data);
            if (result?.status !== 'Success') {
              toast({
                title: 'Data Not Updated.',
                status: 'error',
                duration: 3000,
                isClosable: true,
              });
              return console.log('updateBackground error :' + result?.err);
            } else {
              toast({
                title: 'Updated.',
                status: 'success',
                duration: 3000,
                isClosable: true,
              });
              
              setShowFunction('end')
              thankyouTab.current.click();
            }


          } catch (error) {
            console.error('An error occurred while sending the request:', error);
          }
        }
        break;

      case 'end':

       
        try {
          let data = JSON.stringify(formData);
          const result = await updateGame(id, data);
          if (result?.status !== 'Success') {
            toast({
              title: 'Data Not Updated.',
              status: 'error',
              duration: 3000,
              isClosable: true,
            });
            return console.log('updateBackground error :' + result?.err);
          } else {
            toast({
              title: 'Updated.',
              status: 'success',
              duration: 3000,
              isClosable: true,
            });
            const { gameLastTab, ...formDataWithoutLastTab } = result?.data;

            setFormData(formDataWithoutLastTab);
            setShowFunction('mediaTab');
            onOpen();
            nextFunction = null;
          }


        } catch (error) {
          console.error('An error occurred while sending the request:', error);
        }

        break;
      
      default:
        console.error(`${clickFunctionName} is not a valid function.`);
        return;
    }
    //   // let sliptv = nextFunction.name.split('.');
    //   // let stringConvert = JSON.stringify(sliptv[0]);
    //   // setShowFunction(stringConvert);
    // console.log('nextFunction',nextFunction)
    //   // if (nextFunction) {
    //   //   nextFunction();
    //   // }
  };
  //navin
  const commonNextFunction = async () => {
    if (tab === 1 && !formData.gameBackgroundId) {
      toast({
        title: 'Please Select a background image.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
      return false;
    }
    if (tab === 3 && !formData.gameTitle) {
      toast({
        title: 'Please Enter The Stroy Title',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });

      return false;
    }
    if (tab === 3 && !formData.gameStoryLine) {
      toast({
        title: 'Please Enter The Story Line',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });

      return false;
    }
    if (tab === 3) {
      let cate = JSON.stringify(cat);
      let da = JSON.stringify(tags);
      const res = await createSkills(id, da);
      const cats = await createCategories(id, cate);
      if (res?.status !== 'Success' && res?.data.length === 0) return toast({
        title: 'Cannot Skills',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
      if (cats?.status !== 'Success' && cats?.data.length === 0)
        return toast({
          title: 'Cannot Skills',
          status: 'error',
          duration: 3000,
          isClosable: true,
        });

      console.log('FormData', JSON.stringify(res.data))
    }
    if (tab === 6) {
      if (sentAud) {
        const formDat = new FormData();
        formDat.append('gasAssetImage', sentAud);
        formDat.append('gasAssetName', 'Intro');
        const aud = await uploadAudio(formDat);
        if (aud && aud.status !== 'Success') {
          toast({
            title: 'Cannot upload Audio',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });
          return false;
        }
        setFormData((prev) => ({ ...prev, gameIntroMusic: aud && aud.data.gasId }));
      }
      else {
        toast({
          title: 'please upload Audio',
          status: 'error',
          duration: 3000,
          isClosable: true,
        });
        return false;
      }
    }
    if (tab === 8 && !formData.gamWelcomePageText) {
      toast({
        title: 'Please Fill all required feilds.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });

      return false;
    }
    if (tab === 8 && !formData.gameThankYouPage) {
      toast({
        title: 'Please Fill all required feilds.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });

      return false;
    }
    if (tab === 8 && !formData.gameScormVersion) {
      toast({
        title: 'Please Fill all required feilds.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });

      return false;
    }
    if (isOpenSummary === SummaryState.Yes) {
      console.log('isOpenSummary is true !');
    }

    // if(tab<tab)
    // {
    //   arrange.gameLastTab = tab;
    // }
    // else{
    //   arrange.gameLastTab= formData?.gameLastTab
    // }
    let data = JSON.stringify(formData);

    if (tab === 1 && !id) {
      try {

        const result = await addgame(formData);
        console.log('resultDTA', tab);
        if (result?.status !== 'Success') {
          toast({
            title: 'Data Not Created.',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });
          return console.log('updateBackground error :' + result?.err);
        } else {
          if (tab === 1 && result.status === 'Success') {
            toast({
              title: 'Background Image Stored',
              status: 'success',
              duration: 3000,
              isClosable: true,
              position: 'bottom-right',
            });
            setTab(tab + 1);
            navigate(`/admin/superadmin/game/creation/${result.data.gameId}`);
          }
        }
      } catch (error) {
        console.error('An error occurred while sending the request:', error);
      }
    } else {
      try {
        const result = await updateGame(id, data);
        if (result?.status !== 'Success') {
          toast({
            title: 'Data Not Updated.',
            status: 'error',
            duration: 3000,
            isClosable: true,
          });
          return console.log('updateBackground error :' + result?.err);
        }

        if (tab === 1 && result.status === 'Success') {
          toast({
            title: 'Background Image Updated',
            status: 'success',
            duration: 3000,
            isClosable: true,
            position: 'bottom-right',
          });
          setTab(tab + 1);
          const { gameLastTab, ...formDataWithoutLastTab } = result?.data;

          setFormData(formDataWithoutLastTab);
          
          // setFormData((prev)=>({...prev,gameLastTab:formData.gameLastTab+1}));
        }

        if (tab === 2 && result.status === 'Success') {
          toast({
            title: 'Non-Playing Character Updated',
            status: 'success',
            duration: 3000,
            isClosable: true,
            position: 'bottom-right',
          });
          setTab(tab + 1);
          const { gameLastTab, ...formDataWithoutLastTab } = result?.data;

          setFormData(formDataWithoutLastTab);
          
        }

        if (tab === 3 && result.status === 'Success') {
          toast({
            title: 'About Story Updated',
            status: 'success',
            duration: 3000,
            isClosable: true,
            position: 'bottom-right',
          });
          // console.log('asbasflknafkanfknapnakndakndaknkanpAFPAofhEPEFPEAOFPAOEFPAEOHFAOJ[ALMAIGHPIWH  ke]pk3-it=0w4-tw0kfakf]ie0rgjsjg')
          setTab(tab + 1);
          const { gameLastTab, ...formDataWithoutLastTab } = result?.data;

          setFormData(formDataWithoutLastTab);
          
          // setFormData((prev)=>({...prev,gameLastTab:formData.gameLastTab+1}));
        }

        if (tab === 4 && result.status === 'Success') {
          toast({
            title: 'Story  Updated',
            status: 'success',
            duration: 3000,
            isClosable: true,
            position: 'bottom-right',
          });
          setTab(tab + 1);
          const { gameLastTab, ...formDataWithoutLastTab } = result?.data;

          setFormData(formDataWithoutLastTab);
          
          // setFormData((prev)=>({...prev,gameLastTab:formData.gameLastTab+1}));
        }

        if (tab === 5 && result.status === 'Success') {
          toast({
            title: 'Score Updated',
            status: 'success',
            duration: 3000,
            isClosable: true,
            position: 'bottom-right',
          });
          setTab(tab + 1);
          const { gameLastTab, ...formDataWithoutLastTab } = result?.data;

          setFormData(formDataWithoutLastTab);
          
          // setFormData((prev)=>({...prev,gameLastTab:formData.gameLastTab+1}));
        }

        if (tab === 6 && result.status === 'Success') {
          toast({
            title: 'Summary Updated',
            status: 'success',
            duration: 3000,
            isClosable: true,
            position: 'bottom-right',
          });
          setTab(tab + 1);
          const { gameLastTab, ...formDataWithoutLastTab } = result?.data;

          setFormData(formDataWithoutLastTab);
          
          // setFormData((prev)=>({...prev,gameLastTab:formData.gameLastTab+1}));
        }
        if (tab === 7 && result.status === 'Success') {
          toast({
            title: 'Ready To Launch',
            status: 'success',
            duration: 3000,
            isClosable: true,
            position: 'bottom-right',
          });
          setTab(7);
          const { gameLastTab, ...formDataWithoutLastTab } = result?.data;

          setFormData(formDataWithoutLastTab);
          
          // setFormData((prev)=>({...prev,gameLastTab:formData.gameLastTab+1}));
        }
      } catch (error) {
        console.error('An error occurred while sending the request:', error);
      }
    }
  };
  function truncateText(text:any, maxLength:any, maxLineLength:10) {
    if (text.length <= maxLength) {
      return text;
    } else {
      let truncatedText = text.slice(0, maxLength);
      
      // Break lines after maxLineLength characters
      truncatedText = truncatedText.replace(new RegExp(`(.{${maxLineLength}})`, 'g'), '$1\n');
      
      return truncatedText + '........';
    }
  }
  ////////////////////////////Changes-14/12/23//////////////////////
  const handleBackground = (img: any, i: any) => {
    console.log('back image', img)
    // setIsSelected(!isSelected);
    setBackgroundIndex((prevIndex: any) => (prevIndex === i ? null : i));
    // setFetchImg(img?.aniId);

    ///
    if (selectedCardIndex === i) {
      // Clicked on already selected card, deselect it
      setSelectedCardIndex(null);
      setFormData((prev) => ({
        ...prev,
        gameBackgroundId: null,

      }));
      localStorage.removeItem('selectedCardIndex');
    } else {
      // Select new card and deselect the previously selected one (if any)
      setSelectedCardIndex(i);
      setFormData((prev) => ({
        ...prev,
        gameBackgroundId: img.gasId,

      }));
      localStorage.setItem('selectedCardIndex', i);
    }
    setBackgroundIndex((prevIndex: any) => (prevIndex === i ? null : i));
    ///

    setFetchImg((prev: any) => {
      return {
        ...prev,
        id: img?.gasId,
        img: img?.gasAssetImage,
        name: img?.gasAssetName,
      };
    });
    ////
    const updatedSelections = [...selections];
    updatedSelections[i] = !updatedSelections[i];
    setSelections(updatedSelections);
    ///
    onClose();
    console.log('img', img);

    console.log('Function3-', selectedCardIndex);
    if (selectedCardIndex === i) {
      
    }else{
      console.log('form gas id-', );
      // setTimeout(() => {
      //   
      // }, 1000);
     
    }

  };
  useEffect(() => {
    if(formData.gameBackgroundId){
      setPreview(false)
      commonNextFunction();
    }
   
  }, [formData.gameBackgroundId]);
  /////////////////////////////////////////////////////////////////

  const handlePlayer = (player: any, i: any) => {
    setNonPlayer((prevIndex: any) => (prevIndex === i ? null : i));

    setSelectedPlayer((prev: any) => {
      return {
        ...prev,
        id: player?.gasId,
        img: player?.gasAssetImage,
        name: player?.gasAssetName,
      };
    });
    console.log('selectdplayer', selectedPlayer);
  };
  const handleChange = (e: any) => {
    const { name, value, checked } = e.target;
    if (name === 'gameDuration') {
      let duration =
        parseInt(value.split(':')[0], 10) * 60 +
        parseInt(value.split(':')[1], 10);
      setFormData((prev) => ({ ...prev, gameDuration: String(duration) }));
    }
    else if (
      name === 'gameIsSetMinPassScore' ||
      name === 'gameIsSetDistinctionScore' ||
      name === 'gameIsSetSkillWiseScore' ||
      name === 'gameIsSetBadge' ||
      name === 'gameIsSetCriteriaForBadge' ||
      name === 'gameIsSetCongratsSingleMessage' ||
      name === 'gameIsSetCongratsScoreWiseMessage' ||
      name === 'gameIsShowLeaderboard' ||
      name === 'gameIsShowReflectionScreen' ||
      name === 'gameIsLearnerMandatoryQuestion' ||
      name === 'gameIsShowTakeaway' ||
      name === 'gameIsShowSkill' ||
      name === 'gameIsShowStoryline' ||
      name === 'gameIsShowLearningOutcome' ||
      name === 'gameIsShowGameDuration' ||
      name === 'gameIsShowAuhorName' ||
      name === 'gameIsShowAdditionalWelcomeNote' ||
      name === 'gameIsCollectLearnerFeedback' ||
      name === 'gameIsFeedbackMandatory' ||
      name === 'gameShuffle' ||
      name === 'gameDisableOptionalReplays' ||
      name === 'gameTrackQuestionWiseAnswers' ||
      name === 'gameDisableLearnerMailNotifications') {
      setFormData((prev) => ({ ...prev, [name]: String(checked) }))
    }
    else if (e.target.id === 'gameLaunchedWithinPlatform') {
      e.target.checked
        ? setFormData((prev) => ({ ...prev, [name]: value }))
        : setFormData((prev) => ({ ...prev, [name]: 0 }));
    } else if (name === 'gameDownloadedAsScorm') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 1 : 0 }));
      console.log('gameDownloadedAsScorm', formData.gameDownloadedAsScorm);
    } else if (name === 'gameDefaultFeedbackForm') {
      setFormData((prev) => ({
        ...prev,
        [name]: checked ? feedBackForm.Yes : feedBackForm.No,
      }));
      console.log('gameDefaultFeedbackForm', formData.gameDefaultFeedbackForm);
    } else if (name === 'gameReplayAllowed') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'true' : 'false' }));
      console.log('gameReplayAllowed', formData.gameReplayAllowed);
    } else if (name === 'gameLeaderboardAllowed') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'true' : 'false' }));
      console.log('gameLeaderboardAllowed', formData.gameLeaderboardAllowed);
    } else if (name === 'gameReflectionpageAllowed') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'true' : 'false' }));
      console.log(
        'gameReflectionpageAllowed',
        formData.gameReflectionpageAllowed,
      );
    } else if (name === 'gameFeedbackQuestion') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'true' : 'false' }));
      console.log('gameFeedbackQuestion', formData.gameFeedbackQuestion);
    } else if (name === 'gameShuffle') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'true' : 'false' }));
      console.log('gameShuffle', formData.gameShuffle);
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
    console.log('formdata', formData);
  };
  // const handleMouse = (i: number) => {
  //   setEnter(true);
  //   setBgIndex(i);
  // };
  // const handleMouseLeave = () => {
  //   setEnter(false);
  //   setBgIndex(null);
  // };

  const handleHover = (index: number, isHovered: boolean) => {
    const newHoveredStates = [...hoveredStates];
    newHoveredStates[index] = isHovered;
    setHoveredStates(newHoveredStates);
  };
  const handleSummaryState = (isOpen: any) => {
    setIsOpenSummary(isOpen);
    setFormData((prev) => ({
      ...prev,
      gameSummaryScreen: !isOpen ? SummaryState.No : SummaryState.Yes,
    }));

    // console.log('isOpenSummary',isOpenSummary);
    // console.log('formData',formData);
  };
  const handleLanguageChange = (selectedOption: OptionType | null) => {
    setFormData({ ...formData, gameLanguageId: selectedOption.value });
    console.log('formData', selectedOption.value);
  };
  const handleIntroMusic = (selectedOption: OptionType | null) => {
    setFormData({ ...formData, gameIntroMusic: selectedOption.value });
    console.log('formData', selectedOption.value);
  };

  const myBlink = keyframes`
  0% {
    filter: drop-shadow(2px 4px 6px #0000);
  }
  50% {
    filter: drop-shadow(2px 4px 6px #411ab3);
  }
  100% {
    filter: drop-shadow(2px 4px 6px #0000);
  }
  `;

  const blink = `${myBlink} 0.5s linear infinite`;
  const textColor = useColorModeValue('secondaryGray.900', 'white');
  const brandColor = useColorModeValue('brand.500', 'white');
  const completeBg = useColorModeValue(
    'white',
    'linear-gradient(180deg, #1F2A4F 0%, #18224D 50.63%, #111C44 100%)',
  );
  const completeShadow = useColorModeValue(
    '0px 18px 40px rgba(112, 144, 176, 0.12)',
    'inset 0px 4px 4px rgba(255, 255, 255, 0.2)',
  );
  const incompleteColor = useColorModeValue(
    'secondaryGray.600',
    'whiteAlpha.200',
  );
  const incompleteShadow = useColorModeValue(
    'inset 0px 18px 22px rgba(112, 144, 176, 0.1)',
    'inset 0px 4px 4px #0B1437',
  );
  const lineColor = useColorModeValue('%23a3aed0', '%23FFFFFF1A');

  // SET BORDER IN IMAGE
  const stepImgActiveBorder = 'done';
  const stepImgBorder = '';
  const tab1 = formData?.gameLastTabArray.includes(1) ? stepImgActiveBorder : stepImgBorder;
  const tab2 = formData?.gameLastTabArray.includes(2) ? stepImgActiveBorder : stepImgBorder;
  const tab3 = formData?.gameLastTabArray.includes(3) ? stepImgActiveBorder : stepImgBorder;
  const tab4 = formData?.gameLastTabArray.includes(4) ? stepImgActiveBorder : stepImgBorder;
  const tab5 = formData?.gameLastTabArray.includes(5)  ? stepImgActiveBorder : stepImgBorder;
  const tab6 = formData?.gameLastTabArray.includes(6)  ? stepImgActiveBorder : stepImgBorder;
  const tab7 = formData?.gameLastTabArray.includes(7) ? stepImgActiveBorder : stepImgBorder;

  // set height and width for stepper image based on tab
  const stepImgActiveHeight = '110px';
  const stepImgHeight = '78px';
  const stepBgImg = tab == 1 ? stepImgActiveHeight : stepImgHeight;
  const stepNonPlaying = tab == 2 ? stepImgActiveHeight : stepImgHeight;
  const stepAbtStory = tab == 3 ? stepImgActiveHeight : stepImgHeight;
  const stepBlocks = tab == 4 ? stepImgActiveHeight : stepImgHeight;
  const stepScore = tab == 5 ? stepImgActiveHeight : stepImgHeight;
  const stepSummaries = tab == 6 ? stepImgActiveHeight : stepImgHeight;
  const stepEnd = tab == 7 ? stepImgActiveHeight : stepImgHeight;

  // SET ACTIVE STATUS BASED ON TAB
  const stepIconActiveColor = completeShadow;
  const stepIconColor = incompleteShadow;
  const stepPoseIcon = tab >= 2 ? stepIconActiveColor : stepIconColor;
  const stepAboutStoryIcon = tab >= 3 ? stepIconActiveColor : stepIconColor;
  const stepBlockIcon = tab >= 4 ? stepIconActiveColor : stepIconColor;
  const stepScoreIcon = tab >= 5 ? stepIconActiveColor : stepIconColor;
  const stepSummariesIcon = tab >= 6 ? stepIconActiveColor : stepIconColor;
  const stepCompleteIcon = tab >= 7 ? stepIconActiveColor : stepIconColor;

  // SET ACTIVE CHECK BASED ON TAB
  const stepCheckActiveColor = brandColor;
  const stepCheckColor = incompleteColor;
  const stepbgCheck = formData?.gameLastTabArray.includes(1)? stepCheckActiveColor : stepCheckColor;
  const stepPoseCheck = formData?.gameLastTabArray.includes(2) ? stepCheckActiveColor : stepCheckColor;
  const stepAboutStoryCheck = formData?.gameLastTabArray.includes(3) ? stepCheckActiveColor : stepCheckColor;
  const stepBlockCheck = formData?.gameLastTabArray.includes(4) ? stepCheckActiveColor : stepCheckColor;
  const stepScoreCheck = formData?.gameLastTabArray.includes(5)? stepCheckActiveColor : stepCheckColor;
  const stepSummariesCheck = formData?.gameLastTabArray.includes(6) ? stepCheckActiveColor : stepCheckColor;
  const stepCompleteCheck = formData?.gameLastTabArray.includes(7)? stepCheckActiveColor : stepCheckColor;

  const steps = [
    {
      title: 'Background',
      description:
        'Contact Info sddfaf asfasf  fASAF dad  EDsd dA dADda DDEde Dd DEWe Q QW OIH OIHO HIUG G 8G 8G 8 UG8 G8 G8 G 8G GEwgeg',
    },
    { title: 'Character', description: 'Date & Time' },
    { title: 'Overview', description: 'Select Rooms' },
    { title: 'Story', description: 'Select Rooms' },
    { title: 'Prefrences', description: 'Select Rooms' },
    { title: 'Design', description: 'Select Rooms' },
    { title: 'Launch', description: 'Select Rooms' },
  ];
  const [activeStep, setActiveStep] = useState(1);

  const handleStepChange = (step: any) => {
    setActiveStep(step);
  };

  const handleReadMore = (index: number) => {
    const newShowFullTextStates = [...showFullTextStates];
    newShowFullTextStates[index] = true;
    setShowFullTextStates(newShowFullTextStates);
  };

  const handleEditClick = (player: any, i: any) => {
    // setInputValue(player?.gasAssetName);
    setInputValue((prev: any) => {
      return {
        ...prev,
        pid: player?.gasId,
        pimg: player?.gasAssetImage,
        pname: player?.gasAssetName,
        i,
      };
    });
    setIsEditing(true);
    setIsSave(false);

  };

  console.log('input--', inputValue);

  const handleSave = () => {
    setIsSave(true);
    setIsEditing(false);
  };
  //navin 16-12
  useEffect(() => {
    if (formData.gameIsSetCongratsScoreWiseMessage === 'true') {
      setFormData((prev) => ({
        ...prev,
        gameIsSetCongratsScoreWiseMessage: 'true',
        gameIsSetCongratsSingleMessage: 'false',

      }));

    }

  }, [formData.gameIsSetCongratsScoreWiseMessage]);
  useEffect(() => {

    if (formData.gameIsSetCongratsSingleMessage === 'true') {

      setFormData((prev) => ({
        ...prev,
        gameIsSetCongratsSingleMessage: 'true',
        gameIsSetCongratsScoreWiseMessage: 'false'
      }));
    }
  }, [formData.gameIsSetCongratsSingleMessage]);


  //navin 16-12


  //navin
  const playerPerview = (id: any) => {

    setPreview(true)
    setPreviewId(id)

  }
  const makeInputFiled = (id: any, name: any) => {
    console.log('id', id)


    if (formData.gameNonPlayingCharacterId !== id) {
      setFormData((prev) => ({
        ...prev,
        gameNonPlayingCharacterId: id,
        gameNonPlayerName: name,
        gameNonPlayerVoice: null,
        gamePlayerMaleVoice: null,
        gamePlayerFemaleVoice: null,
        gameNarratorVoice: null

      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        gameNonPlayingCharacterId: null,
        gameNonPlayerName: null,
        gameNonPlayerVoice: null,
        gamePlayerMaleVoice: null,
        gamePlayerFemaleVoice: null,
        gameNarratorVoice: null
      }));
    }


  }
  useEffect(() => {
    if(formData.gameNonPlayingCharacterId){
      playerPerview(formData.gameNonPlayingCharacterId)
      
    }
   
  }, [formData.gameNonPlayingCharacterId]);
  // navin
  return (
    <>
      <Grid templateColumns="repeat(5, 1fr)" gap={2}>
        <GridItem colSpan={{ sm: 5, md: 1 }}>
          {/* <Card width={'290px'} h={'700px'} mt={{ base: '90px', xl: '90px' }} alignItems={'center'} bg={'linear-gradient(to bottom, #7551ff, #3311db)'}> */}
          <HStack
            borderRadius={'20px'}
            width={'280px'}
            mt={{ base: '90px', xl: '90px' }}
            // h={'700px'}
            overflow={'auto'}
          >
            <Card
              flexDirection="column"
              w="100%"
            // bg={'linear-gradient(to bottom, #7551ff, #3311db)'}
            >
              
              <Flex position="relative" direction="column">
                <Flex
                  position="absolute"
                  left="32.5px"
                  h="100%"
                  w="2px"
                  bg={`url("data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' stroke='${lineColor}' stroke-width='4' stroke-dasharray='6%2c 14' stroke-dashoffset='0' stroke-linecap='square'/%3e%3c/svg%3e")`}
                  zIndex={1}
                />
                <OrderStep
                  cursor={'pointer'}
                  onClick={() => handleTrans(1)}
                  mb="30px"
                  name="BackGround"
                  status={tab1}
                  icon={
                    <IconBox
                      h="66px"
                      w="66px"
                      bg={completeBg}
                      boxShadow={stepPoseIcon}
                      icon={
                        <Icon
                          as={TbView360}
                          color={stepbgCheck}
                          h="32px"
                          w="32px"
                        />
                      }
                    />
                  }
                />
                <OrderStep
                  cursor={'pointer'}
                  onClick={() => handleTrans(2)}
                  mb="30px"
                  name="Character"
                  status={tab2}
                  icon={
                    <IconBox
                      h="66px"
                      w="66px"
                      // color='#fff'
                      bg={completeBg}
                      boxShadow={stepAboutStoryIcon}
                      icon={
                        <Icon
                          as={FaRobot}
                          color={stepPoseCheck}
                          h="32px"
                          w="32px"
                        />
                      }
                    />
                  }
                />
                <OrderStep
                  cursor={'pointer'}
                  onClick={() => handleTrans(3)}
                  mb="30px"
                  name="Overview"
                  status={tab3}
                  icon={
                    <IconBox
                      h="66px"
                      w="66px"
                      bg={completeBg}
                      boxShadow={stepBlockIcon}
                      icon={
                        <Icon
                          as={MdOutlineSubtitles}
                          color={stepAboutStoryCheck}
                          h="32px"
                          w="32px"
                        />
                      }
                    />
                  }
                />
                <OrderStep
                  cursor={'pointer'}
                  onClick={() => handleTrans(4)}
                  mb="30px"
                  name="Story"
                  status={tab4}
                  icon={
                    <IconBox
                      h="66px"
                      w="66px"
                      bg={completeBg}
                      boxShadow={stepAboutStoryCheck}
                      icon={
                        <Icon
                          as={GiBlackBook}
                          color={stepBlockCheck}
                          h="32px"
                          w="32px"
                        />
                      }
                    />
                  }
                />
                <OrderStep
                  cursor={'pointer'}
                  onClick={() => handleTrans(5)}
                  mb="30px"
                  name="Design"
                  status={tab5}
                  icon={
                    <IconBox
                      h="66px"
                      w="66px"
                      bg={completeBg}
                      boxShadow={stepScoreIcon}
                      icon={
                        <Icon
                          as={FaCubes}
                          color={stepScoreCheck}
                          h="32px"
                          w="32px"
                        />
                      }
                    />
                  }
                />
                <OrderStep
                  cursor={'pointer'}
                  onClick={() => handleTrans(6)}
                  mb="30px"
                  name="Preferences"
                  status={tab6}
                  icon={
                    <IconBox
                      h="66px"
                      w="66px"
                      bg={completeBg}
                      boxShadow={stepSummariesIcon}
                      icon={
                        <Icon
                          as={MdTune}
                          color={stepSummariesCheck}
                          h="32px"
                          w="32px"
                        />
                      }
                    />
                  }
                />
                <OrderStep
                  cursor={'pointer'}
                  onClick={() => handleTrans(7)}
                  name="Launch"
                  status={tab7}
                  icon={
                    <IconBox
                      h="66px"
                      w="66px"
                      bg={completeBg}
                      boxShadow={stepCompleteIcon}
                      icon={
                        <Icon
                          as={MdRocketLaunch}
                          color={stepCompleteCheck}
                          h="32px"
                          w="32px"
                        />
                      }
                    />
                  }
                />
              </Flex>
            </Card>
          </HStack>
          {/* { options.map((it,i)=>(
           <Box key={i} p={'20px'}>
            <Text fontSize={20} fontWeight={700} color={'#fff'}><Icon mt={'10px'} as={MdEdit}/>{it}</Text>
            </Box>
           ))
           }  */}
          {/* </Card> */}
        </GridItem>
        <GridItem colSpan={{ sm: 5, md: 4 }}>
          <Box className="game-creation" mt={{ base: '100px', xl: '100px' }}>
            <Grid templateColumns="repeat(1, 1fr)" gap={6}>
              {/* <GridItem w="100%" colSpan={1}>                               
            <motion.div initial={{ opacity: 0, x: 120 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.3 }}>
                <Box className='stepper' w={'100%'} p={'0 20px'} display={'flex'} alignItems={'center'} justifyContent={'space-between'}>
                      <Flex>
                        <Box position={'relative'} display={'flex'} flexDir={'column'} alignItems={'center'}>
                          <Card borderRadius={'50%'} w={stepBgImg} h={stepBgImg} p={0} bg={'#f3f3f3'}  border={tab1} boxShadow={'1px 3px 33px #3c3c3c33'} > 
                            <Img src={Background} h={'300px'} width={'300px'} display={'block'}/>
                          </Card>
                          <Box display={'flex'} alignItems={'center'} mt={'10px'}>
                            <Icon className='icon' as={MdCheckCircle} fontSize={'18px'} color={stepbgCheck} position={'relative'} mr={'5px'} />
                            <Text textAlign={'center'} color={'#000'} fontSize={'17px'} fontWeight={600}>Background</Text>
                          </Box>
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'5px'} color={'blue.300'} />
                        </Box>                        
                      </Flex>
                      <Box mb={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepPoseIcon} />
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepPoseIcon} />
                          </Flex>
                      </Box>                                        
                      <Flex>
                        <Box position={'relative'} display={'flex'} flexDir={'column'} alignItems={'center'}>
                          <Card borderRadius={'50%'} w={stepNonPlaying} h={stepNonPlaying} bg={'#f3f3f3'}  p={0} border={tab2} boxShadow={'1px 3px 33px #3c3c3c33'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                          <Img src={pose} h={'300px'} width={'300px'} display={'block'}/></Card>
                          <Box display={'flex'} alignItems={'center'} mt={'10px'}>
                            <Icon className='icon' as={MdCheckCircle} fontSize={'18px'} color={stepPoseCheck} position={'relative'} mr={'5px'} />
                            <Text textAlign={'center'} color={'#000'} fontSize={'17px'} fontWeight={600}>Character</Text>
                          </Box>
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'blue.300'} />
                        </Box>                        
                      </Flex> 
                      <Box mb={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepAboutStoryIcon} />
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepAboutStoryIcon} />
                          </Flex>
                      </Box>                                        
                      <Flex>
                        <Box position={'relative'} display={'flex'} flexDir={'column'} alignItems={'center'}>
                          <Card borderRadius={'50%'} w={stepAbtStory} h={stepAbtStory} p={0} bg={'#f3f3f3'}   border={tab3}boxShadow={'1px 3px 33px #3c3c3c33'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                          <Img src={stroy} h={'300px'} width={'300px'} display={'block'}/> </Card>
                          <Box display={'flex'} alignItems={'center'} mt={'10px'}>
                             <Icon className='icon' as={MdCheckCircle} fontSize={'18px'} color={stepAboutStoryCheck} position={'relative'} mr={'5px'} />
                            <Text textAlign={'center'} color={'#000'} fontSize={'17px'} fontWeight={600}>About Story</Text>
                          </Box>
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'9px'} color={'blue.300'} />
                        </Box>                        
                      </Flex>                    
                      <Box mb={'23px'}>
                            <Flex>
                              <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepBlockIcon} />
                            </Flex>
                      </Box>
                      <Box position={'relative'} display={'flex'} flexDir={'column'} alignItems={'center'}>
                        <Card borderRadius={'50%'} w={stepBlocks} h={stepBlocks} p={0} bg={'#e1e1e1'}  border={tab4} boxShadow={'1px 3px 33px #3c3c3c33'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                        <Img src={Block} h={'300px'} width={'300px'} display={'block'} borderRadius={'50%'}/>
                        </Card>
                        <Box display={'flex'} alignItems={'center'} mt={'10px'}>
                              <Icon className='icon' as={MdCheckCircle} fontSize={'18px'} color={stepBlockCheck} position={'relative'} mr={'5px'} />
                              <Text textAlign={'center'} color={'#000'} fontSize={'17px'} fontWeight={600}>Blocks</Text>
                        </Box>
                        <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'-8px'} color={'blue.300'} />
                      </Box>                    
                      <Flex>
                        <Box mb={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepScoreIcon}/>
                          </Flex>
                        </Box>                        
                      </Flex>  
                      <Box position={'relative'} display={'flex'} flexDir={'column'} alignItems={'center'}>
                            <Card borderRadius={'50%'} w={stepScore} h={stepScore} bg={'#f3f3f3'}  p={0} border={tab5} boxShadow={'1px 3px 33px #3c3c3c33'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                            <Img src={scores} h={'300px'} width={'300px'} display={'block'} borderRadius={'50%'}/> </Card>
                            <Box display={'flex'} alignItems={'center'} mt={'10px'}>
                              <Icon className='icon' as={MdCheckCircle} fontSize={'18px'} color={stepScoreCheck} position={'relative'} mr={'5px'} />
                              <Text textAlign={'center'} color={'#000'} fontSize={'17px'} fontWeight={600}>Score</Text>
                            </Box>
                            <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'-3px'} color={'#CF9FFF'} />
                      </Box>                    
                      <Flex>
                        <Box mb={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepSummariesIcon} />
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepSummariesIcon} />
                          </Flex>
                        </Box>                        
                      </Flex>                   
                      <Box position={'relative'} display={'flex'} flexDir={'column'} alignItems={'center'}>
                            <Card borderRadius={'50%'} w={stepSummaries} h={stepSummaries} bg={'#f3f3f3'}  p={0} border={tab6}boxShadow={'1px 3px 33px #3c3c3c33'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                            <Img
                              src={summary} h={'300px'} width={'300px'} display={'block'} borderRadius={'50%'}/></Card>
                              <Box display={'flex'} alignItems={'center'} mt={'10px'}>
                              <Icon className='icon' as={MdCheckCircle} fontSize={'18px'} color={stepSummariesCheck} position={'relative'} mr={'5px'} />
                                <Text textAlign={'center'} color={'#000'} fontSize={'17px'} fontWeight={600}>Summaries</Text>
                              </Box>                            
                            <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'3px'} color={'#CF9FFF'} />
                      </Box>                   
                      <Flex>
                        <Box mb={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepCompleteIcon} />
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={stepCompleteIcon} />
                          </Flex>
                        </Box>                        
                      </Flex>                   
                      <Box position={'relative'} display={'flex'} flexDir={'column'} alignItems={'center'}>
                          <Card borderRadius={'50%'} w={stepEnd} h={stepEnd} bg={'#f3f3f3'}  p={0} border={tab7} boxShadow={'1px 3px 33px #3c3c3c33'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                            <Img src={endflag} h={'300px'} width={'300px'} display={'block'} borderRadius={'50%'}/>
                          </Card>
                          <Box display={'flex'} alignItems={'center'} mt={'10px'}>
                             <Icon className='icon' as={MdCheckCircle} fontSize={'18px'} color={stepCompleteCheck} position={'relative'} mr={'5px'} />
                            <Text textAlign={'center'} color={'#000'} fontSize={'17px'} fontWeight={600}>Completed</Text>                          
                          </Box>
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'#CF9FFF'} />
                      </Box>
                </Box>
            </motion.div>
        </GridItem> */}
              <GridItem w="100%" colSpan={2}>
                {/*******************Changes-14/12/23*************************/}
                {preview && <ImagePreview
                  fetchImg={fetchImg}
                  isOpen={isOpen}
                  onOpen={onOpen}
                  onClose={onClose}
                  values={values}
                  setValues={setValues}
                  selectedCardIndex={selectedCardIndex}
                  handleBackground={handleBackground} // Ensure this prop is included
                />}

                {tab === 1 ? (
                  <Box className='background-step' display={{ base: 'block', md: 'flex', lg: 'flex' }}>
                    <Box className='bg-img-list' width={'100%'}>
                      <Box display={'flex'} flexDir={'column'} justifyContent={'start'} alignItems={'start'}>
                        <Text fontSize={'20px'} fontWeight={800} m={'10px 10px 10px 20px'}>
                          BackGround Image
                        </Text>
                      </Box>
                      <Divider mb={'0px'} />
                      <Box height={'700px'} overflowY={'auto'} borderRadius={'70px'} padding={'30px 0'}>
                        <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
                          {img &&
                            img.map((img, i) => (
                              <Box key={i} position={'relative'}>
                                <Card
                                  //  backgroundColor={selections[i] ? '#11047a' : 'white'}
                                  backgroundColor={selectedCardIndex === i ? '#11047a' : 'white'}
                                  mb={{ base: '0px', xl: '10px', sm: '20px' }}
                                  padding={'13px'}
                                  key={i}
                                  position="relative"
                                  // onMouseEnter={() => handleMouseEnter(i)}
                                  // onMouseLeave={() => handleMouseLeaves(i)}
                                  onMouseEnter={() => handleH(i)}
                                  onMouseLeave={() => handleL()}
                                  // _hover={{opacity: 1}}
                                  boxShadow={
                                    backgroundIndex === i ? '1px 4px 29px #44445429' : '1px 4px 29px #44445429'
                                  }
                                  transition={'0.3s'}
                                  overflow="hidden"
                                >
                                  <Box position={'relative'} overflow={'hidden'} borderRadius={'10px'}>
                                    <Img src={img?.gasAssetImage} w="100%" h={'250px'} borderRadius="20px" cursor="pointer" />

                                    {backgroundIndex === i ? (
                                      <Flex
                                        position='absolute'
                                        bottom='0px'

                                        transform='translate(-50%, 0)'
                                        flexDirection='row'
                                        alignItems='center'
                                        justifyContent='space-between'
                                        width='100%'
                                        style={{
                                          opacity: '1',
                                          transform: 'translateY(0)',
                                          transition: 'transform 0.5s ease, opacity 0.5s ease'
                                        }}
                                      >
                                        <Box
                                          bg='white'
                                          width='50%'
                                          height='35px'
                                          borderBottomLeftRadius='10px'
                                          display='flex'
                                          alignItems='center'
                                          justifyContent='center'
                                          cursor='pointer'
                                          _hover={{
                                            bg: '#f0f0f0',
                                          }}
                                          onClick={() => handlePreview(img, backgroundIndex, i)}

                                        >
                                          <span style={{ color: 'black' }}>Preview</span>
                                        </Box>
                                        <Box
                                          bg='#11047a'
                                          width='50%'
                                          height='35px'
                                          borderBottomRightRadius='10px'
                                          display='flex'
                                          alignItems='center'
                                          justifyContent='center'
                                          cursor='pointer'
                                          _hover={{
                                            bg: '#11047ae3',
                                          }}
                                          // onClick={() => handleButtonTwo(id)}
                                          onClick={() => handleBackground(img, i)}
                                        >
                                          <span style={{ color: 'white' }}>{selectedCardIndex === i ? 'Selected' : 'Select'}</span>

                                        </Box>

                                      </Flex>

                                    ) : (
                                      <Flex
                                        position='absolute'
                                        bottom='0'

                                        transform='translate(-50%, 0)'
                                        flexDirection='row'
                                        alignItems='center'
                                        justifyContent='space-between'
                                        width='100%'
                                        style={{
                                          opacity: '0',
                                          transform: 'translateY(20px)',
                                          transition: 'transform 0.5s ease, opacity 0.5s ease'
                                        }}
                                      >
                                        <Box
                                          bg='white'
                                          width='50%'
                                          height='35px'
                                          borderBottomLeftRadius='10px'
                                          display='flex'
                                          alignItems='center'
                                          justifyContent='center'
                                          cursor='pointer'
                                        >
                                          <span style={{ color: 'black' }}>Preview</span>
                                        </Box>
                                        <Box bg='#11047a' width='50%' height='35px' borderBottomRightRadius='10px' display='flex'
                                          alignItems='center'
                                          justifyContent='center'
                                          cursor='pointer'>
                                          {/* <span style={{ color: 'white' }}>{selections[i] ? 'Selected' : 'Select'}</span> */}
                                          <span style={{ color: 'white' }}>{selectedCardIndex === i ? 'Selected' : 'Select'}</span>
                                        </Box>
                                      </Flex>
                                    )}

                                  </Box>
                                  <Flex justifyContent={'space-between'} margin={'10px 0'} flexDirection={'column'}>
                                    <Box>
                                      <Text color={selectedCardIndex === i ? 'white' : 'black'} fontSize={'16px'} fontWeight={'800'} textTransform={'capitalize'}>

                                        {img?.temp.tempTitle}
                                      </Text>
                                    </Box>
                                    <Box mt={2}>
                                      {/* <Text fontSize={'12px'} fontWeight={'800'} color={'#555'}>
                                        Test Title
                                      </Text> */}
                                     
                                      {backgroundIndex === i ? (  <Text
                                        fontSize={'12px'}
                                        fontWeight={'500'}
                                        color={selectedCardIndex === i ? 'white' : 'black'}
                                        maxH={showFullTextStates[i] ? 'none' : '1.5em'} // Limit to one line (adjust height as needed)
                                        overflow={'hidden'}
                                        textOverflow={'ellipsis'}
                                        whiteSpace={'nowrap'}
                                      >  {truncateText(img.temp.tempStoryLine, 60,10)} 
                                       </Text>
                                       ):( '')}
                                     
                                    </Box>
                                    <Flex
                                      justifyContent={'space-between'}
                                      margin={'0'}
                                      flexDirection={'column'}
                                      style={{ opacity: hoveredStates[i] ? 1 : 0, height: hoveredStates[i] ? 'auto' : 0, overflow: 'hidden' }}
                                    >
                                      <Box display={'flex'} alignItems={'flex-end'}>
                                      </Box>
                                      {/**TEXT**/}
                                      {/**TEXT**/}
                                    </Flex>
                                  </Flex>
                                </Card>
                              </Box>
                            ))}
                        </SimpleGrid>
                      </Box>
                    </Box>
                  </Box>
                ) : tab === 2 ? (

                  ///////////////////////Non-Player IMAGE/////////////////////////////////
                  <>
                    {preview && <CharacterPreview players={players} setPreview={setPreview} makeInputFiled={makeInputFiled} onClose={onClose} values={values} setValues={setValues} previewId={previewId} setFormData={setFormData} formData={formData} commonNextFunction={commonNextFunction} />}

                    <Box className='character-step' display={{ base: 'block', md: 'flex', lg: 'flex' }}>
                      <Box className='character-img-list' width={'100%'}>
                        <Box display={'flex'} flexDir={'column'} justifyContent={'start'} alignItems={'start'}>
                          <Text fontSize={'20px'} fontWeight={800} m={'10px 10px 10px 20px'}>Non-Playing Character</Text>
                          {/* <Text fontSize={'14px'} fontWeight={500} m={'0px 10px 20px 20px'} color={'#8b8b8bd9'} letterSpacing={'0.5px'}>Here is the Non-Playing Character from which you can choose any one</Text>                      */}
                        </Box>
                        <Divider mb={'0px'} />
                        <Box height={'700px'} overflowY={'auto'} borderRadius={'70px'} padding={'30px 0'}>
                          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
                            {players &&
                              players.map((player, i) => (
                                <GameCard
                                  name={player.gasAssetName}
                                  author={''}
                                  // image={game.gameBackgroundId && game?.image.gasAssetImage}
                                  image={player.gasId && player?.gasAssetImage}
                                  tabState={'charater'}
                                  id={player.gasId}
                                  handleButtonOne={playerPerview}
                                  handleButtonTwo={makeInputFiled}
                                  handelDuplicate={setFormData}
                                  handelLaunch={''}
                                  handelAssign={formData}
                                  handelMakePublic={''}
                                  handelDelete={''}
                                />

                              ))}
                          </SimpleGrid>
                        </Box>
                      </Box>
                      <Box width={'1px'} background={'#dddddd87'} marginInline={'20px'} display={'flex'}></Box>

                    </Box>
                  </>

                ) : tab === 3 ? (
                  <>
                    <AboutStory
                      setCat={setCat}
                      setFormData={setFormData}
                      setTags={setTags}
                      formData={formData}
                      handleChange={handleChange}
                      id={id}
                    />
                  </>
                ) : tab === 4 ? (
                  <>
                    <Customization />
                  </>
                ) : tab === 5 ? (
                  <>

                    <AddScores
                      reflection={reflection}
                      setReflection={setReflection}
                      setBadge={setBadge}
                      formData={formData}
                      inputRef={inputRef}
                      handleChange={handleChange}
                      updateHandleIntroMusic={handleIntroMusic}
                      setFormData={setFormData}
                      setTab={setTab}
                      onOpen={onOpen}
                      isOpen={isOpen}
                      onClose={onClose}
                      cancelRef={cancelRef}
                      productTab={productTab} mediaTab={mediaTab} pricingTab={pricingTab} takeawayTab={takeawayTab} welcomeTab={welcomeTab} thankyouTab={thankyouTab}
                    />
                  </>
                ) : tab === 6 ? (
                  <>
                    <GreetingsForm
                      formData={formData}
                      handleChange={handleChange}
                      updateSummaryState={handleSummaryState}
                      updateLanguage={handleLanguageChange}
                      updateImageBackGround={handleBackGroundImage}
                      setFormData={setFormData}
                      setSentAud={setSentAud}
                    />
                  </>
                ) : tab === 7 ? (
                  <CompletionScreen
                    formData={formData}
                    handleChange={handleChange}
                    inputRef={inputRef}
                  />
                ) : null}
              </GridItem>
            </Grid>
            <Flex justify="center">
              <Card
                display="flex"
                justifyContent="center"
                w="350px"
                flexDirection="row"
                position={'fixed'}
                boxShadow={'1px 3px 14px #0000'}
                top={'24px'}
                right={'150px'}
                zIndex={99}
                background={'#0000 !important'}
              >
                <Icon
                  as={BsShareFill}
                  color={'#3311db'}
                  mt="5px"
                  cursor={'pointer'}
                  w={'30px'}
                  h={'30px'}
                  mr="10px"
                />
                {tab !== 1 ? (
                  <Button
                    bg="#3311db"
                    _hover={{ bg: '#3311db' }}
                    color="#fff"
                    w="80px"
                    mr="10px"
                  >
                    Preview
                  </Button>
                ) : null}
                {/* {tab <= 1 ? null : (
                  <Button
                    bg={'#f4f7fe'}
                    color={'#000'}
                    _hover={{ bg: '#e9edf7' }}
                    w="80px"
                    mr="10px"
                    onClick={() => setTab(tab - 1)}
                  >
                    Back
                  </Button>
                )} */}
                {/* navin 15-12 */}
                {tab === 5 ? (<Button
                  bg="#3311db"
                  _hover={{ bg: '#3311db' }}
                  color="#fff"
                  w="80px"
                  onClick={() => handleButtonClick(showFunction)}
                >
                  Next
                </Button>) : (
                  <Button
                    bg="#3311db"
                    _hover={{ bg: '#3311db' }}
                    color="#fff"
                    w="80px"
                    onClick={commonNextFunction}
                  >
                    {tab === 7 ? 'Launch' : 'Next'}
                  </Button>)}
                {/* navin */}
              </Card>
            </Flex>
          </Box>
        </GridItem>
      </Grid>
    </>
  );
};

export default GameCreation;
