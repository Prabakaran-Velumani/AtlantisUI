import { Box, Button, FormControl, FormLabel, Grid, GridItem, Icon, Img, SimpleGrid, Text, useColorModeValue, useDisclosure,Flex,TagLabel,Tag,TagCloseButton,Input } from "@chakra-ui/react"
import InputField from "components/fields/InputField"
import TextField from "components/fields/TextField"
import React, { useEffect, useState } from "react"
import Card from 'components/card/Card'
import TagsField from "components/fields/TagsField"
import { MdAdd, MdAddCircle } from "react-icons/md"
import AddCourse from "./AddCourse"
import narrator from 'assets/img/games/meeting_room.png';
import back from 'assets/img/games/narrator.png';
import { getSkills,getDefaultCat,getDefaultSkill } from "utils/game/gameService"
import { useParams } from "react-router-dom"
 

const AboutStory : React.FC<{handleChange:(e:any)=>void,formData:any,setTags:any,setFormData:any,setCat:any,id:any}>= ({handleChange,formData,setTags,setFormData,setCat,id}) => {

  //navin 16-12
  const [openCourse,setOpenCourse] = useState(false),
        [defaultskills,setDefaultSkills] = useState([]),
        [defaultCat,setDefaultCat] = useState([]),
        [skills,setSkills] = useState([]),
        [Catgory,setCatgory] = useState([]),
      
        [apiSkill,setApiSkill] = useState([]),
        [apiCat,setApiCat] = useState([
          {
            name: 'War',
            id: 1,
            
          },
        ]);
        const fetchDefaultSkill = async () =>{
          setDefaultSkills([]);
          const result = await getDefaultSkill(id);
          if(result?.status !== 'Success') return console.log('getSkills Error :',result?.error)
          setDefaultSkills(result?.data);
        }
        const fetchDefaultcat = async () =>{
          setDefaultCat([]);
          const result = await getDefaultCat(id);
          if(result?.status !== 'Success') return console.log('getSkills Error :',result?.error)
          setDefaultCat(result?.data);
        }
       
        useEffect(()=>{
          setFormData((prev:any) => ({
            ...prev,
            gameSkills: defaultskills,
    
          }));
        },[defaultskills])
        useEffect(()=>{
          setFormData((prev:any) => ({
            ...prev,
            gameCategoryId: defaultCat,
           
    
          }));
        },[defaultCat])
        useEffect(() => {
          if (formData.gameCategoryId) {
            try {
              const categoryArray = formData.gameCategoryId;
              console.log(categoryArray);
              // Now, categoryArray is an array of objects
            } catch (error) {
              console.error('Error parsing gameCategoryId:', error);
            }
          }
        }, []);

        useEffect(() => {
          if (formData.gameSkills) {
            try {
              const gameSkillsArray = JSON.parse(formData.gameSkills);
              console.log('gameSkillsArray',gameSkillsArray);
              const categoryArray = formData.gameCategoryId;
    console.log(categoryArray);
              // Now, categoryArray is an array of objects
            } catch (error) {
              console.error('Error parsing gameCategoryId:', error);
            }
          }
        }, []);
   

        // console.log('skill,cat',formData.gameSkills,formData.gameCategoryId)
        useEffect(()=>{
          fetchDefaultSkill();
        },[])
        useEffect(()=>{
          fetchDefaultcat();
        },[])
        console.log('defaultCat',defaultCat);
        let borderColor = useColorModeValue('secondaryGray.100', 'whiteAlpha.100');
	let bg = useColorModeValue('brand.500', 'brand.400');

  const keyPress = (e: any) => {
		if (e.keyCode === 13) {
			setDefaultCat([
				...defaultCat,
				{
					catName: e.target.value,
					catId: defaultCat.length === 0 ? 1 : defaultCat[defaultCat.length - 1].catId + 1
				}
			]);
			e.target.value = '';
		}
	};
  const keyPressSkill = (e: any) => {
		if (e.keyCode === 13) {
			setDefaultSkills([
				...defaultskills,
				{
					crSkillName: e.target.value,
					crSkillId: defaultskills.length === 0 ? 1 : defaultskills[defaultskills.length - 1].crSkillId + 1
				}
			]);
			e.target.value = '';
		}
	};
   //navin 16-12
  const iconColor = useColorModeValue('brand.500', 'white');
  const bgButton = useColorModeValue('secondaryGray.300', 'whiteAlpha.100');
  const textColorPrimary = useColorModeValue('secondaryGray.900', 'white');
  const bgHover = useColorModeValue(
    { bg: 'secondaryGray.400' },
    { bg: 'whiteAlpha.50' },
  );
  const bgFocus = useColorModeValue(
    { bg: 'secondaryGray.400' },
    { bg: 'whiteAlpha.100' },
  );
   let previousLength = 0;
  const handleInput = (event:any) => {
    const bullet = "\u2022";
    const newLength = event.target.value.length;
    const characterCode = event.target.value.substr(-1).charCodeAt(0);    
    if (newLength > previousLength) {
      if (characterCode === 10) {
        event.target.value = `${event.target.value}${bullet} `;
      } else if (newLength === 1) {
        event.target.value = `${bullet} ${event.target.value}`;
      }
    }
    setFormData((prev:any)=>({...prev,gameLearningOutcome:event.target.value}))
    previousLength = newLength;
  }

  const fetch = async () =>{
    const result = await getSkills();
    if(result?.status !== 'Success') return console.log('getSkills Error :',result?.error)
    setApiSkill(result?.data);
  }
  useEffect(()=>{
    fetch()
  },[])
  const handleSkillsChange = (updatedSkills:any) => {
    setSkills(updatedSkills);
  };
  const { isOpen, onOpen, onClose } = useDisclosure();


    return (
      <>
        <Card mb={{ base: '0px', xl: '20px', sm: '20px' }}>
          <Text fontSize={20} fontWeight={800} mb={'20px'}>
            Game Overview
          </Text>
          <Box>
            <SimpleGrid columns={{ base: 1, md: 1 }}>
              <InputField
                mb="0px"
                me="30px"
                id="title"
                label="Title"
                placeholder="eg. Oliver"
                name="gameTitle"
                value={formData?.gameTitle}
                onChange={handleChange}
                isRequired
              />
            </SimpleGrid>
            <SimpleGrid columns={{ base: 1, md: 2 }} gap={6} mt={'20px'}>
              
              <TextField
                me="30px"
                mb="0px"
                id="storyline"
                label="Story Line"
                placeholder="eg. Fight Me"
                name="gameStoryLine"
                value={formData?.gameStoryLine}
                onChange={handleChange}
                isRequired
              />
              <TextField
                mb="0px"
                me="30px"
                id="learningOutcome"
                label="Learning Outcome"
                placeholder="eg. Oliver"
                name="gameLearningOutcome"
                value={formData?.gameLearningOutcome}
                onChange={handleInput}
              />
                {/* navin 16-12 */}
              <Box>
                <FormControl>
                <Box>
			<FormLabel  fontWeight='bold' fontSize='sm' mb='8px'>
      Category<Text as='span' color='red.500'>*</Text>
			</FormLabel>
			<Flex
				direction='row'
				p='12px'
				wrap='wrap'
				bg='transparent'
				border='1px solid'
				borderColor={borderColor}
				borderRadius='16px'
				_focus={{ borderColor: 'teal.300' }}
				minH='30px'
				h='stretch'
				cursor='text'
				>
				{defaultCat.map((tag, index) => {
          
					return (
						<Tag
							fontSize='xs'
							h='25px'
							mb='6px'
							me='6px'
							borderRadius='12px'
							variant='solid'
							bg={bg}
							key={index}>
							<TagLabel w='100%'>{tag.catName}</TagLabel>
							<TagCloseButton
								justifySelf='flex-end'
								color='white'
								onClick={() => {
                  // Assuming tag.catName is the id to be removed
                  const updatedDefaultCat = defaultCat.filter((element) => element.catId !== tag.catId);
                  console.log('updatedDefaultCat',updatedDefaultCat);
                  setDefaultCat(updatedDefaultCat);
                }}
							/>
						</Tag>
					);
              
				})}
				<Input
					variant='main'
					bg='transparent'
					border='none'
					p='0px'
					onKeyDown={(e) => keyPress(e)}
					fontSize='sm'
				/>
			</Flex>
		</Box>
                </FormControl>
              </Box>

              
  
              <FormControl>
              <Box>
			<FormLabel  fontWeight='bold' fontSize='sm' mb='8px'>
      Skill<Text as='span' color='red.500'>*</Text>
			</FormLabel>
			<Flex
				direction='row'
				p='12px'
				wrap='wrap'
				bg='transparent'
				border='1px solid'
				borderColor={borderColor}
				borderRadius='16px'
				_focus={{ borderColor: 'teal.300' }}
				minH='30px'
				h='stretch'
				cursor='text'
				>
				{defaultskills.map((tag, index) => {
					return (
						<Tag
							fontSize='xs'
							h='25px'
							mb='6px'
							me='6px'
							borderRadius='12px'
							variant='solid'
							bg={bg}
							key={index}>
							<TagLabel w='100%'>{tag.crSkillName}</TagLabel>
							<TagCloseButton
								justifySelf='flex-end'
								color='white'
								onClick={() => {
                  // Assuming tag.catName is the id to be removed
                  const updatedDefaultSkill = defaultskills.filter((element) => element.crSkillId !== tag.crSkillId);
                  console.log('updatedDefaultCat',updatedDefaultSkill);
                  setDefaultSkills(updatedDefaultSkill);
                }}
							/>
						</Tag>
					);
				})}
				<Input
					variant='main'
					bg='transparent'
					border='none'
					p='0px'
					onKeyDown={(e) => keyPressSkill(e)}
					fontSize='sm'
				/>
			</Flex>
		</Box>
              </FormControl> 
            </SimpleGrid>
            <SimpleGrid columns={{ base: 1, md: 1 }} mt={'20px'}>
              <InputField
                mb="0px"
                me="30px"
                id="author"
                label="Author"
                placeholder="eg. Admin"
                name="gameAuthorName"
                value={formData?.gameAuthorName}
                onChange={handleChange}
              />
            </SimpleGrid>
          
          </Box>
        </Card>
        {openCourse ? <AddCourse setOpenCourse={setOpenCourse} isOpen={isOpen} onClose={onClose} onOpen={onOpen}/> : null}
      </>
    );
}
export default AboutStory;