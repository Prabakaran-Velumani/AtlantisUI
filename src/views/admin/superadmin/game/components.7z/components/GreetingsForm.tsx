import {
  Box,
  Button,
  Flex,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  Img,
  SimpleGrid,
  Step,
  Stepper,
  StepIndicator,
  Text,
  Tooltip,
  StepNumber,
  StepIcon,
  StepStatus,
  StepSeparator,
  StepTitle,
  TabPanels,
  Tab,
  Tabs,
  TabList,
  useColorModeValue,
  TabPanel,
  RadioGroup,
  Stack,
  Radio,
  Icon,
  useToast,
} from '@chakra-ui/react';
import React, { ChangeEvent, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from 'components/card/Card';
import InputField from 'components/fields/InputField';
import TextField from 'components/fields/TextField';
import SelectField from 'components/fields/SelectField';
import { Switch } from '@chakra-ui/react';
import logo from 'assets/img/games/log.png';
import badge from 'assets/img/games/new-level-final.png';
import { getImages } from 'utils/game/gameService';
import Dropzone from 'views/admin/main/ecommerce/settingsProduct/components/Dropzone';
import { MdClose, MdOutlineCloudUpload } from 'react-icons/md';

interface OptionType {
  value: string;
  label: string;
}

const GreetingsForm: React.FC<{
  handleChange: (e: any, selectedOption?: OptionType) => void;
  formData: any;
  updateSummaryState: (isOpen: any) => void;
  updateLanguage: (selectedOption: OptionType | null) => void;
  updateImageBackGround: (e: any) => void;
  setFormData: any;
  setSentAud:any;
}> = ({
  handleChange,
  formData,
  updateSummaryState,
  updateLanguage,
  updateImageBackGround,
  setFormData,
  setSentAud,
}) => {
    const [isOpenSummary, setIsOpenSummary] = useState<any>(false);
    const [tab, setTab] = useState<number>(1);
    const [img, setImg] = useState<any[]>([]);
    let [tabState, setTabState] = useState('Creation');
    const [selectedAud, setSelectedAud] = useState(null);
    const [backgroundIndex, setBackgroundIndex] = useState<number>();
    const languageOptions = [
      {
        value: '1',
        label: 'English',
      },
      {
        value: '2',
        label: 'Italy',
      },
    ];
    const toast = useToast()
    const mappedlanguageOptions = Array.isArray(languageOptions)
      ? languageOptions.map((language) => ({
        value: language.value,
        label: language.label,
      }))
      : [];
    const options = [
      { value: 'Each', name: 'Immediately After Each Interaction' },
      { value: 'Completion', name: ' Together After Completion Screen' },
    ];
    const steps = [
      { title: 'BackGround' },
      { title: 'Non Playing Charater' },
      { title: 'About Story' },
      { title: 'Customzation' },
      { title: 'Score' },
      { title: 'Summaries' },
      { title: 'Endpage' },
    ];
    const textColorPrimary = useColorModeValue('secondaryGray.900', 'white');
    const textColor = useColorModeValue('secondaryGray.900', 'white');
    const navigate = useNavigate();

    const handleSummary = () => {
      setIsOpenSummary(!isOpenSummary);
      updateSummaryState(!isOpenSummary);
    };
    const fetchData = async () => {
      const result = await getImages(5);
      if (result?.status !== 'Success')
        return alert('getbackruond error:' + result?.message);
      setImg(result?.data);
    };
    const handleSetBackground = (i: any) => {
      setBackgroundIndex(i);
      // setFormData((prev:any) => ({
      //   ...prev,
      //   gameReflectionpageBackground:i
      // }));
    };

    useEffect(() => {
      fetchData();
      console.log('formData', formData);
    }, [backgroundIndex]);

    const handleChan = (e: any) => {
      setFormData((prev: any) => ({ ...prev, gameIsShowInteractionFeedBack: e }))
    }
    const handleAud = (e: any) => {
      e.preventDefault();
      let selectedFile;
      if (e.target.files) {
        selectedFile = e.target.files[0];
      }
      else if (e.dataTransfer && e.dataTransfer.files) {
        selectedFile = e.dataTransfer.files[0];
      }
      if (selectedFile) {
        setSentAud(selectedFile);
        const reader = new FileReader();
        reader.onload = () => {
          setSelectedAud(reader.result);
        };
        reader.readAsDataURL(selectedFile);
      }
    }
    return (
      <>
        <Box className="greeting-form" mt={{ base: '135px', xl: '20px' }}>
          <Card w={'100%'} alignItems={'center'}>
            <Tabs width={'90%'}>
              <TabList>
                <Tab>Preferences</Tab>
                <Tab>Translations</Tab>
              </TabList>
              <TabPanels>
                <TabPanel>
                  <Box w={'65%'}>
                    <SimpleGrid
                      columns={{ sm: 1, md: 1, xl: 1 }}
                      spacing={{ base: '20px', xl: '20px' }}
                    >
                      <FormControl mt="20px">
                        <FormLabel
                          htmlFor="alerts"
                          mb="0"
                          fontSize="sm"
                          fontWeight="bold"
                          color={textColorPrimary}
                          mr="2"
                        >
                          Show Interaction Feedback
                        </FormLabel>
                        <RadioGroup
                          name="gameIsShowInteractionFeedBack"
                          id="alerts"
                          onChange={handleChan}
                        // value={chosen}
                        >
                          <Stack direction="row" spacing={5}>
                            {options.map((option) => (
                              <Radio
                                key={option?.value}
                                value={option?.value}
                                colorScheme="green"
                              >
                                {option?.name}
                              </Radio>
                            ))}
                          </Stack>
                        </RadioGroup>
                      </FormControl>
                      <FormControl
                        display="flex"
                        alignItems="center"
                        justifyContent={'space-between'}
                        mt={'20px'}
                      >
                        <FormLabel
                          htmlFor="summaryScreen"
                          fontSize="sm"
                          fontWeight="bold"
                          color={textColorPrimary}
                          mr="2"
                        >
                          Shuffle option
                        </FormLabel>
                        <Switch
                          id="gameShuffle"
                          name="gameShuffle"
                          colorScheme={'brandScheme'}
                          onChange={handleChange}
                        />
                      </FormControl>
                      <FormControl
                        display="flex"
                        alignItems="center"
                        justifyContent={'space-between'}
                        mt={'20px'}
                      >
                        <FormLabel
                          htmlFor="summaryScreen"
                          fontSize="sm"
                          fontWeight="bold"
                          color={textColorPrimary}
                          mr="2"
                        >
                          Disable optional replays
                        </FormLabel>
                        <Switch
                          id="gameDisableOptionalReplays"
                          name="gameDisableOptionalReplays"
                          colorScheme={'brandScheme'}
                          onChange={handleChange}
                        />
                      </FormControl>
                      <Flex alignItems="center" justifyContent={'space-between'}>
                        <Text
                          fontSize="sm"
                          fontWeight="bold"
                          color={textColorPrimary}
                          mb="10px"
                          mr="45px"
                        >
                          Change introductory music
                        </Text>
                        <Flex alignItems="center">

                          <Text
                            fontSize="sm"
                            fontWeight="bold"
                            color={textColorPrimary}
                            mb="10px"
                            mr="45px"
                          >
                            Select Music
                          </Text>
                          {!selectedAud ?
                            <Dropzone
                              accept='.mp3'
                              onChange={handleAud}
                              onDrop={handleAud}
                              content={
                                <Box maxW="100%" textAlign="center">
                                  <Icon
                                    as={MdOutlineCloudUpload}
                                    w="30px"
                                    h="30px"
                                    color={textColor}
                                  />
                                </Box>
                              }
                              style={{
                                border: '2px dashed #A0AEC0',
                                borderRadius: '4px',
                                width: '140px',
                                height: '50px',
                              }}
                            /> :
                            <>
                            <audio controls>
                              <source src={selectedAud} type="audio/mpeg" />
                              Your browser does not support the audio element.
                            </audio>
                            <Icon ml={'10px'} as={MdClose} borderRadius={'50%'} bg={'#e2e8f0'} w={'30px'} h={'30px'} cursor={'pointer'} onClick={()=>setSelectedAud(null)}/>
                            </>
                            }
                        </Flex>
                      </Flex>
                      <FormControl
                        display="flex"
                        alignItems="center"
                        justifyContent={'space-between'}
                        mt={'20px'}
                      >
                        <FormLabel
                          htmlFor="summaryScreen"
                          fontSize="sm"
                          fontWeight="bold"
                          color={textColorPrimary}
                          mr="2"
                        >
                          Track Question Wise Answers
                        </FormLabel>
                        <Switch
                          id="gameTrackQuestionWiseAnswers"
                          name="gameTrackQuestionWiseAnswers"
                          colorScheme={'brandScheme'}
                          onChange={handleChange}
                        />
                      </FormControl>
                      <FormControl
                        display="flex"
                        alignItems="center"
                        justifyContent={'space-between'}
                        mt={'20px'}
                      >
                        <FormLabel
                          htmlFor="summaryScreen"
                          fontSize="sm"
                          fontWeight="bold"
                          color={textColorPrimary}
                          mr="2"
                        >
                          Disable Learner Email Notifications
                        </FormLabel>
                        <Switch
                          id="gameDisableLearnerMailNotifications"
                          name="gameDisableLearnerMailNotifications"
                          colorScheme={'brandScheme'}
                          onChange={handleChange}
                        />
                      </FormControl>
                    </SimpleGrid>
                  </Box>
                </TabPanel>
                <TabPanel bg={'yellow'}>
                  <Text>Translations Pending...!</Text>
                </TabPanel>
              </TabPanels>
            </Tabs>
          </Card>
          {/* <Card>
          <Flex gridArea='1 / 1 / 2 / 2' display={{ base: 'block', lg: 'flex' }}>
            <Tabs variant='soft-rounded' colorScheme='brandTabs'>
              <TabList mx={{ base: '10px', lg: '30px' }} overflowX={{ sm: 'scroll', lg: 'unset' }}>
                <Flex>
                  <Tab>
                    <Flex align='center'>
                      <Text color={textColor} fontSize='lg' fontWeight='500' me='12px'>
                        Preferences
                      </Text>
                    
                    </Flex>
                    <Box
                      height='4px'
                      w='100%'
                      transition='0.1s linear'
                      bg={tabState === 'Creation' ? 'brand.500' : 'transparent'}
                      mt='15px'
                      borderRadius='30px'
                    />
                  </Tab>
                  <Tab
                    onClick={function () {
                      setTabState('Review');
                    }}
                    pb='0px'
                    me='10px'
                    bg='unset'
                    _selected={{
                      bg: 'none'
                    }}
                    _focus={{ border: 'none' }}
                    minW='max-content'
                    flexDirection='column'>
                    <Flex align='center'>
                      <Text color={textColor} fontSize='lg' fontWeight='500' me='12px'>
                        Translation
                      </Text>
                    </Flex>
                    <Box
                      height='4px'
                      w='100%'
                      transition='0.1s linear'
                      bg={tabState === 'Review' ? 'brand.500' : 'transparent'}
                      mt='15px'
                      borderRadius='30px'
                    />
                  </Tab>
                </Flex>
              </TabList>
              <TabPanels maxW={{ md: '90%', lg: '100%' }} mx="auto">
                <TabPanel>
                 
                </TabPanel>
              </TabPanels>
              </Tabs>
           </Flex>
              </Card> */}
          {/* <Flex mb={'30px'} flexDirection={{sm: 'column', md:'column', xl:'row'}}>          
            <Box display={'flex'} flexDirection={'column'} width={{sm: '100%',xl:'100%'}}>
                <Box display={'flex'} flexDirection={{sm: 'column-reverse', md:'row', xl:'row'}} mb={'20px'}>
                    <Card width={{sm: '100%', md:'60%', xl:'60%'}} mr={'30px'}>
                        <Text fontSize={20} fontWeight={800} mb={'20px'}>
                            Preferences
                         </Text>
                        <SimpleGrid columns={{ sm: 1, md: 1, xl: 2 }} spacing={{ base: '20px', xl: '20px' }}>
                            { isOpenSummary ? 
                            <TextField
                                mb="0px"
                                me="30px"
                                name="gameSummarizes"                   
                                label="Summary"
                                placeholder="eg. Summary"
                                isRequired={true}
                                value={formData?.gameSummarizes}
                                onChange={handleChange}
                            /> : null }                            
                            <TextField
                                mb="0px"
                                me="30px"
                                name="gamWelcomePageText"                   
                                label="Welcome Page"
                                placeholder="eg. Welcome Page"
                                isRequired={true}
                                value={formData?.gamWelcomePageText}
                                onChange={handleChange}
                            />
                            <TextField
                                mb="0px"
                                me="30px"
                                name="gameThankYouPage"                   
                                label="Thankyou Page"
                                placeholder="eg. Thankyou Page"
                                isRequired={true}
                                value={formData?.gameThankYouPage}
                                onChange={handleChange}
                            />                          
                            <TextField
                                mb="0px"
                                me="30px"
                                name="gameScormVersion"                   
                                label="Scorm Version"
                                placeholder="eg. 2.0"
                                isRequired={true}
                                value={formData?.gameScormVersion}
                                onChange={handleChange}
                            />
                            <SelectField
                                mb="0px"
                                me="30px"
                                label="Language"
                                name="gameLanguageId"
                                options={mappedlanguageOptions}
                                value={
                                    mappedlanguageOptions.find(
                                      (option) => option.value === formData?.gameLanguageId,
                                    ) || null
                                  }
                                onChange={updateLanguage}
                                                  
                            />
                        </SimpleGrid>
                    </Card>
                    <Card width={{sm: '100%', md: '40%', xl:'40%'}} mb={{sm: '30px', md: '30px', xl: '0'}} className='for-switch' alignItems={'stretch'}>                
                        <SimpleGrid columns={{ sm: 1, md: 1 }} spacing={{ base: '40px', xl: '60px' }} >
                            <FormControl display='flex' alignItems='center' justifyContent={'space-between'}>
                                <FormLabel htmlFor='summaryScreen' mb='0'>
                                    Summary Screen
                                </FormLabel>
                                <Switch id='gameSummaryScreen' name='gameSummaryScreen' colorScheme={'brandScheme'} onChange={handleSummary} />
                            </FormControl>
                            <FormControl display='flex' alignItems='center'  justifyContent={'space-between'}>
                                <FormLabel htmlFor='launchPlatform' mb='0'>
                                    Launched within Platform
                                </FormLabel>
                                <Switch id='gameLaunchedWithinPlatform' name='gameLaunchedWithinPlatform' value={1} onChange={handleChange} colorScheme={'brandScheme'} />
                            </FormControl>
                            <FormControl display='flex'  onChange={handleChange} alignItems='center'  justifyContent={'space-between'}>
                                <FormLabel htmlFor='downloadScorm' mb='0'>
                                    Downloaded as Scorm
                                </FormLabel>
                                <Switch id='gameDownloadedAsScorm' name='gameDownloadedAsScorm' onChange={handleChange} value={1} colorScheme={'brandScheme'} />
                            </FormControl>
                            <FormControl display='flex' alignItems='center'  justifyContent={'space-between'}>
                                <FormLabel htmlFor='defaultFeedback' mb='0'>
                                    Default Feedback Form
                                </FormLabel>
                                <Switch id='gameDefaultFeedbackForm' name='gameDefaultFeedbackForm'  onChange={handleChange} colorScheme={'brandScheme'} />
                            </FormControl>
                        </SimpleGrid>
                    </Card>
                </Box>
                <Box>
                    <Card>
                        <Text fontSize={18} fontWeight={800} mb={'20px'} >Welcome Page Background</Text>
                        <Flex overflowX={'auto'} width={'100%'} pb={'20px'}>       
                        {img &&
                        img.map((img, i) => (                                                  
                                
                                    <Img src={img?.gasAssetImage} h={'80px'} w={'80px'} mr={20} borderRadius={'8px'} boxShadow={'6px 5px 6px #4a4844ad'}   id={i.toString()} onClick={(e) => updateImageBackGround(e)}/>
                                  
                              
                                  ))}                            
                                                               
                        </Flex>
                    </Card>
                </Box>
            </Box>                       
        </Flex>            */}
        </Box>
      </>
    );
  };

export default GreetingsForm;
