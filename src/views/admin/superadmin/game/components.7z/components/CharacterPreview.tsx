import React from 'react';
import {
  Button,
  Box,
  Flex,
  Image,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Select,
  FormControl,
  FormLabel,
  ChakraProvider, CSSReset
} from '@chakra-ui/react';
import InputField from 'components/fields/InputField';

const CharacterPreview: React.FC<{
  players?: any;
  setPreview?: any;
  makeInputFiled?: any;
  onClose?: any;
  values?: any;
  setValues?: any;
  previewId?: any;
  setFormData?: any;
  formData?: any;
  commonNextFunction?: any;
}> = ({
  players,
  setPreview,
  makeInputFiled,
  onClose,
  values,
  setValues,
  previewId,
  setFormData,
  formData,
  commonNextFunction,
}) => {
  const textContent =
    'Game Content means any templates, modules, functions, features, images, audio data, video data, or other content that may be used by a Game Creator when creating a Game.';
  const truncatedText = textContent.slice(0, 80) + '...';

  const selectedPlayer = players.find((player: any) => player.gasId === previewId);

  const handleNonPlayerVoice: React.ChangeEventHandler<HTMLSelectElement> = (e) => {
    setFormData((prev: any) => ({
      ...prev,
      gameNonPlayerVoice: e.target.value || '',
    }));
  };

  const handlePlayerMale: React.ChangeEventHandler<HTMLSelectElement> = (e) => {
    setFormData((prev: any) => ({
      ...prev,
      gamePlayerMaleVoice: e.target.value || '',
    }));
  };

  const handlePlayerFemale: React.ChangeEventHandler<HTMLSelectElement> = (e) => {
    setFormData((prev: any) => ({
      ...prev,
      gamePlayerFemaleVoice: e.target.value || '',
    }));
  };

  const handleNarrator: React.ChangeEventHandler<HTMLSelectElement> = (e) => {
    setFormData((prev: any) => ({
      ...prev,
      gameNarratorVoice: e.target.value || '',
    }));
  };

  const handleChange: React.ChangeEventHandler<HTMLSelectElement> = (e) => {
    setFormData((prev: any) => ({
      ...prev,
      gameNonPlayerName: e.target.value || '',
    }));
  };

  return (
    <>
   
      
      
      <Modal isOpen={setPreview} onClose={setPreview} size="lg">
        <ModalOverlay  />
        <ModalContent maxW="1150px" height="750px" position="fixed" overflowY="auto">
          <ModalHeader p={2}>Preview</ModalHeader>
          <ModalCloseButton />
          <ModalBody p={0}>
            {formData.gameNonPlayingCharacterId === previewId ? (
              <Flex flexDirection={{ base: 'column', md: 'row' }}>
                <Box flex="1" p={4}>
                  <Image src={selectedPlayer.gasAssetImage} alt="Your Image" maxH="600px" w="100%" mb="4" />
                </Box>
                <Box flex="1" p={4}>
                  <FormControl mb={{ base: '4', md: '8' }}>
                    <FormLabel htmlFor="title">Non-Player Name</FormLabel>
                    <InputField
                      id="title"
                      placeholder="eg. Oliver"
                      name="gameTitle"
                      value={formData.gameNonPlayerName ?? selectedPlayer.gasAssetName}
                      onChange={handleChange}
                      w="100%"
                    />
                  </FormControl>
                  <FormControl mb={{ base: '4', md: '8' }}>
                    <FormLabel htmlFor="nonPlayerVoice">Non-Player Voice</FormLabel>
                    <Select
                      id="nonPlayerVoice"
                      variant="main"
                      onChange={handleNonPlayerVoice}
                      value={formData.gameNonPlayerVoice}
                    >
                      <option value="">Select...</option>
                      <option value="1">Adam</option>
                      <option value="2">Charlie</option>
                      <option value="3">Freya</option>
                      <option value="4">Domi</option>
                    </Select>
                  </FormControl>
                  <Flex justifyContent="space-between" mb={{ base: '4', md: '8' }}>
                    <FormControl flexBasis={{ base: '100%', md: '48%' }} marginRight={{ md: '4' }}>
                      <FormLabel htmlFor="playerMaleVoice">Player Male Voice</FormLabel>
                      <Select
                        id="playerMaleVoice"
                        variant="main"
                        onChange={handlePlayerMale}
                        value={formData.gamePlayerMaleVoice}
                      >
                        <option value="">Select...</option>
                        <option value="1">Adam</option>
                        <option value="2">Charlie</option>
                        <option value="3">Freya</option>
                        <option value="4">Domi</option>
                      </Select>
                    </FormControl>
                    <FormControl flexBasis={{ base: '100%', md: '48%' }}>
                      <FormLabel htmlFor="playerFemaleVoice">Player Female Voice</FormLabel>
                      <Select
                        id="playerFemaleVoice"
                        variant="main"
                        onChange={handlePlayerFemale}
                        value={formData.gamePlayerFemaleVoice}
                      >
                        <option value="">Select...</option>
                        <option value="1">Adam</option>
                        <option value="2">Charlie</option>
                        <option value="3">Freya</option>
                        <option value="4">Domi</option>
                      </Select>
                    </FormControl>
                  </Flex>
                  <FormControl mb={{ base: '4', md: '8' }}>
                    <FormLabel htmlFor="narratorVoice">Narrator Voice</FormLabel>
                    <Select
                      marginTop={{ base: '4', md: '0' }}
                      id="narratorVoice"
                      variant="main"
                      onChange={handleNarrator}
                      value={formData.gameNarratorVoice}
                    >
                      <option value="">Select...</option>
                      <option value="1">Adam</option>
                      <option value="2">Charlie</option>
                      <option value="3">Freya</option>
                      <option value="4">Domi</option>
                    </Select>
                  </FormControl>
                  <Button
                    bg="#3311db"
                    _hover={{ bg: '#3311db' }}
                    color="#fff"
                    w="100%"
                    onClick={commonNextFunction}
                  >
                    Submit
                  </Button>
                </Box>
              </Flex>
            ) : (
              <Flex justifyContent="space-between" alignItems="center" flexDirection="column" h="100%">
                <Image src={selectedPlayer?.gasAssetImage} alt="Your Image" maxH="600px" w="50%" mb="4" />
              </Flex>
            )}
          </ModalBody>
          <ModalFooter></ModalFooter>
        </ModalContent>
      </Modal>
     
      
    </>
  );
};

export default CharacterPreview;
