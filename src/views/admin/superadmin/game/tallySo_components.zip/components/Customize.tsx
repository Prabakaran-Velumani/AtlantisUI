import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import CustomList from './NDI_Main';
import Note from './NoteForm';
import Dialog from './DialogForm';
import Interaction from './InteractionForm';

const Customize = () => {
  const [showComponent, setComponent] = useState('CustomList');
  const navigate = useNavigate();

  const handleShowComponent = (componentName:string) => {
    setComponent(componentName);
  }; 

  return (
    <>
      {showComponent === 'CustomList' && <CustomList handleShowComponent={handleShowComponent} />}
      {showComponent === 'Note' && <Note handleShowComponent={handleShowComponent}  />}
      {showComponent === 'Dialog' && <Dialog  handleShowComponent={handleShowComponent} />}
      {showComponent === 'Interaction' && <Interaction handleShowComponent={handleShowComponent} />}
    </>
  );
};

export default Customize;
