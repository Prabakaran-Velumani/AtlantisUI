import React, { ChangeEvent, useEffect, useState } from 'react'
import Card from 'components/card/Card';
import TextField from 'components/fields/TextField';
import { Navigate, useNavigate } from 'react-router-dom';
import {    
    Box,
    Text,   
    Button,
    Icon,
    Flex,   
  } from '@chakra-ui/react'
import { MdAdd, MdArrowDownward, MdArrowDropUp, MdArrowUpward, MdDelete } from 'react-icons/md';
import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';
import { ChevronDownIcon, ChevronUpIcon } from '@chakra-ui/icons';

type ItemType = {
    id: string;
    name: string;
    content: string;
  }; 
  
  interface ChildComponentProps {
    textareaEvent: React.MouseEvent<HTMLTextAreaElement> | null;
  }

  interface CustomAccordionItemProps {
    title: any;   
    inputFld: any
    field: any;
  }

const CustomAccordion = (props: { items: any, setItems: any, field:  any }) => {

    const {items, setItems, field} = props;
    const [inputFld, setInputFld] = useState<any>([]);


    const onDragEnd = (result: DropResult) => {
        if (!result.destination) {
          return;
        }
    
        // const reorderedItems = Array.from(items);
        const reorderedItems: ItemType[] = Array.from(items);
        const [movedItem] = reorderedItems.splice(result.source.index, 1);
        reorderedItems.splice(result.destination.index, 0, movedItem);           

         // Update the id based on the original order        
        const updatedItems = reorderedItems.map((item: ItemType, index) => ({ ...item, id: (index + 1).toString() }));

        
        setItems(updatedItems);    
        console.log('result', updatedItems);
    };    

    useEffect(()=> {
        if(field) {        
            setInputFld((prev: any)=> {
                return [...prev, {
                    name: field?.name,
                    type: field?.type,
                    id: field?.id,
                    value: field?.value,
                }]
            });
            console.log('field', field);
        }
    },[field])
        

    return (
    <Box>
        <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="your-droppable-id">
                {(provided) => (
                    <div {...provided.droppableProps} ref={provided.innerRef}>
                        {/* {items.map((item, index) => (             */}
                        {field && items.map((item:any, index:number) => (
                            <Draggable key={item.id} draggableId={item.id} index={index}>
                                {(provided) => (
                                    <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}                   
                                    >                                      
                                        <CustomAccordionItem key={index} title={item.name} inputFld={inputFld} field={field} />
                                    </div>
                                )}
                                </Draggable>
                            ))}
                        {provided.placeholder}
                    </div>
                )}
            </Droppable>
        </DragDropContext>            
    </Box>
    );
};


const CustomAccordionItem: React.FC<CustomAccordionItemProps> = (props: { title:any, inputFld:any,  field: any }) => {
    const {title,inputFld,  field} = props;
    const [isOpen, setIsOpen] = useState(false);
    

    const toggleAccordion = () => {
        setIsOpen(!isOpen);
    };

   
    console.log('fld', inputFld);

    const handleTextArea = (e: ChangeEvent<HTMLInputElement>) => {
        console.log('event', e.target.value);
    }

    return (       
        <>            
            { field ? 
                inputFld.map((item: any, i: number)=> (
                    <TextField     
                        key={i}               
                        mb="0px"
                        me="30px"
                        w="100%"
                        id={item.id}
                        label={item.name.toUpperCase()}
                        placeholder="eg. Game"
                        name={item.name} 
                        onChange={(e: any)=>handleTextArea(e)}                   
                        // value={inputFld.value}                         
                    />
                ))                    
            : null}
            <Flex flexDirection={'row-reverse'} className='custom-accordion'>
                <Box className='custom-accordionItem' width={'100%'} p={'10px 15px'} ml={'15px'} display={'flex'} justifyContent={'space-between'} alignItems={'center'} 
                    flexDirection={'row'} color={isOpen ? '#000' : '#000'} mb={'10px'}  bg={'#f7f7f7'}                 
                >
                    <Text textAlign="left" fontSize={15} fontWeight={600} letterSpacing={0.4}>{title}</Text>                    
                </Box>
                <Box className='icons' width={'30px'} height={'auto'} display={'flex'}>
                    <Icon as={MdAdd} color={'green'} filter={'drop-shadow(5px 6px 5px green)'} fontSize={'16px'} mb={'4px'} mr={'5px'} onClick={()=>console.log('add')} />
                    <Icon as={MdDelete} color={'red'} filter={'drop-shadow(5px 6px 5px #e5212194)'} mb={'4px'} onClick={()=>console.log('delete')}  />
                </Box>
            </Flex>
        </>
    );
};

export default CustomAccordion