import { Box, SimpleGrid, Text } from "@chakra-ui/react"
import InputField from "components/fields/InputField"
import TextField from "components/fields/TextField"
import React from "react"
import Card from 'components/card/Card'
 

const AboutStory : React.FC<{handleChange:(e:any)=>void,formData:any}>= ({handleChange,formData}) => {
   console.log(formData)
    return (
        <Card mb={{ base: '0px', xl: '20px', sm: '20px' }}>
        <Text fontSize={20} fontWeight={500} mb={'20px'}>
          About Story
        </Text>
        <Box>
          <SimpleGrid
            columns={{ sm: 1, md: 2 }}
            spacing={{ base: '20px', xl: '20px' }}
          >
            <InputField
              mb="0px"
              me="30px"
              id="title"
              label="Title"
              placeholder="eg. Oliver"
              name="gameTitle"
              value={formData?.gameTitle}
              onChange={handleChange}
              isRequired
              // errMsg={inputErr.title}
            />
             <TextField
              mb="0px"
              me="30px"
              id="storyline"
              label="Story Line"
              placeholder="eg. Fight Me"
              name="gameStoryLine"
              value={formData?.gameStoryLine}
              onChange={handleChange}
              isRequired
              
              // errMsg={inputErr.storyline}
            />
          
            <InputField
              mb="0px"
              me="30px"
              id="skills"
              label="Skills"
              placeholder="eg. Technical"
              name="gameSkills"
              value={formData?.gameSkills}
              onChange={handleChange}
            />
            <InputField
              mb="0px"
              me="30px"
              type="time"
              id="duration"
              label="Duration"
              placeholder="eg. 12:10"
              name="gameDuration"
              // value={input.duration}
              onChange={handleChange}
            />
          

            <InputField
              mb="0px"
              me="30px"
              id="author"
              label="Author"
              placeholder="eg. Admin"
              name="gameAuthorName"
              
              value={formData?.gameAuthorName}
              onChange={handleChange}
            />
           
            <TextField
              mb="0px"
              me="30px"
              id="learningOutcome"
              label="Learning Outcome"
              placeholder="eg. Oliver"
              name="gameLearningOutcome"
              value={formData?.gameLearningOutcome}
              onChange={handleChange}
            />
          </SimpleGrid>
        </Box>
      </Card>
    )
}
export default AboutStory;