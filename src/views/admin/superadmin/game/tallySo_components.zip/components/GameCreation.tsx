import {
  Accordion,
  AccordionButton,
  AccordionIcon,
  AccordionItem,
  AccordionPanel,
  Avatar,
  Box,
  Button,
  Divider,
  Flex,
  Grid,
  GridItem,
  Icon,
  Img,
  Input,
  List,
  ListIcon,
  ListItem,
  Progress,
  SimpleGrid,
  Step,
  StepIcon,
  StepIndicator,
  StepNumber,
  StepSeparator,
  StepStatus,
  StepTitle,
  Stepper,
  Text,
  VStack,
  useSteps,
  keyframes,
  useToast,
  Heading
} from '@chakra-ui/react';
import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { VscVerifiedFilled } from "react-icons/vsc";
import { GoVerified ,GoUnverified, GoDotFill } from "react-icons/go";
import Card from 'components/card/Card';
import InputField from 'components/fields/InputField';
import TextField from 'components/fields/TextField';
import Log from 'assets/img/games/log.png';
import Level from 'assets/img/games/new-level-final.png';
import Character from 'assets/img/games/select-character-final.png';
import Badges from 'assets/img/games/badges-game-read-format.png';
import { getBackgrounds, getNonPlayer, getPlayer, updateGame, getGameById } from 'utils/game/gameService';
import { useParams } from 'react-router-dom';
import AboutStory from './AboutStory';
import GreetingsForm from './GreetingsForm';
import Customization from './Customize'

import { MdCheckCircle, MdSettings, MdMyLocation, MdImage, MdIncompleteCircle, MdArrowCircleRight } from 'react-icons/md';
import { TfiRulerPencil } from "react-icons/tfi";
import AddScores from './AddScores';
import CompletionScreen from './Completion';


import Background from 'assets/img/stepper/background.png'
import Block from 'assets/img/stepper/blocks.png'
import pose from 'assets/img/stepper/pose.png'
import stroy from 'assets/img/stepper/stroy.png'
import scores from 'assets/img/stepper/scores.png'
import endflag from 'assets/img/stepper/endflag.png'
import summary from 'assets/img/stepper/summary.png'
import NftStepper from 'assets/img/nfts/NftStepper.png'
import Stepbg from 'assets/img/product/product-footer.png';
import Stepbg1 from 'assets/img/product/OverviewBanner.png';
import Stepbg2 from 'assets/img/ecommerce/Details.png';


const steps = [
  { title: 'BackGround' },
  { title: 'Non Playing Charater' },
  { title: 'About Story' },
  { title: 'Blocks' },
  { title: 'Score' },
  { title: 'Summaries' },
  { title: 'Endpage' },
];
const GameCreation = () => {
  const toast = useToast();
  const [tab, setTab] = useState<number>(1);
  const [img, setImg] = useState<any[]>([]),
    [players, setPlayers] = useState<any[]>([]);
  enum SummaryState {
    Yes = 'yes',
    No = 'no',
  }

  enum feedBackForm {
    Yes = 'yes',
    No = 'no',
  }
  
  const [isOpenSummary, setIsOpenSummary] = useState<SummaryState>(SummaryState.No);
  //   const [formDatas, setFormDatas] = useState<FormData>({
  //     '0': {
  //       refQuestion: [], // Ensure lenUserName is initialized as an array
  //     },
  //     // ... other rows ...
  // });


  const [fetchImg, setFetchImg] = useState<any>(''),
    [selectedPlayer, setSelectedPlayer] = useState<any>(''),
    [backgroundIndex, setBackgroundIndex] = useState<any>(),
    [nonPlayer, setNonPlayer] = useState(),
   [clicked, setClicked] = useState(false),
    [enter,setEnter] = useState(false),
    [bgIndex,setBgIndex] = useState<number>(),
    [formData, setFormData] = useState({
      // gameCourseName: null,
      // gameCourseDescription: null,
      gameabstract: null,
      gameBibliography: null,
      gameMinScore: null,
      gameMaxScore: null,
      // gameCategoryId: null,
      gameBackgroundId: null,
      gameCourseType: '',
      gameNonPlayingCharacterId: null,
      gameAnimationId: null,
      gameTitle: '',
      gameStoryLine: '',
      gameSkills: '',
      gameLearningOutcome: '',
      gameDuration: '',
      gameAuthorName: '',
      gameTotalScore: null,
      gameCreatorId: null,
      gameAnotherCreatorId: null,
      gameReplayAllowed: null,
      gameReflectionpageAllowed: null,
      gameLeaderboardAllowed: null,
      gameReflectionPageId: null,
      gamelanguageId: '',
      gameSummarizes: null,
      gameThankYouPage: null,
      gamWelcomePageText: null,
      gameScormVersion: null,
      gameSummaryScreen: null,
      gameLaunchedWithinPlatform: null,
      gameLastTab: 0,
      refQuestion: [],
      gameDownloadedAsScorm: null,
      gameDefaultFeedbackForm: null,
      gameFeedbackQuestion: null,
      gameShuffle: null,
      gameLanguageId:null,
      gameIntroMusic:null,
      // gameCreatedUserId: null,
      // gameEditedUserId: null,
      // gameCreatedDate: null,
      // gameEditedDate: null,
      // gameStatus: null,
      // gameDeleteStatus: 'NO',
      // gameIpAdderss: null,
      // gameDeviceType: null,
      // gameUserAgent: null,
    });
  const { id } = useParams();
  const inputRef = useRef<HTMLButtonElement>(null);
  console.log(inputRef);
  const fetchData = async () => {
    const result = await getBackgrounds();
    if (result?.status !== 'Success')
      return alert('getbackruond error:' + result?.message);
    setImg(result?.data);
    const players = await getNonPlayer();
    if (players?.status !== 'Success')
      return alert('getbackruond error:' + players?.message);
    setPlayers(players?.data);

  };
  interface OptionType {
    value: string;
    label: string;
  }

  const handleBackGroundImage = (e: any) => {
    setFormData((prev) => ({
      ...prev,
      gameWelcomepageBackground: e.target.id
    }));

    

  };

  const fetchGameId = async () => {

    const gameById = await getGameById(id);
    console.log('gameById', gameById.data);

    setFormData(gameById.data);
  };
  console.log('formData', formData)
  useEffect(() => {
    fetchData();
    fetchGameId();
  }, []);
  const commonNextFunction = async () => {
    
    if (tab === 1 && !formData.gameBackgroundId) {
      toast({
        title: 'Please Select a background image.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
      // console.log('frominsidecommonNextFunction',alerts);
      // setAlerts(true);
      // setMsg('Please Select a background image');
      // setToastStatus('error');
      // console.log('background is empty !');
      return false;
    }

    if (tab === 2 && !formData.gameNonPlayingCharacterId) {
      toast({
        title: 'Please Select a Non Playing Character.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
      // console.log('background is empty !');
      return false;

    }
    if (tab === 3 && !formData.gameTitle) {
      toast({
        title: 'Please Enter The Stroy Title',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
      // console.log('background is empty !');
      return false;

    }
    if (tab === 3 && !formData.gameStoryLine) {
      toast({
        title: 'Please Enter The Story Line',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });
      // console.log('background is empty !');
      return false;

    }

    if (tab === 8 && !formData.gamWelcomePageText) {
      toast({
        title: 'Please Fill all required feilds.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });

      // console.log('background is empty !');
      return false;
    }
    if (tab === 8 && !formData.gameThankYouPage) {
      toast({
        title: 'Please Fill all required feilds.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });

      // console.log('background is empty !');
      return false;
    }
    if (tab === 8 && !formData.gameScormVersion) {
      toast({
        title: 'Please Fill all required feilds.',
        status: 'error',
        duration: 3000,
        isClosable: true,
      });

      // console.log('background is empty !');
      return false;
    }
    if (isOpenSummary === SummaryState.Yes) {
      console.log('isOpenSummary is true !');
    }    


    let data = JSON.stringify(formData);
    console.log('update data', formData);

    try {
      const result = await updateGame(id, data);
      console.log('resultDTA', tab);
      if (result?.status !== 'Success') {
        toast({
          title: 'Data Not Updated.',
          status: 'error',
          duration: 3000,
          isClosable: true,
        });
        return console.log('updateBackground error :' + result?.err);

      }

      if(tab == 1 && result.status == "Success") {
        toast({
          title: 'Background Image Updated',
          status: 'success',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right',
        });
        setTab(tab + 1);        
      }    

      if(tab == 2 && result.status == "Success") {
        toast({
          title: 'Non-Playing Character Updated',
          status: 'success',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right',
        });
        setTab(tab + 1);        
      }    

      if(tab == 3 && result.status == "Success") {
        toast({
          title: 'About Story Updated',
          status: 'success',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right',
        });
        setTab(tab + 1);        
      }    

      if(tab == 4 && result.status == "Success") {
        toast({
          title: 'Blocks Updated',
          status: 'success',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right',
        });
        setTab(tab + 1);        
      }    
      
      if(tab == 5 && result.status == "Success") {
        toast({
          title: 'Score Updated',
          status: 'success',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right',
        });
        setTab(tab + 1);        
      }    

      if(tab == 6 && result.status == "Success") {
        toast({
          title: 'Summary Updated',
          status: 'success',
          duration: 3000,
          isClosable: true,
          position: 'bottom-right',
        });
        setTab(tab + 1);        
      }    

      // toast({
      //   title: 'Data updated',
      //   status: 'success',
      //   duration: 3000,
      //   isClosable: true,
      // });
      // setTimeout(() => {
      //   setTab(tab + 1);
      // }, 200);

      // alert(result?.status);
    } catch (error) {
      console.error('An error occurred while sending the request:', error);

    }

  };
  
  const handleBackground = (img: any, i: any) => {    
    setBackgroundIndex((prevIndex: any) => (prevIndex === i ? null : i));      
    setFetchImg(img?.aniId);
    console.log('img', img);
  };
    
  useEffect(() => {
    setFormData((prev) => ({ ...prev, gameBackgroundId: backgroundIndex !== null ? fetchImg : null}));

    setFormData((prev) => ({ ...prev, gameNonPlayingCharacterId: nonPlayer !== null ? selectedPlayer?.aniId : null}));
  },[backgroundIndex, fetchImg, nonPlayer]);

  
  const handlePlayer = (player: any, i: any) => {
    setNonPlayer((prevIndex : any) => (prevIndex === i ? null : i));
    
    setSelectedPlayer(player);
    setFormData((prev) => ({
      ...prev,
      gameNonPlayingCharacterId: player?.aniId,
    }));
  };  
  const handleChange = (e: any) => {
    const { name, value, checked } = e.target;
    if (name === 'gameDuration') {
      let duration =
        parseInt(value.split(':')[0], 10) * 60 +
        parseInt(value.split(':')[1], 10);
      setFormData((prev) => ({ ...prev, gameDuration: String(duration) }));
    } else if (e.target.id === 'gameLaunchedWithinPlatform') {
      e.target.checked ?
        setFormData((prev) => ({ ...prev, [name]: value })) :
        setFormData((prev) => ({ ...prev, [name]: 0 }));
      console.log('name', name);
      console.log('value', value);

    }
    else if (name === 'gameDownloadedAsScorm') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 1 : 0 }));
      console.log("gameDownloadedAsScorm", formData.gameDownloadedAsScorm);
    }

    else if (name === 'gameDefaultFeedbackForm') {
      setFormData((prev) => ({ ...prev, [name]: checked ? feedBackForm.Yes : feedBackForm.No }));
      console.log("gameDefaultFeedbackForm", formData.gameDefaultFeedbackForm);
    } else if (name === 'gameReplayAllowed') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'yes' : 'no' }));
      console.log("gameReplayAllowed", formData.gameReplayAllowed);
    } else if (name === 'gameLeaderboardAllowed') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'yes' : 'no' }));
      console.log("gameLeaderboardAllowed", formData.gameLeaderboardAllowed);
    }
    else if (name === 'gameReflectionpageAllowed') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'yes' : 'no' }));
      console.log("gameReflectionpageAllowed", formData.gameReflectionpageAllowed);
    }
    else if (name === 'gameFeedbackQuestion') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'yes' : 'no' }));
      console.log("gameFeedbackQuestion", formData.gameFeedbackQuestion);
    }
    else if (name === 'gameShuffle') {
      setFormData((prev) => ({ ...prev, [name]: checked ? 'yes' : 'no' }));
      console.log("gameShuffle", formData.gameShuffle);
    }
    else {
      setFormData((prev) => ({ ...prev, [name]: value }));
      // console.log("formdata",formData);
    }

    console.log("formdata", formData);
  };
  const handleMouse = (i:number) =>{
    setEnter(true)
    setBgIndex(i )
  }
  const handleMouseLeave = () =>{
    setEnter(false)
    setBgIndex(null)
  }
  const handleSummaryState = (isOpen: any) => {
    setIsOpenSummary(isOpen);
    setFormData((prev) => ({
          ...prev,
          gameSummaryScreen: !isOpen ? SummaryState.No : SummaryState.Yes  
        }));
    
    // console.log('isOpenSummary',isOpenSummary);
    // console.log('formData',formData);

  };
  const handleLanguageChange = (selectedOption: OptionType | null) => {
    setFormData({ ...formData, gameLanguageId: selectedOption.value });
    console.log('formData',selectedOption.value);
  };
  const handleIntroMusic = (selectedOption: OptionType | null) => {
    setFormData({ ...formData, gameIntroMusic: selectedOption.value });
    console.log('formData',selectedOption.value);
  };



  const myBlink = keyframes`
  0% {
    filter: drop-shadow(2px 4px 6px #0000);
  }
  50% {
    filter: drop-shadow(2px 4px 6px #411ab3);
  }
  100% {
    filter: drop-shadow(2px 4px 6px #0000);
  }
  `;

  const blink = `${myBlink} 0.5s linear infinite`;



return (
  <>
    <Box className="game-creation" mt={{ base: '0px', xl: '100px' }}>
      <Grid templateColumns="repeat(1, 1fr)" gap={6}>
        <GridItem w="100%" colSpan={1}>
          {/* <Card position={'fixed'} width={'25%'}>
            <Stepper
              colorScheme='green'
              index={tab - 1}
              orientation="vertical"
              height="600px"
              gap="0"
            >
              {steps.map((step, index) => (
                <Step key={index}>
                  <StepIndicator>
                    <StepStatus
                      complete={<StepIcon />}
                      incomplete={<StepNumber />}
                      active={<StepNumber />}
                    />
                  </StepIndicator>
                  <Box flexShrink="0">
                    <StepTitle>{step.title}</StepTitle>
                  </Box>
                  <StepSeparator />
                </Step>
              ))}
            </Stepper>
          </Card> */}
          {/* <Box>
                <Card>
                  <Card
                    alignItems={'center'}
                    bg={'linear-gradient(135deg, #667eea 0%, #764ba2 100%);'}
                    borderRadius={'none'}
                  >
                    <Box>
                      <Flex>
                        <Box
                          borderRadius={'50%'}
                          width={'40px'}
                          height={'40px'}
                          bg={'green'}
                          as={GoVerified}
                          color={'white'}
                        />
                        <Text
                          mt={'8px'}
                          ml={'10px'}
                          padding={'5px'}
                          bg={''}
                          color={'white'}
                          textShadow="2px 2px grey"
                        >
                          Background
                        </Text>
                      </Flex>
                    </Box>
                  </Card>
                  <Card alignItems={'center'} borderRadius={'none'}>
                    <Flex>
                      <Text mt={'10px'} mr={'10px'}>
                        Non Playing Character
                      </Text>
                      <Box
                        borderRadius={'50%'}
                        width={'40px'}
                        height={'40px'}
                        bg={'grey'}
                        as={GoUnverified}
                        color={'whiteSmoke'}
                      />
                    </Flex>
                    <Progress
                      size="xs"
                      mt="2px"
                      colorScheme="purple"
                      w={'100%'}
                      isIndeterminate
                    />
                  </Card>
                  <Card alignItems={'center'} borderRadius={'none'}>
                    <Flex>
                      <Box
                        borderRadius={'50%'}
                        width={'40px'}
                        height={'40px'}
                        as={GoUnverified}
                        bg={'grey'}
                        color={'whiteSmoke'}
                      />
                      <Text mt={'10px'} ml={'10px'}>
                        About Story
                      </Text>
                    </Flex>
                  </Card>
                  <Card alignItems={'center'} borderRadius={'none'}>
                    <Flex>
                      <Text mt={'10px'} mr={'10px'}>
                        Blocks
                      </Text>
                      <Box
                        borderRadius={'50%'}
                        width={'40px'}
                        height={'40px'}
                        as={GoUnverified}
                        bg={'grey'}
                        color={'whiteSmoke'}
                      />
                    </Flex>
                  </Card>
                  <Card alignItems={'center'} borderRadius={'none'}>
                    {' '}
                    <Flex>
                      <Box
                        borderRadius={'50%'}
                        width={'40px'}
                        height={'40px'}
                        as={GoUnverified}
                        bg={'grey'}
                        color={'whiteSmoke'}
                      />
                      <Text mt={'10px'} ml={'10px'}>
                        Summaries
                      </Text>
                    </Flex>
                  </Card>
                  <Card alignItems={'center'} borderRadius={'none'}>
                    <Flex>
                      <Text mt={'10px'} mr={'10px'}>
                        Scores
                      </Text>
                      <Box
                        borderRadius={'50%'}
                        width={'40px'}
                        height={'40px'}
                        as={GoUnverified}
                        bg={'grey'}
                        color={'whiteSmoke'}
                      />
                    </Flex>
                  </Card>
                  <Card alignItems={'center'} borderRadius={'none'}>
                    <Box>
                      <Flex>
                        <Box
                          borderRadius={'50%'}
                          width={'40px'}
                          height={'40px'}
                          as={GoUnverified}
                          bg={'grey'}
                          color={'whiteSmoke'}
                        />
                        <Text mt={'10px'} ml={'10px'}>
                          End Page
                        </Text>
                      </Flex>
                    </Box>
                  </Card>
                </Card>
          </Box> */}
          {/* <motion.div initial={{ opacity: 0, x: 120 }} animate={{ opacity: 1, x: 0}} transition={{ duration: 0.3 }}>
            <Card boxShadow={'4px 3px 22px #00000078'} borderRadius={'30px'} p={'25px 20px'} alignItems={'center'} flexDirection={'row'} className='for-stepper' bg={'linear-gradient(to bottom, #7551ff, #3311db)'}>
              <Img w={'250px'} src={StepperImg} position={'absolute'} left={'-25px'} filter={'drop-shadow(4px 8px 19px #2e2a2a94)'} />            
                <Box display={'flex'} position={'relative'} left={'150px'}>
                    <Box 
                      className={'box-1'}
                      borderTop={'5px dashed #fff'} 
                      borderRadius={'150px'} 
                      height={'140px'}
                      width={'168px'}
                      transform={'rotate(2deg)'} 
                    >                  
                      <Text 
                      bg={'linear-gradient(to left, #7551ff, #79b5e9)'}
                      boxShadow={'1px 3px 14px #2e2a2a2e'}
                        transform={'rotate(358deg)'} 
                        color={'#fff'} 
                        borderRadius={'30px'} 
                        display={'flex'} 
                        justifyContent={'center'} 
                        width={'180px'} 
                        position={'relative'} 
                        // border={'2px solid #3311db'} 
                        top={'-13px'} 
                        left={'12px'}>BackGround Image</Text>                  
                    </Box>
                    <Box 
                      className={'box-2'}
                      borderTop={'5px dashed #fff'} 
                      borderRadius={'150px'} 
                      height={'140px'}
                      width={'168px'}
                      transform={'rotate(182deg)'} 
                    >                                   
                      <Text 
                      bg={'linear-gradient(to left, #7551ff, #79b5e9)'}
                      boxShadow={'1px 3px 14px #2e2a2a1f'}
                        transform={'rotate(178deg)'}  
                        color={'#fff'} 
                        borderRadius={'30px'} 
                        display={'flex'} 
                        justifyContent={'center'} 
                        width={'180px'} 
                        position={'relative'} 
                        // border={'2px solid #3311db'} 
                        top={'-13px'} 
                        left={'0px'}>Non Playing Charater</Text>                  
                    </Box>  
                    <Box 
                      className={'box-1'}
                      borderTop={'5px dashed #fff'} 
                      borderRadius={'150px'} 
                      height={'140px'}
                      width={'168px'}
                      transform={'rotate(2deg)'} 
                    >                  
                      <Text 
                      bg={'linear-gradient(to left, #7551ff, #79b5e9)'}
                      boxShadow={'1px 3px 14px #2e2a2a1f'}
                        transform={'rotate(358deg)'} 
                        color={'#fff'} 
                        borderRadius={'30px'} 
                        display={'flex'} 
                        justifyContent={'center'} 
                        width={'180px'} 
                        position={'relative'} 
                        // border={'2px solid #3311db'} 
                        top={'-13px'} 
                        left={'12px'}>About Story</Text>                  
                    </Box> 
                    <Box 
                    className={'box-2'}
                      borderTop={'5px dashed #fff'} 
                      borderRadius={'150px'} 
                      height={'140px'}
                      width={'168px'}
                      transform={'rotate(182deg)'} 
                    >                  
                      <Text 
                      className='block'
                      bg={'linear-gradient(to right, #7551ff, #79b5e9)'}
                      boxShadow={'1px 3px 14px #2e2a2a1f'}
                        transform={'rotate(178deg) scale(1.3)'}  
                        color={'#fff'} 
                        borderRadius={'30px'} 
                        display={'flex'} 
                        justifyContent={'center'} 
                        width={'180px'} 
                        position={'relative'} 
                        // border={'2px solid #3311db'}                                         
                        top={'-13px'} 
                        left={'12px'}>
                          <Icon animation={blink} as={MdMyLocation} color={'#3311db'} fontSize={'24px'} mr={'10px'} />
                          Blocks</Text>                  
                    </Box> 
                    <Box 
                      className={'box-1'}
                      borderTop={'5px dashed #fff'} 
                      borderRadius={'150px'} 
                      height={'140px'}
                      width={'168px'}
                      transform={'rotate(2deg)'} 
                    >                  
                      <Text 
                      bg={'linear-gradient(to left, #7551ff, #79b5e9)'}
                      boxShadow={'1px 3px 14px #2e2a2a1f'}
                        transform={'rotate(358deg)'} 
                        color={'#fff'} 
                        borderRadius={'30px'} 
                        display={'flex'} 
                        justifyContent={'center'} 
                        width={'180px'} 
                        position={'relative'} 
                        // border={'2px solid #3311db'} 
                        top={'-13px'} 
                        left={'12px'}>Summaries</Text>                  
                    </Box> 
                    <Box 
                    className={'box-2'}
                      borderTop={'5px dashed #fff'} 
                      borderRadius={'150px'} 
                      height={'140px'}
                      width={'168px'}
                      transform={'rotate(182deg)'}
                      borderLeft={'2px solid #0000'} 
                    >                  
                    
                          <Img src={Golf} height={'80px'} width={'80px'} position={'relative'} top={'-10px'} left={'10px'} filter={'drop-shadow(4px 8px 19px #2e2a2a94)'}  transform={'rotate(178deg)'} />
                          <Text transform={'rotate(178deg)'}  color={'#fff'} fontSize={'17px'} position={'relative'} top={'-10px'} left={'-80px'}>The End</Text>                        
                    </Box> 
                </Box>                              
            </Card>
          </motion.div> */}

            
            <motion.div initial={{ opacity: 0, x: 120 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.3 }}>
                {/* <Card bgImage={NftStepper} height={'200px'} width={'100%'}></Card> */}
                <Box className='stepper' bgImage={Stepbg2} w={'100%'} display={'flex'} alignItems={'center'} justifyContent={'center'}>
                  <Box w={'90%'} display={'flex'} alignItems={'center'} justifyContent={'space-between'} h={'180px'}>                    
                    <Box>
                      <Flex>
                        <Box position={'relative'}>
                          <Card borderRadius={'50%'} w={'78px'} h={'78px'} p={0} bg={'#f3f3f3'}  border={'6px solid #3d92fb'} > 
                            <Img src={Background} h={'300px'} width={'300px'} display={'block'}/>
                             {/* <Icon className='icon' as={MdSettings} fontSize={'66px'} color={'#db2bcc'} position={'relative'} top={'18px'} /> */}
                          </Card>
                            <Text textAlign={'center'} color={'#fff'} fontSize={'17px'} fontWeight={600}>Background</Text>
                        {/* <Text ml={'10px'}>Background</Text> */}
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'blue.300'} />
                        </Box>
                        <Box mt={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#3311db'} />
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#3311db'} />
                          </Flex>
                        </Box>
                      </Flex>
                    </Box>
                    <Box>
                      <Flex>
                        <Box position={'relative'}>
                          <Card borderRadius={'50%'} w={'78px'} h={'78px'} bg={'#f3f3f3'}  p={0} border={'6px solid #3d92fb'} boxShadow={'1px 3px 33px #3c3c3c7d'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                          <Img src={pose} h={'300px'} width={'300px'} display={'block'}/></Card><Text textAlign={'center'} color={'#fff'} fontSize={'17px'} fontWeight={600}>Character</Text>
                             {/* <Icon className='icon' as={MdSettings} fontSize={'66px'} color={'#db2bcc'} position={'relative'} top={'18px'} /> */}
                          {/* <Text ml={'10px'}>Character</Text>  */}
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'blue.300'} />
                        </Box>
                        <Box mt={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#3311db'} />
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#3311db'} />
                          </Flex>
                        </Box>
                      </Flex> 
                    </Box>
                    <Box>
                      <Flex>
                        <Box position={'relative'}>
                          <Card borderRadius={'50%'} w={'78px'} h={'78px'} p={0} bg={'#f3f3f3'}   border={'6px solid #3d92fb'}boxShadow={'1px 3px 33px #3c3c3c7d'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                          <Img src={stroy} h={'300px'} width={'300px'} display={'block'}/> </Card><Text textAlign={'center'} color={'#fff'} fontSize={'17px'} fontWeight={600}>About Story</Text>
                             {/* <Icon className='icon' as={MdSettings} fontSize={'66px'} color={'#db2bcc'} position={'relative'} top={'18px'} /> */}
                          {/* <Text ml={'10px'}>About Story</Text>  */}
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'blue.300'} />
                        </Box>
                        <Box mt={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#3311db'} />
                          </Flex>
                        </Box>
                      </Flex>
                    </Box>
                    <Box position={'relative'}>
                      <Card borderRadius={'50%'} w={'110px'} h={'110px'} p={0} bg={'#e1e1e1'}  border={'6px solid #3311db'} boxShadow={'1px 3px 33px #3c3c3c7d'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                      <Img src={Block} h={'300px'} width={'300px'} display={'block'} borderRadius={'50%'}/>
                             {/* <Icon className='icon' as={MdSettings} fontSize={'66px'} color={'#db2bcc'} position={'relative'} top={'18px'} /> */}
                      </Card><Text textAlign={'center'} color={'#fff'} fontSize={'17px'} fontWeight={600}>Blocks</Text>
                      {/* <Text ml={'33px'}>Blocks</Text>  */}
                      <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'blue.300'} />
                    </Box>
                    <Box>
                      <Flex>
                        <Box mt={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#cecece'}/>
                          </Flex>
                        </Box>
                        <Box position={'relative'}>
                          <Card borderRadius={'50%'} w={'78px'} h={'78px'} bg={'#f3f3f3'}  p={0} border={'6px solid #3d92fb'}boxShadow={'1px 3px 33px #3c3c3c7d'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                          <Img src={scores} h={'300px'} width={'300px'} display={'block'} borderRadius={'50%'}/> </Card><Text textAlign={'center'} color={'#fff'} fontSize={'17px'} fontWeight={600}>Score</Text>
                             {/* <Icon className='icon' as={MdSettings} fontSize={'66px'} color={'#db2bcc'} position={'relative'} top={'18px'} /> */}
                          {/* <Text ml={'10px'}>Scores</Text>  */}
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'#CF9FFF'} />
                        </Box>
                      </Flex>
                    </Box>
                    <Box>
                      <Flex>
                        <Box mt={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#cecece'} />
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#cecece'} />
                          </Flex>
                        </Box>
                        <Box position={'relative'}>
                          <Card borderRadius={'50%'} w={'78px'} h={'78px'} bg={'#f3f3f3'}  p={0} border={'6px solid #3d92fb'}boxShadow={'1px 3px 33px #3c3c3c7d'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                          <Img
                            src={summary} h={'300px'} width={'300px'} display={'block'} borderRadius={'50%'}/></Card><Text textAlign={'center'} color={'#fff'} fontSize={'17px'} fontWeight={600}>Summaries</Text>
                             {/* <Icon className='icon' as={MdSettings} fontSize={'66px'} color={'#db2bcc'} position={'relative'} top={'18px'} /> */}
                          {/* <Text ml={'10px'}>Summary</Text>  */}
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'#CF9FFF'} />
                        </Box>
                      </Flex>
                    </Box>
                    <Box>
                      <Flex>
                        <Box mt={'23px'}>
                          <Flex>
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#cecece'} />
                            <Icon as={GoDotFill} w={'30px'} h={'30px'} color={'#cecece'} />
                          </Flex>
                        </Box>
                        <Box position={'relative'}>
                          <Card borderRadius={'50%'} w={'78px'} h={'78px'} bg={'#f3f3f3'}  p={0} border={'6px solid #3d92fb'} boxShadow={'1px 3px 33px #3c3c3c7d'} justifyContent={'center'} alignItems={'center'} overflow={'hidden'}>
                            <Img src={endflag} h={'300px'} width={'300px'} display={'block'} borderRadius={'50%'}/>
                             {/* <Icon className='icon' as={MdSettings} fontSize={'66px'} color={'#db2bcc'} position={'relative'} top={'18px'} /> */}
                            {/* <Icon className='icon' as={MdSettings} fontSize={'66px'} color={'#db2bcc'} position={'relative'} top={'18px'} /> */}
                          </Card>
                          <Text textAlign={'center'} color={'#fff'} fontSize={'17px'} fontWeight={600}>Completed</Text>                          
                          {/* <Text ml={'10px'}>End Page</Text>  */}
                          <Icon as={GoDotFill} position={'absolute'} top={'0'} w={'30px'} h={'30px'} right={'0'} color={'#CF9FFF'} />
                        </Box>
                      </Flex>
                    </Box>
                  </Box>
                </Box>
            </motion.div>
        </GridItem>
        <GridItem w="100%" colSpan={2}>
          {tab === 1 ? (
                // <Card mb={{ base: '0px', xl: '20px', sm: '20px' }}>
                //   {/* <InputField /> */}
                //   <Text fontSize={18} fontWeight={500} mb="20px">
                //     Background Image
                //   </Text>
                //   <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
                //     {img &&
                //       img.map((img, i) => (
                //         <Box key={i} position={'relative'}>
                //           <Card
                //             className='bg-img-card'
                //             mb={{ base: '0px', xl: '10px', sm: '20px' }}
                //             key={i}
                //             boxShadow={
                //               backgroundIndex === i ? '5px 5px 20px #8080803b' : ''
                //             }
                //             transform={backgroundIndex === i ? 'scale(1.10)' : ''}
                //             transition={'0.3s'}
                //             onMouseEnter={() => handleMouse(i)}
                //             onMouseLeave={() => handleMouseLeave()}
                //           >
                //             <Img
                //               src={img?.aniImages}
                //               onClick={() => handleBackground(img, i)}
                //               w="100%"
                //               h="150"
                //               borderRadius="0px"
                //               cursor="pointer"
                //             />
                //             <Box
                //               borderRadius={
                //                 enter && bgIndex === i ? 'none' : '0 0 40px 0px'
                //               }
                //               // w={'150px'}
                //               bg={'linear-gradient(95deg, #a927f8, #2857bc)'}
                //               color={'white'}
                //               alignItems={'center'}
                //               p={'2'}
                //               zIndex={0}
                //               transform={
                //                 enter && bgIndex === i
                //                   ? 'scale(1.15) translate(0px,4px)'
                //                   : ''
                //               }
                //               w={'100%'}
                //               transition="transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out,border-radius 0.3s ease-in-out"
                //               cursor={'pointer'}
                //               textAlign={'center'}
                //             >
                //               Casandra
                //             </Box>
                //           </Card>
                //         </Box>
                //       ))}
                //   </SimpleGrid>
                // </Card>
                <Box className='background-step' display={{ base: 'block', md: 'flex', lg: 'flex' }}>                  
                  <Box className='bg-img-list' width={'65%'}>  
                    <Box display={'flex'} flexDir={'column'} justifyContent={'start'} alignItems={'start'}>
                      <Text fontSize={'20px'} fontWeight={800}m={'0px 10px 3px 20px'}>BackGround Image</Text>
                      <Text fontSize={'14px'} fontWeight={500} m={'0px 10px 20px 20px'} color={'#8b8b8bd9'} letterSpacing={'0.5px'}>Here is the Background Image from which you can choose any one</Text>
                      {/* <Img src={pose} h={'30px'} width={'30px'} mb={'20px'} /> */}
                      {/* <Card p={'5px'} boxShadow={'1px 2px 10px #8080803b'} width={'40%'}> */}
                        {/* <InputField
                          name='SearchBar'
                          placeholder='Search Background....'
                          margin={'0'}
                          bg={'#fff'}
                          boxShadow={'2px 3px 13px #8080801b'}
                        /> */}
                      {/* </Card> */}
                    </Box>                  
                    <Divider mb={'30px'} />
                    <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
                      {img &&
                        img.map((img, i) => (
                          <Box key={i} position={'relative'}>
                            <Card                            
                              mb={{ base: '0px', xl: '10px', sm: '20px' }}
                              padding={'13px'}
                              key={i}
                              boxShadow={
                                backgroundIndex === i ? '1px 4px 29px #44445429' : '1px 4px 29px #44445429'
                              }
                              // transform={backgroundIndex === i ? 'scale(1.10)' : ''}
                              transition={'0.3s'}                           
                            >
                              <Box position={'relative'} overflow={'hidden'} borderRadius={'10px'}>
                                <Img src={img?.aniImages} onClick={() => handleBackground(img, i)} w="100%" borderRadius="20px" cursor="pointer" />
                                <Box _before={{ content: '""', position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: '15px', backgroundImage: 'linear-gradient(95deg, #a927f84a, #0000004f)' }}></Box>
                              </Box>                              
                              <Flex justifyContent={'space-between'} margin={'10px 0'} flexDirection={'column'}>
                                <Box>
                                  <Text color={'#745c5cc9'} mt={'5px'} fontSize={'14px'} fontWeight={'700'} height={'30px'} textOverflow={'ellipsis'} overflow={'hidden'} whiteSpace={'nowrap'}>Background</Text>
                                  <Text color={'#2b2b2ede'} fontSize={'16px'} fontWeight={'800'}>{'Intro Finish '}</Text>
                                </Box>
                                <Box display={'flex'} alignItems={'center'} mt={'15px'}>
                                  <Button bg={'#190793'} color={'#fff'} border={'1px solid #0000'} _hover={{bg: '190793'}} borderRadius={'150px'}  width={'100%'} boxShadow={'2px 4px 13px #0000'} justifyContent={'space-between'} onClick={() => handleBackground(img, i)}>
                                    <Text fontSize={'14px'}>Choose</Text>
                                    <Icon as={MdArrowCircleRight} color={'#fff'} fontSize={'22px'} />
                                  </Button>
                                </Box>
                              </Flex>                                             
                            </Card>
                          </Box>
                        ))}
                    </SimpleGrid>
                  </Box>
                  <Box width={'1px'} background={'#dddddd87'} marginInline={'20px'} display={'flex'}></Box>                  
                  <Box className='bg-img-identifier-card' width={'35%'} height={'10vh'} mt={'50px'}>
                    <Flex flexDirection={'column'}>                            
                            <Heading fontSize={'45px'} mb={'40px'} textAlign={'center'}>Color Abstractus</Heading>
                            <Flex justifyContent={'space-between'}>
                              <Box display={'flex'} alignItems={'center'}>
                                <Box bg={'linear-gradient(45deg, #fdd07f, #e5b41e)'} display={'flex'} justifyContent={'center'} alignItems={'center'} borderRadius={'30px'} height={'50px'} width={'50px'} >
                                  <Icon as={MdImage} fontSize={'21px'} color={'#fff'} />                                  
                                </Box>
                                <Box ml={'10px'}>
                                  <Text fontSize={'13px'} color={'#848397'} letterSpacing={'0.8px'}>Background Name</Text>
                                  <Text fontSize={'21px'} color={'#000'} fontWeight={'700'}>Cargo</Text>
                                </Box>
                              </Box>
                              <Box display={'flex'} alignItems={'center'}>
                                <Box bg={'linear-gradient(45deg, #4220e3, #6b53ff54)'} display={'flex'} justifyContent={'center'} alignItems={'center'} borderRadius={'30px'} height={'50px'} width={'50px'} >
                                  <Icon as={MdImage} fontSize={'21px'} color={'#fff'} />                                  
                                </Box>
                                <Box ml={'10px'}>
                                  <Text fontSize={'13px'} color={'#848397'} letterSpacing={'0.8px'}>Story Line</Text>
                                  <Text fontSize={'21px'} color={'#000'} fontWeight={'700'}>Quick Fix</Text>
                                </Box>
                              </Box>                                                                                                                      
                            </Flex>
                            <Img src={NftStepper} h={'300'} w={'100%'} mt={'30px'} borderRadius={'8px'} boxShadow={'1px 3px 12px #8080807d'} />
                    </Flex>
                  </Box>
                </Box>
          ) : tab === 2 ? (
                <>
                  {/* <Card
                    mb={{ base: '0px', xl: '20px', sm: '20px' }}
                    bg={'#f7f7f7'}
                  >
                    <Text fontSize={20} fontWeight={500}>
                      Non Playing Character
                    </Text>
                    <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
                      {players &&
                        players.map((player, i) => (
                          <Box key={i} position={'relative'}>
                            <Card
                              className='non-pl-img'
                              justifyContent={'center'}
                              alignItems={'center'}
                              mt={{ base: '0px', xl: '10px', sm: '20px' }}
                              key={i}
                              boxShadow={
                                nonPlayer === i ? '5px 5px 20px #8080807d' : ''
                              }
                              zIndex={'9'}
                              cursor={'pointer'}
                              // transform={nonPlayer === i ? 'scale(1.10)' : ''}
                              transform={nonPlayer === i ? 'rotate3d(0, 57, 0, 360deg)' : ''}
                              transition="transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out"
                              // onMouseEnter={handleMouseMove}
                              // onMouseLeave={resetTransformOrigin}
                              onMouseUp={() => setClicked(true)}
                              onClick={() => handlePlayer(player, i)}
                            >
                              {nonPlayer === i ? <Box _after={{content: '""', height: '100%', width: '100%', zIndex: '99', position: 'absolute', top: '0', left: '0', background: '#2221247a', borderRadius: '20px'}}></Box> : null}
                              <Img
                                src={player?.aniImages}
                                
                                zIndex={'-9'}
                                w="100"
                                h="250"
                                borderRadius="8px"
                                // boxShadow="1px 3px 17px #332f2f4d"
                                cursor="pointer"
                              />
                                {nonPlayer === i ? (                             
                                <Icon
                                  position={'absolute'}
                                  // top={'100px'}
                                  // left={'90px'}
                                  as={VscVerifiedFilled}
                                  w={'100px'}
                                  zIndex={'9999999'}
                                  height={'100px'}
                                  color={'#f3f3f3'}
                                  // transform={'scale(1.25)'}
                                  transition="transform 0.6s ease-in-out, box-shadow 0.3s ease-in-out"
                                  onClick={() => setNonPlayer(null)}
                                />
                              ) : (
                                // </Card>
                                ''
                              )}
                            </Card>                            
                          </Box>
                        ))}
                    </SimpleGrid>
                  </Card> */}

                <Box className='character-step' display={{ base: 'block', md: 'flex', lg: 'flex' }}>                  
                  <Box className='character-img-list' width={'65%'}>  
                    <Box display={'flex'} flexDir={'column'} justifyContent={'start'} alignItems={'start'}>
                      <Text fontSize={'20px'} fontWeight={800} m={'0px 10px 3px 20px'}>Non-Playing Character</Text>
                      <Text fontSize={'14px'} fontWeight={500} m={'0px 10px 20px 20px'} color={'#8b8b8bd9'} letterSpacing={'0.5px'}>Here is the Non-Playing Character from which you can choose any one</Text>                     
                    </Box>                  
                    <Divider mb={'30px'} />
                    <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
                      {players &&
                        players.map((player, i) => (
                          <Box key={i} position={'relative'}>
                            <Card                            
                              mb={{ base: '0px', xl: '10px', sm: '20px' }}
                              padding={'13px'}
                              key={i}
                              boxShadow={
                                backgroundIndex === i ? '1px 4px 29px #44445429' : '1px 4px 29px #44445429'
                              }
                              // transform={backgroundIndex === i ? 'scale(1.10)' : ''}
                              transition={'0.3s'}                           
                            >
                              <Box position={'relative'} overflow={'hidden'} borderRadius={'10px'}>
                                <Img src={player?.aniImages} h={'150px'} w="100%" borderRadius="20px" cursor="pointer" />
                                <Box _before={{ content: '""', position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: '15px', backgroundImage: 'linear-gradient(95deg, #a927f84a, #0000004f)' }}></Box>
                              </Box>                              
                              <Flex justifyContent={'space-between'} margin={'10px 0'} flexDirection={'column'}>
                                <Box>
                                  <Text color={'#745c5cc9'} mt={'5px'} fontSize={'14px'} fontWeight={'700'} height={'30px'} textOverflow={'ellipsis'} overflow={'hidden'} whiteSpace={'nowrap'}>Character</Text>
                                  <Text color={'#2b2b2ede'} fontSize={'16px'} fontWeight={'800'}>{'Drew McIntyre'}</Text>
                                </Box>
                                <Box display={'flex'} alignItems={'center'} mt={'15px'}>
                                  <Button bg={'#190793'} color={'#fff'} border={'1px solid #0000'} _hover={{bg: '190793'}} borderRadius={'150px'}  width={'100%'} boxShadow={'2px 4px 13px #0000'} justifyContent={'space-between'} onClick={() => handlePlayer(player, i)}>
                                    <Text fontSize={'14px'}>Choose</Text>
                                    <Icon as={MdArrowCircleRight} color={'#fff'} fontSize={'22px'} />
                                  </Button>
                                </Box>
                              </Flex>                                             
                            </Card>
                          </Box>
                        ))}
                    </SimpleGrid>
                  </Box>
                  <Box width={'1px'} background={'#dddddd87'} marginInline={'20px'} display={'flex'}></Box>                  
                  <Box className='bg-img-identifier-card' width={'35%'} height={'10vh'} mt={'50px'}>
                    <Flex flexDirection={'column'}>                            
                            <Heading fontSize={'45px'} mb={'40px'} textAlign={'center'}>Color Abstractus</Heading>
                            <Flex justifyContent={'space-between'}>
                              <Box display={'flex'} alignItems={'center'}>
                                <Box bg={'linear-gradient(45deg, #fdd07f, #e5b41e)'} display={'flex'} justifyContent={'center'} alignItems={'center'} borderRadius={'30px'} height={'50px'} width={'50px'} >
                                  <Icon as={MdImage} fontSize={'21px'} color={'#fff'} />                                  
                                </Box>
                                <Box ml={'10px'}>
                                  <Text fontSize={'13px'} color={'#848397'} letterSpacing={'0.8px'}>Character Name</Text>
                                  <Text fontSize={'21px'} color={'#000'} fontWeight={'700'}>Cargo</Text>
                                </Box>
                              </Box>
                              <Box display={'flex'} alignItems={'center'}>
                                <Box bg={'linear-gradient(45deg, #4220e3, #6b53ff54)'} display={'flex'} justifyContent={'center'} alignItems={'center'} borderRadius={'30px'} height={'50px'} width={'50px'} >
                                  <Icon as={MdImage} fontSize={'21px'} color={'#fff'} />                                  
                                </Box>
                                <Box ml={'10px'}>
                                  <Text fontSize={'13px'} color={'#848397'} letterSpacing={'0.8px'}>Story Line</Text>
                                  <Text fontSize={'21px'} color={'#000'} fontWeight={'700'}>Quick Fix</Text>
                                </Box>
                              </Box>                                                                                                                      
                            </Flex>
                            <Img src={NftStepper} h={'300'} w={'100%'} mt={'30px'} borderRadius={'8px'} boxShadow={'1px 3px 12px #8080807d'} />
                    </Flex>
                  </Box>
                </Box>
                </>
          ) : tab === 3 ? (
            <>
              <AboutStory formData={formData} handleChange={handleChange} />
            </>
          ) : tab === 4 ? (
            <>
              <Customization />
            </>
          ) : tab === 5 ? (
            <>
             
              <AddScores formData={formData} inputRef={inputRef}  handleChange={handleChange} updateHandleIntroMusic = {handleIntroMusic}  setFormData={setFormData}/>
            </>
          ) : tab === 6 ? (
            <>
              <GreetingsForm formData={formData} handleChange={handleChange} updateSummaryState={handleSummaryState} updateLanguage={handleLanguageChange} updateImageBackGround={handleBackGroundImage} />
            </>
          ) : (
            <CompletionScreen formData={formData} handleChange={handleChange} inputRef={inputRef} />
          )}
        </GridItem>
      </Grid>
      <Flex justify="center">
        <Card
          display="flex"
          justifyContent="center"
          w="200px"
          flexDirection="row"
        >
          {tab <= 1 ? null : (
            <Button
              bg="#12101b"
              _hover={{bg: '#12101b'}}
              color="#fff"
              boxShadow='5px 5px 20px grey'
              w="80px"
              mr="10px"
              onClick={() => setTab(tab - 1)}
            >
              Back
            </Button>
          )}
          <Button
            bg="#3311db"
            _hover={{bg: '#3311db'}}
            color="#fff"
            boxShadow='1px 2px 20px grey'
            w="80px"
            onClick={commonNextFunction}
          >
            Next
          </Button>
        </Card>
      </Flex>
    </Box>
  </>
);
};

export default GameCreation;
