import { Box, Button, Flex, FormControl, FormLabel, Grid, GridItem, Img, SimpleGrid, Step, Stepper, StepIndicator, Text, Tooltip, StepNumber, StepIcon, StepStatus, StepSeparator, StepTitle } from '@chakra-ui/react'
import React, { ChangeEvent, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import Card from 'components/card/Card'
import InputField from 'components/fields/InputField'
import TextField from 'components/fields/TextField'
import SelectField from 'components/fields/SelectField'
import { Switch } from '@chakra-ui/react'
import logo from 'assets/img/games/log.png'
import badge from 'assets/img/games/new-level-final.png'



interface OptionType {
    value: string;
    label: string;
  }

const GreetingsForm : React.FC<{handleChange:(e:any,selectedOption?: OptionType)=>void,formData:any,updateSummaryState: (isOpen: any) => void,updateLanguage: (selectedOption: OptionType | null) => void ,updateImageBackGround: (e:any)=> void } > = ({handleChange,formData,updateSummaryState,updateLanguage,updateImageBackGround}) => {
    const [isOpenSummary, setIsOpenSummary] = useState<any>(false);
    const [tab, setTab] = useState<number>(1);

   const  languageOptions = [{
    value:'1',
    label: 'English',
   }, {
    value:'2',
    label: 'Italy',
   }];

   const mappedlanguageOptions = Array.isArray(languageOptions) ? languageOptions.map((language) => ({
       value: language.value,
       label: language.label,
     }))
   : [];

   

    const steps = [
        { title: 'BackGround' },
        { title: 'Non Playing Charater' },
        { title: 'About Story'},
        { title: 'Customzation'},
        { title: 'Score'},
        { title: 'Summaries'},
        { title: 'Endpage'},
      ];

    const navigate = useNavigate();

    const handleSummary = () => {
        setIsOpenSummary(!isOpenSummary); 
        updateSummaryState(!isOpenSummary);     
    }
    


  return (
    <>
    <Box className='greeting-form' mt={{ base: '135px', xl: '20px' }}>       
        <Flex mb={'30px'} flexDirection={{sm: 'column', md:'column', xl:'row'}}>          
            <Box display={'flex'} flexDirection={'column'} width={{sm: '100%',xl:'100%'}}>
                <Box display={'flex'} flexDirection={{sm: 'column-reverse', md:'row', xl:'row'}} mb={'20px'}>
                    <Card width={{sm: '100%', md:'60%', xl:'60%'}} mr={'30px'}>
                        <Text fontSize={20} fontWeight={500} mb={'20px'}>
                            Summaries
                        </Text>
                        <SimpleGrid columns={{ sm: 1, md: 1, xl: 2 }} spacing={{ base: '20px', xl: '20px' }}>
                            { isOpenSummary ? 
                            <TextField
                                mb="0px"
                                me="30px"
                                name="gameSummarizes"                   
                                label="Summary"
                                placeholder="eg. Summary"
                                isRequired={true}
                                value={formData?.gameSummarizes}
                                onChange={handleChange}
                            /> : null }                            
                            <TextField
                                mb="0px"
                                me="30px"
                                name="gamWelcomePageText"                   
                                label="Welcome Page"
                                placeholder="eg. Welcome Page"
                                isRequired={true}
                                value={formData?.gamWelcomePageText}
                                onChange={handleChange}
                            />
                            <TextField
                                mb="0px"
                                me="30px"
                                name="gameThankYouPage"                   
                                label="Thankyou Page"
                                placeholder="eg. Thankyou Page"
                                isRequired={true}
                                value={formData?.gameThankYouPage}
                                onChange={handleChange}
                            />                          
                            <TextField
                                mb="0px"
                                me="30px"
                                name="gameScormVersion"                   
                                label="Scorm Version"
                                placeholder="eg. 2.0"
                                isRequired={true}
                                value={formData?.gameScormVersion}
                                onChange={handleChange}
                            />
                            <SelectField
                                mb="0px"
                                me="30px"
                                label="Language"
                                name="gameLanguageId"
                                options={mappedlanguageOptions}
                                value={
                                    mappedlanguageOptions.find(
                                      (option) => option.value === formData?.gameLanguageId,
                                    ) || null
                                  }
                                onChange={updateLanguage}
                                                  
                            />
                        </SimpleGrid>
                    </Card>
                    <Card width={{sm: '100%', md: '40%', xl:'40%'}} mb={{sm: '30px', md: '30px', xl: '0'}} className='for-switch' alignItems={'stretch'}>                
                        <SimpleGrid columns={{ sm: 1, md: 1 }} spacing={{ base: '40px', xl: '60px' }} >
                            <FormControl display='flex' alignItems='center' justifyContent={'space-between'}>
                                <FormLabel htmlFor='summaryScreen' mb='0'>
                                    Summary Screen
                                </FormLabel>
                                <Switch id='gameSummaryScreen' name='gameSummaryScreen' colorScheme={'purple'} onChange={handleSummary} />
                            </FormControl>
                            <FormControl display='flex' alignItems='center'  justifyContent={'space-between'}>
                                <FormLabel htmlFor='launchPlatform' mb='0'>
                                    Launched within Platform
                                </FormLabel>
                                <Switch id='gameLaunchedWithinPlatform' name='gameLaunchedWithinPlatform' value={1} onChange={handleChange} colorScheme={'purple'} />
                            </FormControl>
                            <FormControl display='flex'  onChange={handleChange} alignItems='center'  justifyContent={'space-between'}>
                                <FormLabel htmlFor='downloadScorm' mb='0'>
                                    Downloaded as Scorm
                                </FormLabel>
                                <Switch id='gameDownloadedAsScorm' name='gameDownloadedAsScorm' onChange={handleChange} value={1} colorScheme={'purple'} />
                            </FormControl>
                            <FormControl display='flex' alignItems='center'  justifyContent={'space-between'}>
                                <FormLabel htmlFor='defaultFeedback' mb='0'>
                                    Default Feedback Form
                                </FormLabel>
                                <Switch id='gameDefaultFeedbackForm' name='gameDefaultFeedbackForm'  onChange={handleChange} colorScheme={'purple'} />
                            </FormControl>
                        </SimpleGrid>
                    </Card>
                </Box>
                <Box>
                    <Card>
                        <Text fontSize={18} fontWeight={800} mb={'20px'} >Welcome Page Background</Text>
                        <Flex overflowX={'auto'} width={'100%'} pb={'20px'}>                                                         
                                <Tooltip label='Scroll Img' placement='top'>
                                    <Img src={logo} h={'80px'} w={'80px'} mr={20} borderRadius={'8px'} boxShadow={'6px 5px 6px #4a4844ad'} id='1' onClick={(e) => updateImageBackGround(e)}/>
                                </Tooltip>                                  
                                <Tooltip label='Scroll Img' placement='top'>
                                    <Img src={badge} h={'80px'} w={'80px'} mr={20} borderRadius={'8px'} boxShadow={'6px 5px 6px #4a4844ad'} id='2' onClick={(e) => updateImageBackGround(e)}/>
                                </Tooltip>                                  
                                <Tooltip label='Scroll Img' placement='top'>
                                    <Img src={logo} h={'80px'} w={'80px'} mr={20} borderRadius={'8px'} boxShadow={'6px 5px 6px #4a4844ad'} id='3' onClick={(e) => updateImageBackGround(e)}/>
                                </Tooltip>                                  
                                <Tooltip label='Scroll Img' placement='top'>
                                    <Img src={badge} h={'80px'} w={'80px'} mr={20} borderRadius={'8px'} boxShadow={'6px 5px 6px #4a4844ad'} id='4'  onClick={(e) => updateImageBackGround(e)}/>
                                </Tooltip>                                  
                                <Tooltip label='Scroll Img' placement='top'>
                                    <Img src={logo} h={'80px'} w={'80px'} mr={20} borderRadius={'8px'} boxShadow={'6px 5px 6px #4a4844ad'} id='5' onClick={(e) => updateImageBackGround(e)}/>
                                </Tooltip>                                  
                                <Tooltip label='Scroll Img' placement='top'>
                                    <Img src={badge} h={'80px'} w={'80px'} mr={20} borderRadius={'8px'} boxShadow={'6px 5px 6px #4a4844ad'} id='6' onClick={(e) => updateImageBackGround(e)}/>
                                </Tooltip>                                  
                        </Flex>
                    </Card>
                </Box>
            </Box>                       
        </Flex>           
    </Box>
       
    </>
  )
}

export default GreetingsForm