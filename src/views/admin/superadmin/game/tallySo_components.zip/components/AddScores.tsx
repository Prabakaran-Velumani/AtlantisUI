import { Box, Button, Flex, FormControl, FormLabel, Grid, GridItem, HStack, Img, Radio, RadioGroup, SimpleGrid, Stack, Switch, Text } from "@chakra-ui/react"
import InputField from "components/fields/InputField"
import TextField from "components/fields/TextField"
import React, { useEffect, useRef, useState } from "react"
import Card from 'components/card/Card';
import SelectField from 'components/fields/SelectField';

import { getBackgrounds } from "utils/game/gameService"
interface OptionType {
  value: string;
  label: string;
}
const AddScores : React.FC<{handleChange:(e:any)=>void,formData:any,inputRef:any, updateHandleIntroMusic:(selectedOption: OptionType | null)=> void,setFormData: React.Dispatch<React.SetStateAction<any>> }>= ({handleChange,formData,inputRef,updateHandleIntroMusic,setFormData}) => {
    const [reflection,setReflection] = useState([''])
  
    const [img, setImg] = useState<any[]>([]);
  
  
   const [backgroundIndex, setBackgroundIndex] = useState<number>();
    const options = ['Private', 'Public'];
    const musicOptions = [
      { value: '1', label: 'Jazz' },
      { value: '2', label: 'Melodic Harmony' },
      { value: '3', label: 'Rhythmic Serenity'},
      { value: '4', label:  'Echoes of Euphoria' },
      { value: '5', label: 'Sonic Reverie' },
      {value:'6',label:'Tranquil Melodies'},
      {value:'7',label:'Harmonic Bliss'},
      {value:'8',label:'Mystical Cadence'},
      {value:'9',label:'Celestial Rhythms'},
      {value:'10',label:'Enchanted Sonata'},
      {value:'11',label:'Symphony of Dreams'},
    ];
    const handleFileChange = (e:any) => {
        const file = e.target.files[0];
        console.log('Selected file:', file);
      };
      const addReflection = () => {
        setReflection([...reflection, '']); 
      };
      const handleInputChange = (index:number, value:any) => {
        const updatedRows = [...reflection];
        updatedRows[index] = value;
        setReflection(updatedRows);
      };
      const fetchData = async () => {
        const result = await getBackgrounds();
        if (result?.status !== 'Success')
          return alert('getbackruond error:' + result?.message);
        setImg(result?.data);
       
      };
      const handleSetBackground = (i:any) =>{
        setBackgroundIndex(i);
        setFormData((prev:any) => ({
          ...prev,
          gameReflectionpageBackground:i
        }));
        
      }
      useEffect(() => {
        fetchData();
       console.log('formData',formData);
      }, [backgroundIndex]);
     
    return (
      <>
        <Box>
          <Box display={{base: 'block', md: 'flex', lg: 'flex'}}>
            <Card width={{sm: '100%', md:'80%', xl:'80%'}} mb={{base: '20px', xl: '20px'}} mr={{base: '0px', md: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                <Text fontSize={22} fontWeight={500} mb={'20px'}>
                  Score
                </Text>
                <SimpleGrid columns={{ base: 1, md: 1, xl: 2 }} spacing={5} mb={{base: '10px', xl: '10px'}}>              
                    <InputField
                        mb="0px"
                        me="30px"
                        id="gameMinScore"
                        label="MinScore"
                        placeholder="eg. 10"
                        name="gameMinScore"                
                        isRequired
                        value={formData?.gameMinScore}
                        onChange={handleChange}                
                    />                            
                    <InputField
                        mb="0px"
                        me="30px"
                        id="gameMaxScore"
                        label="MaxScore"
                        placeholder="eg. 200"
                        name="gameMaxScore"
                        value={formData?.gameMaxScore}
                        onChange={handleChange}                
                    />                                                                   
                </SimpleGrid>
                <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={1}>                                            
                  <InputField
                      mb="0px"
                      me="30px"                
                      id="gameTotalScore"
                      label="TotalScore"
                      placeholder="eg. 1000"
                      name="gameTotalScore"
                      value={formData?.gameTotalScore}
                      onChange={handleChange}                
                  />                             
                </SimpleGrid>
            </Card>
            <Card width={{sm: '100%', md:'20%', xl:'20%'}} mb={{base: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                <Text fontSize={22} fontWeight={500} mb={'20px'}>
                  Course Type
                </Text>
                <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={5} mb={{base: '10px', xl: '10px'}}>              
                  <FormControl>
                    <FormLabel htmlFor="alerts">Course Type</FormLabel>
                    <RadioGroup                 
                      id="alerts"
                    >
                      <Stack direction={{base: "column", xl: 'row'}} spacing={5}>
                        {options.map((option) => (
                          <Radio key={option} value={option} colorScheme="green" name="gameCourseType" onChange={handleChange}>
                            {option}
                          </Radio>
                        ))}
                      </Stack>
                    </RadioGroup>
                  </FormControl>
                </SimpleGrid>            
            </Card>
          </Box>
          <Box display={{base: 'block', md:'block', xl: 'flex'}}>                     
            <Card width={{sm: '100%', md:'100%', xl:'100%'}} mb={{base: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                <Box display={'flex'} justifyContent={'space-between'} alignItems={'center'} mb={'30px'}>
                  <Text fontSize={22} fontWeight={500}>
                    Reflection
                  </Text>
                  <Button
                      bg="#3311db"
                      color="#fff"
                      boxShadow="5px 5px 20px grey"                
                      mr="10px"                  
                      onClick={addReflection}
                    >
                      Add Reflection
                  </Button>
                </Box>
                <SimpleGrid columns={{ base: 1, md: 1, xl: 3 }} spacing={5} mb={{base: '10px', xl: '10px'}}>              
                  {reflection.map((value, index) => (                
                      <Box >
                        <TextField
                          mb="10px"
                          me="30px"
                          id="learningOutcome"                      
                          label={`Reflection Question ${index + 1}`}
                          placeholder="eg. Oliver"                      
                          value={value}                    
                        />                    
                      </Box>                
                  ))}
                </SimpleGrid>            
            </Card>                            
          </Box>  
          <Box display={{base: 'block', md:'block', xl: 'flex'}}>
            <Card width={{sm: '100%', md:'100%', xl:'50%'}} mb={{base: '20px', xl: '20px'}} mr={{base: '0px', md: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                <Text fontSize={22} fontWeight={500} mb={'20px'}>
                  Choose Image
                </Text>
                <SimpleGrid columns={{ base: 3, md: 3, xl: 3 }} spacing={5} mb={{base: '10px', xl: '10px'}}>                                
                    {img &&
                        img.map((img, i) => (
                            <Img
                            key={i}
                              src={img?.aniImages}
                              onClick={() => handleSetBackground(i)}
                              w="150px"
                              h="100px"
                              boxShadow={
                                backgroundIndex === i ? '5px 5px 20px grey' : ''
                              }
                              transform={backgroundIndex === i ?'scale(1.10)':''}
                              transition={'0.3s'}
                              borderRadius="8px"                        
                              cursor="pointer"
                            />
                        ))}                    
                </SimpleGrid>            
            </Card>

            <Box display={{base: 'block', md:'flex', xl: 'flex'}} width={{base: '100%', md: '100%', xl: '100%'}}>
              <Card width={{sm: '100%', md:'50%', xl:'50%'}} mb={{base: '20px', xl: '20px'}} mr={{base: '0px', md: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                      <Text fontSize={22} fontWeight={500} mb={'20px'}>
                        Game Audio / Upload
                      </Text>                          
                      <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={5} mb={{base: '10px', xl: '10px'}}>                                                                
                          <SelectField
                            mb="10px"
                            me="30px"
                            id="gameIntroMusic"
                            name="gameIntroMusic"
                            label="Game Intro Music"
                            options={musicOptions}
                            value={
                              musicOptions.find(
                                (option) => option.value === formData?.gameIntroMusic,
                              ) || null
                            }
                            onChange={updateHandleIntroMusic}
                          />    
                          <Box mt={'15px'} display={{base: 'flex', xl: 'flex'}} width={'100%'}>
                            <audio src={'audio'} controls />
                          </Box>                                                           
                      </SimpleGrid> 
                      <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={5}>
                        <input type='file' style={{display:'none', padding: '20px', border: '2px dashed #3311db'}}  ref={inputRef}  onChange={handleFileChange}/>  
                      </SimpleGrid>           
              </Card>
              <Card width={{sm: '100%', md:'50%', xl:'50%'}} mb={{base: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                  <Text fontSize={22} fontWeight={500} mb={'20px'}>
                    Switch On / Off
                  </Text>
                  <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={5} mb={{base: '10px', xl: '10px'}}>              
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="25px">
                        <FormLabel htmlFor="email-" mb="0">
                          Replay
                        </FormLabel>
                        <Switch colorScheme="purple" id="gameReplayAllowed" name="gameReplayAllowed" onChange={handleChange}/>
                    </FormControl>  
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="25px">
                      <FormLabel htmlFor="email-alerts" mb="0">
                        LeaderBoard
                      </FormLabel>
                      <Switch colorScheme="purple" id="gameLeaderboardAllowed" name="gameLeaderboardAllowed" onChange={handleChange}/>
                    </FormControl>   
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="25px">
                      <FormLabel htmlFor="email-alerts" mb="0">
                      Allowed Reflection
                      </FormLabel>
                      <Switch colorScheme="purple" id="gameReflectionpageAllowed" name="gameReflectionpageAllowed" onChange={handleChange} />
                    </FormControl>   
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="25px">
                      <FormLabel htmlFor="-alerts" mb="0">
                        FeedBack
                      </FormLabel>
                      <Switch colorScheme="purple" id="gameFeedbackQuestion" name="gameFeedbackQuestion" onChange={handleChange}/>
                    </FormControl>   
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="35px">
                      <FormLabel htmlFor="alerts" mb="0">
                        Shuffle
                      </FormLabel>
                      <Switch colorScheme="purple" size='lg' id="gameShuffle" name="gameShuffle" onChange={handleChange} />
                    </FormControl>                                                                                    
                  </SimpleGrid>            
              </Card> 
            </Box>
          </Box>        
        </Box>      
      </>
    );
}
export default AddScores;