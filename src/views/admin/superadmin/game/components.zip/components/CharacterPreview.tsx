
import React from 'react'
// Chakra Imports
import {
  Button,
  Badge,
  Box,
  Flex,
  Icon,
  Text,
  Image,
  useColorModeValue,
  useColorMode,
  useDisclosure,
  SimpleGrid,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  useBreakpointValue,  
  DrawerProps,
  Img,
  Select
} from '@chakra-ui/react';
import InputField from "components/fields/InputField"
import { useEffect, useState } from 'react';
import Light from '../../../../../assets/img/layout/Light.png';
import { HSeparator } from '../../../../../components/separator/Separator';
import { MdPlayArrow } from 'react-icons/md';


const CharacterPreview = (props: {players: any, setPreview: any, makeInputFiled: any, onClose: any, values : any , setValues : any,previewId:any,setFormData:any,formData:any}) => {

  const {players,setPreview, makeInputFiled, onClose, values, setValues,previewId,setFormData,formData} = props;

  //eslint-disable-next-line
  const { colorMode, toggleColorMode } = useColorMode();
  // const { isOpen, onOpen, onClose } = useDisclosure();
  const [active, setActive] = useState('Purple');
  const [contrast, setContrast] = useState(false);
  const [toggle, setToggle] = useState<any>();
  const [name, setname ] = useState('Purple');
  
  // const drawerSize = useBreakpointValue({ base: '100%', lg: '400px' });

 

  console.log('fetch', players);
  
  console.log('onOpen', makeInputFiled);
  
  const [showFullText, setShowFullText] = useState(false);
  const maxTextLength = 80; // Maximum characters to display before truncating

  const toggleShowFullText = () => {
    setShowFullText(!showFullText);
  };

  const textContent = "Game Content means any templates, modules, functions, features, images, audio data, video data, or other content that may be used by a Game Creator when creating a Game.";

  const truncatedText = showFullText ? textContent : `${textContent.slice(0, maxTextLength)}...`;

function handle() {
  
  console.log('fgfg', toggle)
  
  if(values === 'Selected'){
    setValues('Select')
  } 
  else if(values === 'Select'){
    setValues('Selected')
  }
}
const selectedPlayer = players.find((player:any) => player.gasId === previewId);

const handleNonPlayerVoice: React.ChangeEventHandler<HTMLSelectElement> = (e) => {


  setFormData((prev:any) => ({
    ...prev,
    gameNonPlayerVoice: e.target.value || '',
  }));
};
const handlePlayerMale: React.ChangeEventHandler<HTMLSelectElement> = (e) => {

  setFormData((prev:any) => ({
    ...prev,
    gamePlayerMaleVoice: e.target.value || '',
  }));
 
};

const handlePlayerFemale: React.ChangeEventHandler<HTMLSelectElement> = (e) => {


  setFormData((prev:any) => ({
    ...prev,
    gamePlayerFemaleVoice: e.target.value || '',
  }));
};
const handleNarrator: React.ChangeEventHandler<HTMLSelectElement> = (e) => {


  setFormData((prev:any) => ({
    ...prev,
    gameNarratorVoice: e.target.value || '',
  }));
};
const handleChange: React.ChangeEventHandler<HTMLSelectElement> = (e) => {


  setFormData((prev:any) => ({
    ...prev,
    gameNonPlayerName: e.target.value || '',
  }));
};






  return (
    <>

      <Modal isOpen={setPreview} onClose={setPreview}  size="lg">
      <ModalOverlay />
      <ModalContent
        maxW="1150px"  // Set the width manually
        height="750px" // Set the height manually
      >
        <ModalHeader p={2}>Preview</ModalHeader>
        <ModalCloseButton />
        <ModalBody p={0}>
 
    {/* Left side */}

    {  formData.gameNonPlayingCharacterId === previewId ? (
       <Flex>
      <Box flex="1"  p={4}>
      {/* Left content goes here */}
      <Img src={selectedPlayer.gasAssetImage} alt="Your Image" maxH="600px" w="100%" mb="4" />
    </Box>
    <Box flex="1" p={4}>
    <Box display="flex" alignItems="center" justifyContent="space-between" width="80%" marginBottom={'8px'}>
  {/* Left side */}
  <InputField
    mb={{ base: '1', md: '0' }}
    me={{ base: '0', md: '1' }}
    id="title"
    label=""
    placeholder="eg. Oliver"
    name="gameTitle"
    value={formData.gameNonPlayerName ?? selectedPlayer.gasAssetName}
    onChange={handleChange}
    w={{ base: '100%', md: '100%' }} // Adjust the width as needed
  />

  {/* Right side */}
  <Select
    fontSize="sm"
    id="nonPlayerVoice"
    variant="main"
    h="44px"
    maxH="44px"
    w={{ base: '100%', md: '45%' }} // Adjust the width as needed
    onChange={handleNonPlayerVoice}
    value={formData.gameNonPlayerVoice}
  >
    <option value="">Non Player Voice</option>
    <option value="">Narrator</option>
    <option value="1">Adam</option>
    <option value="2">Charlie</option>
    <option value="3">Freya</option>
    <option value="4">Domi</option>
    {/* Options here */}
  </Select>
</Box>
<Box  display="flex" alignItems="center" justifyContent="space-between" width="80%" marginBottom={'8px'}>
<Select
        fontSize="sm"
        id="playerMaleVoice"
        variant="main"
        h="44px"
        maxH="44px"
        w={{ base: '100%', md: '45%' }} // Adjust the width as needed
        onChange={handlePlayerMale}
        value={formData.gamePlayerMaleVoice}
      >
        <option value="">Player Male</option>
        <option value=""> Narrator </option>
<option value="1">Adam</option>
<option value="2">Charlie</option>
<option value="3">Freya</option>
<option value="4">Domi</option>
      </Select>

      <Select
        fontSize="sm"
        id="playerFemaleVoice"
        variant="main"
        h="44px"
        maxH="44px"
        w={{ base: '100%', md: '45%' }} // Adjust the width as needed
        onChange={handlePlayerFemale}
        value={formData.gamePlayerFemaleVoice}
      >
        <option value="">Player Female</option>
        <option value=""> Narrator </option>
<option value="1">Adam</option>
<option value="2">Charlie</option>
<option value="3">Freya</option>
<option value="4">Domi</option>
        {/* Options here */}
      </Select>

</Box>
<Box display="flex" alignItems="center" justifyContent="space-between" width="80%" marginBottom={'8px'}>
<Select
        marginTop={{ base: '4', md: '0' }}
        fontSize="sm"
        id="narratorVoice"
        variant="main"
        h="44px"
        maxH="44px"
        w={{ base: '100%', md: '45%' }} // Adjust the width as needed
        onChange={handleNarrator}
        value={formData.gameNarratorVoice}
      >
        <option value="">Narrator</option>
        <option value=""> Narrator </option>
<option value="1">Adam</option>
<option value="2">Charlie</option>
<option value="3">Freya</option>
<option value="4">Domi</option>
      </Select>
      <Button
                  bg="#3311db"
                  _hover={{ bg: '#3311db' }}
                  color="#fff"
                  w={{ base: '100%', md: '45%' }}
                  onClick={() => setPreview(false)}
                >
                  Save
</Button>

</Box>
      {/* Right content goes here */}
    </Box>
 </Flex>
     ) : 
    
    
    
    (
    <Flex  justifyContent="space-between" alignItems="center" flexDirection="column" h="100%">
   
      <Img src={selectedPlayer.gasAssetImage} alt="Your Image" maxH="600px" w="50%" mb="4" />
      
      
      
  </Flex>
  
    )} 
  
    
  
    {/* Right side */}
   
  
</ModalBody>
        

        <ModalFooter>
        <Button
                  bg="#3311db"
                  _hover={{ bg: '#3311db' }}
                  color="#fff"
                  w="80px"
                  onClick={() => makeInputFiled(previewId)}
                >
                 {formData.gameNonPlayingCharacterId === previewId ? (
    'Selected'
  ) : (
    'Select' // or any text you want to display when the condition is not met
  )}
                </Button>
        </ModalFooter>
       
      </ModalContent>
    </Modal>
    </>
  )
}

export default CharacterPreview