import { Box, Button, Flex, FormControl, FormLabel, Grid, GridItem, HStack, Img, Radio, RadioGroup, SimpleGrid, Stack, Switch, Table, Tbody, Td, Text, Th, Thead, Tr } from "@chakra-ui/react"
import InputField from "components/fields/InputField"
import TextField from "components/fields/TextField"
import React, { useEffect, useRef, useState } from "react"
import Card from 'components/card/Card';
import SelectField from 'components/fields/SelectField';
 
import { getImages, getBlocks } from "utils/game/gameService"
import { useParams } from "react-router-dom";
import { addBulkComplete } from "utils/complete/complete";

const CompletionScreen: React.FC<{ handleChange: (e: any) => void, formData: any, inputRef: any }> = ({ handleChange, formData, inputRef }) => {
  const [img, setImg] = useState<any[]>([]);
  const [isOpenBadge, setIsOpenBadge] = useState<any>(false);
  const [blocks, setBlocks] = useState<any[]>([]);
  const [backgroundIndex, setBackgroundIndex] = useState<number>();
  const [chosen, setChosen] = useState<any>('A');
  const options = [{ value: 'A', name: 'End Of Game' }, { value: 'B', name: 'Each Question' }];
  const musicOptions = [
    { value: 1, label: 'Jazz' },
    { value: 1, label: 'Melodic Harmony' }, 
    { value: 1, label: 'Rhythmic Serenity' },
    { value: 1, label: 'Echoes of Euphoria' },
    { value: 1, label: 'Sonic Reverie' },
    { value: 1, label: 'Tranquil Melodies' },
    { value: 1, label: 'Harmonic Bliss' },
    { value: 1, label: 'Mystical Cadence' },
    { value: 1, label: 'Celestial Rhythms' },
    { value: 1, label: 'Enchanted Sonata' },
    { value: 1, label: 'Symphony of Dreams' },
  ];
  const { id } = useParams();
  const fetchData = async () => {
    const result = await getImages(4);
    if (result?.status !== 'Success'){
      return alert('getbackruond error:' + result?.message);
    }
    setImg(result?.data);
   
    const block = await getBlocks(id);
    if (block?.status !== 'Success')
     return alert('getbackruond error:' + block?.message);
    setBlocks(block?.data);
  };
  const handleFileChange = (e: any) => {
    const file = e.target.files[0];
    console.log('Selected file:', file);
  };
  useEffect(() => {
    fetchData();
  }, []);
  const handleGa = (value: any) => {
    setChosen(value);
  }
  const handleComplete = (e: any, index: number,idv?:number) => {
    const { name, value, checked,id } = e.target;
    if (name === 'csBadge' || name === 'csSkillwiseScore') {
      setBlocks((prev) => {
        const newData = [...prev];
        newData[index] = {
          ...newData[index],
          [name]: checked,
        };
        return newData;
      });
    }
    else if(id ==='csBadge') {
      setBlocks((prev) => {
        const newData = [...prev];
        newData[index] = {
          ...newData[index],
          [id]: idv,
        };
        return newData;
      });
    }
    else {
      setBlocks((prev) => {
        const newData = [...prev];
        newData[index] = {
          ...newData[index],
          [name]: value,
        };
        return newData;
      });
    }
  };
 const save = async () =>{ 
     const bulk = blocks.map((item,index)=>{
        return {...item,csGameId:id,csBlockId:blocks[index]?.blockId,csType:'QUESTION'}
     })
     const data =JSON.stringify(bulk);
     const result = await addBulkComplete(data);
     if(result?.status !== 'Success') return console.log('bulk Upload Error:',result?.message);
     console.log(result?.data); 
 }

 const handleImg = () => {
    // setIsOpenBadge(!isOpenBadge);
 }
  console.log('badges',img);
  return (
    <Card mb={{ base: '0px', xl: '20px', sm: '20px' }}>
      <Text fontSize={20} fontWeight={800} mb={'20px'}>
        Launch
      </Text>
      <Box>
        <FormControl mt="25px">
          <FormLabel htmlFor="alerts">Badge Screen</FormLabel>
          <RadioGroup
            name="john"
            id="alerts"
            onChange={handleGa}
            value={chosen}
          >
            <Stack direction="row" spacing={5}>
              {options.map((option) => (
                <Radio key={option?.value} isChecked={option?.value === chosen} value={option?.value} colorScheme="green">
                  {option?.name}
                </Radio>
              ))}
            </Stack>
          </RadioGroup>
        </FormControl>
        {chosen === 'A' ? (
          <>
            <SimpleGrid columns={{ sm: 1, md: 2 }} spacing={{ base: '20px', xl: '20px' }}>
              <FormControl display="flex" alignItems="center" mt="25px">
                <FormLabel htmlFor="badge" mb="0">
                  Badge
                </FormLabel>
                <Switch colorScheme="green" id="badge" onChange={handleImg}  />
              </FormControl>
              <FormControl display="flex" alignItems="center" mt="25px">
                <FormLabel htmlFor="skill" mb="0">
                  Skill Wise Score
                </FormLabel>
                <Switch colorScheme="green" id="skill" />
              </FormControl>
              <InputField
                mb="0px"
                me="30px"
                id="title"
                label="Badge Name"
                placeholder="eg. 10"
                name="gameTitle"
                isRequired
              />
              <HStack className="daoaooa" display="flex" height="150px" width='auto' overflow="auto" spacing='24px'>
                {img &&
                  img.map((img, i) => (
                    <Img                    
                      key={i}
                      src={img?.gasAssetImage}
                      onClick={() => setBackgroundIndex(i)}
                      w="150px"
                      h="100px"
                      boxShadow={
                        backgroundIndex === i ? '5px 5px 20px grey' : ''
                      }
                      transform={backgroundIndex === i ? 'scale(1.10)' : ''}
                      transition={'0.3s'}
                      borderRadius="8px"
                      cursor="pointer"
                    />
                  )) 
                }
              </HStack >
              <FormControl>
                <Flex>
                  <input type='file' style={{ display: 'none' }} ref={inputRef} onChange={handleFileChange} />
                  <Button
                    bg="#3311db"
                    color="#fff"
                    boxShadow="5px 5px 20px grey"
                    // w="80px"
                    ml="10px"
                    mt="25px"
                    onClick={() => inputRef?.current?.click()}
                  >
                    New Badge
                  </Button>
                </Flex>
              </FormControl>
              <InputField
                mb="0px"
                me="30px"
                id="title"
                type='number'
                label="Min"
                placeholder="eg. 10"
                name="gameTitle"
                isRequired
              />
              <InputField
                mb="0px"
                me="30px"
                id="title"
                type='number'
                label="Max"
                placeholder="eg. 100"
                name="gameTitle"
                isRequired
              />
              <TextField
                mb="10px"
                me="30px"
                id="learningOutcome"
                label='Wish Message'
                placeholder="eg. Oliver"
                name="gameLearningOutcome"
              // value={value}
              // onChange={(e: any) =>
              //   handleInputChange(index, e.target.value)
              // }
              />

            </SimpleGrid>
          </>
        ) : (
          <>
            <HStack overflowX="auto">
              <Table variant={'striped'} boxShadow={'1px 2px 17px #f7f7f7'} >
                <Thead>
                  <Tr borderBottom={'2px solid #f7f7f7'}>
                    <Th>Question Title</Th>
                    <Th>Badge Enable</Th>
                    <Th>Skill Wise Score</Th>
                    <Th>Badge Name</Th>
                    <Th>Badge</Th>
                    <Th>Add New Badge</Th>
                    <Th>Minimum Score</Th>
                    <Th>Maximum Score</Th>
                    <Th>Wish Message</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {blocks&&blocks.map((row, i) => (
                    <Tr key={i} whiteSpace={'nowrap'}>
                      <Td>
                        <Text>{row?.blockTitleTag}</Text>
                      </Td>
                      <Td>
                        <FormControl display="flex" alignItems="center" mt="25px">
                          <Switch colorScheme="green" id="badge" name="csBadge" onChange={(e) => handleComplete(e, i)} />
                        </FormControl>
                      </Td>
                      <Td>
                        <FormControl display="flex" alignItems="center" mt="25px">
                          <Switch colorScheme="green" id="skill" name="csSkillwiseScore" onChange={(e) => handleComplete(e, i)} />
                        </FormControl>
                      </Td>
                      <Td>
                        <InputField
                          mb="0px"
                          me="30px"
                          id="title"
                          type="text"
                          placeholder="eg. 10"
                          name="csBadgeName"
                          onChange={(e: any) => handleComplete(e, i)}
                        />
                      </Td>
                      <Td>
                        <HStack display="flex" height="150px" width='auto' overflow="auto" spacing='24px'>
                          {img &&
                            img.map((img, index) => (
                              <Img
                                key={index}
                                src={img?.gasAssetImage}
                                id="csBadge"
                                onClick={(e) => handleComplete(e,i,img?.gasId)}
                                w="150px"
                                h="100px"
                                boxShadow={
                                  backgroundIndex === i ? '5px 5px 20px grey' : ''
                                }
                                transform={backgroundIndex === i ? 'scale(1.10)' : ''}
                                transition={'0.3s'}
                                borderRadius="8px"
                                cursor="pointer"
                              />
                            ))}
                        </HStack >
                      </Td>
                      <Td>
                        <FormControl>
                          <Flex>
                            <input type='file' style={{ display: 'none' }} ref={inputRef} onChange={handleFileChange} />
                            <Button
                              bg="#3311db"
                              color="#fff"
                              boxShadow="5px 5px 20px grey"
                              ml="10px"
                              mt="25px"
                              onClick={() => inputRef?.current?.click()}
                            >
                              New Badge
                            </Button>
                          </Flex>
                        </FormControl>
                      </Td>
                      <Td>
                        <InputField
                          mb="0px"
                          me="30px"
                          id="title"
                          type='number'
                          placeholder="eg. 10"
                          name="csMinScore"
                          onChange={(e: any) => handleComplete(e, i)}
                        />
                      </Td>
                      <Td>
                        <InputField
                          mb="0px"
                          me="30px"
                          id="title"
                          type='number'
                          placeholder="eg. 100"
                          name="csMaxScore"
                          onChange={(e: any) => handleComplete(e, i)}
                        />
                      </Td>
                      <Td>
                        <TextField
                          mb="10px"
                          me="30px"
                          id="learningOutcome"
                          placeholder="eg. Oliver"
                          name="csWishMessage"
                          onChange={(e: any) => handleComplete(e, i)}
                        />
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </HStack>
          </>
        )}
      </Box>
      {/* <Button mt='10px' bg="green.500" onClick={save}>Save</Button> */}
    </Card>
  );
}
export default CompletionScreen;