import {    Box,   } from '@chakra-ui/react'
import { DragDropContext, Droppable, Draggable, DropResult } from 'react-beautiful-dnd';


type ItemType = {
    id: string;
    name: string;
    content: string;
  };
  

const CustomAccordion = (props: { items: any, setItems: any, sequence?: any, children?: any, upNextCount?: any }) => {

    const {items, setItems, sequence, children, upNextCount} = props;

    const onDragEnd = (result: DropResult) => {
        if (!result.destination) {
          return;
        }
    
        // const reorderedItems = Array.from(items);
        const reorderedItems: ItemType[] = Array.from(items);
        const [movedItem] = reorderedItems.splice(result.source.index, 1);
        reorderedItems.splice(result.destination.index, 0, movedItem);           

         // Update the id based on the original order        
        const updatedItems = reorderedItems.map((item: ItemType, index) => ({ ...item, id: sequence[index] || item.id, upNext: upNextCount[index]  }));

        
        setItems(updatedItems);    
        console.log('reorderedItems', updatedItems);
    };

    return (
    <Box>
        <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="your-droppable-id">
                {(provided) => (
                    <div {...provided.droppableProps} ref={provided.innerRef} className='hooky'>
                        {/* {items.map((item, index) => (             */}
                        {children}
                        {provided.placeholder}
                    </div>
                )}
            </Droppable>
        </DragDropContext>            
    </Box>
    );
};



export default CustomAccordion