import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogCloseButton,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  Box,
  Button,
  Flex,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  HStack,
  Icon,
  Img,
  Radio,
  RadioGroup,
  SimpleGrid,
  Stack,
  Switch,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  useColorModeValue,
  useDisclosure,
  useTheme,
} from '@chakra-ui/react';
import InputField from 'components/fields/InputField';
import TextField from 'components/fields/TextField';
import React, { useEffect, useRef, useState } from 'react';
import Card from 'components/card/Card';
import SelectField from 'components/fields/SelectField';

import { getImages } from 'utils/game/gameService';
import Dropzone from 'views/admin/main/ecommerce/settingsProduct/components/Dropzone';
import { MdOutlineCloudUpload } from 'react-icons/md';
interface OptionType {
  value: string;
  label: string;
}
/********navin */
const AddScores: React.FC<{
  handleChange: (e: any) => void;
  formData: any;
  inputRef: any;
  updateHandleIntroMusic: (selectedOption: OptionType | null) => void;
  setFormData: React.Dispatch<React.SetStateAction<any>>;
  setTab:any
  isOpen:any;
  onOpen:any;
   onClose:any;
  cancelRef:any;
  productTab:any;
  mediaTab:any;
  pricingTab:any;
  takeawayTab:any;
  welcomeTab:any;
  thankyouTab:any;
}> = ({
  handleChange,
  formData,
  inputRef,
  updateHandleIntroMusic,
  setFormData,setTab,
  isOpen, onOpen, onClose,
  cancelRef,productTab,mediaTab,pricingTab,takeawayTab,welcomeTab,thankyouTab,
}) => {
  /**********navin */
    const [reflection, setReflection] = useState(['']);
    const [arra, setArra] = useState();
    const [img, setImg] = useState<any[]>([]);
    const [value, setValue] = React.useState('1');
    const [openQuest, setOpenQuest] = useState(false);
    const textColor = useColorModeValue('secondaryGray.900', 'white');
    const [activeBullets, setActiveBullets] = useState({
      product: true,
      media: false,
      pricing: false,
    });
    // const { isOpen, onOpen, onClose } = useDisclosure();
    // const cancelRef = React.useRef();
    // const productTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
    // const mediaTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
    // const pricingTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
    // const takeawayTab =React.useRef() as React.MutableRefObject<HTMLInputElement>;
    // const welcomeTab = React.useRef() as React.MutableRefObject<HTMLInputElement>;
    // const thankyouTab =React.useRef() as React.MutableRefObject<HTMLInputElement>;
    const theme = useTheme();
    //eslint-disable-next-line
    const [lineColor, setLineColor] = useState(theme.colors.brand[500]);
    //eslint-disable-next-line
    const [lineColorDark, setLineColorDark] = useState(theme.colors.brand[400]);
    const brand = useColorModeValue(lineColor, lineColorDark);
    const textColorPrimary = useColorModeValue('secondaryGray.900', 'white');
    const [backgroundIndex, setBackgroundIndex] = useState<number>();
    const options = ['Private', 'Public'];
    const musicOptions = [
      { value: '1', label: 'Jazz' },
      { value: '2', label: 'Melodic Harmony' },
      { value: '3', label: 'Rhythmic Serenity' },
      { value: '4', label: 'Echoes of Euphoria' },
      { value: '5', label: 'Sonic Reverie' },
      { value: '6', label: 'Tranquil Melodies' },
      { value: '7', label: 'Harmonic Bliss' },
      { value: '8', label: 'Mystical Cadence' },
      { value: '9', label: 'Celestial Rhythms' },
      { value: '10', label: 'Enchanted Sonata' },
      { value: '11', label: 'Symphony of Dreams' },
    ];
    const handleFileChange = (e: any) => {
      const file = e.target.files[0];
      console.log('Selected file:', file);
    };
    const addReflection = () => {
      setReflection([...reflection, '']);
    };
    const handleInputChange = (index: number, value: any) => {
      const updatedRows = [...reflection];
      updatedRows[index] = value;
      setReflection(updatedRows);
    };
    const fetchData = async () => {
      const result = await getImages(6);
      if (result?.status !== 'Success')
        return alert('getbackruond error:' + result?.message);
      setImg(result?.data);
    };
    const handleSetBackground = (i: any) => {
      setBackgroundIndex(i);
      setFormData((prev: any) => ({
        ...prev,
        gameReflectionpageBackground: i,
      }));
    };
    useEffect(() => {
      fetchData();
      console.log('formData', formData);
    }, [backgroundIndex]);
    const refs = Array.from({ length: arra }, (_, index) => index + 1);
    const handleAdd = () => {
      onClose();
      setTimeout(() => {
        setOpenQuest(true);
      }, 500);
    };

    return (
      <>
        <Box width={'100%'}>
          <Tabs
            variant="unstyled"
            zIndex="0"
            display="flex"
            flexDirection="column"
          >
            <TabList
              display="none"
              alignItems="center"
              alignSelf="center"
              justifySelf="center"
            >
              <Tab
                _focus={{ border: '0px', boxShadow: 'unset' }}
                ref={productTab}
                w={{ sm: '120px', md: '250px', lg: '300px' }}
                onClick={() =>
                  setActiveBullets({
                    product: true,
                    media: false,
                    pricing: false,
                  })
                }
              >
                <Flex
                  direction="column"
                  // justify="center"
                  // align="center"
                  position="relative"
                  _before={{
                    content: "''",
                    width: { sm: '120px', md: '250px', lg: '300px' },
                    height: '3px',
                    bg: activeBullets.media ? 'white' : 'brand.400',
                    left: { sm: '12px', md: '40px' },
                    top: {
                      sm: activeBullets.product ? '6px' : '4px',
                      md: null,
                    },
                    position: 'absolute',
                    bottom: activeBullets.product ? '40px' : '38px',

                    transition: 'all .3s ease',
                  }}
                >
                  <Box
                    zIndex="1"
                    border="2px solid"
                    borderColor={activeBullets.product ? 'white' : 'brand.400'}
                    bgGradient="linear(to-b, brand.400, brand.600)"
                    w="16px"
                    h="16px"
                    mb="8px"
                    borderRadius="50%"
                  />
                  <Text
                    color={activeBullets.product ? 'white' : 'gray.300'}
                    fontWeight={activeBullets.product ? 'bold' : 'normal'}
                    display={{ sm: 'none', md: 'block' }}
                  >
                    Product Info
                  </Text>
                </Flex>
              </Tab>
              <Tab
                _focus={{ border: '0px', boxShadow: 'unset' }}
                ref={mediaTab}
                w={{ sm: '120px', md: '250px', lg: '300px' }}
                onClick={() =>
                  setActiveBullets({
                    product: true,
                    media: true,
                    pricing: false,
                  })
                }
              >
                <Flex
                  direction="column"
                  justify="center"
                  align="center"
                  position="relative"
                  _before={{
                    content: "''",
                    width: { sm: '120px', md: '250px', lg: '300px' },
                    height: '3px',
                    bg: activeBullets.pricing ? 'white' : 'brand.400',
                    left: { sm: '12px', md: '28px' },
                    top: '6px',
                    position: 'absolute',
                    bottom: activeBullets.media ? '40px' : '38px',

                    transition: 'all .3s ease',
                  }}
                >
                  <Box
                    zIndex="1"
                    border="2px solid"
                    borderColor={activeBullets.media ? 'white' : 'brand.400'}
                    bgGradient="linear(to-b, brand.400, brand.600)"
                    w="16px"
                    h="16px"
                    mb="8px"
                    borderRadius="50%"
                  />
                  <Text
                    color={activeBullets.media ? 'white' : 'gray.300'}
                    fontWeight={activeBullets.media ? 'bold' : 'normal'}
                    display={{ sm: 'none', md: 'block' }}
                  >
                    Media
                  </Text>
                </Flex>
              </Tab>
              <Tab
                _focus={{ border: '0px', boxShadow: 'unset' }}
                ref={pricingTab}
                w={{ sm: '120px', md: '250px', lg: '300px' }}
                onClick={() =>
                  setActiveBullets({
                    product: true,
                    media: true,
                    pricing: true,
                  })
                }
              >
                <Flex
                  direction="column"
                  justify="center"
                  align="center"
                  position="relative"
                >
                  <Box
                    zIndex="1"
                    border="2px solid"
                    borderColor={activeBullets.pricing ? 'white' : 'brand.400'}
                    bgGradient="linear(to-b, brand.400, brand.600)"
                    w="16px"
                    h="16px"
                    mb="8px"
                    borderRadius="50%"
                  />
                  <Text
                    color={activeBullets.pricing ? 'white' : 'gray.300'}
                    fontWeight={activeBullets.pricing ? 'bold' : 'normal'}
                    display={{ sm: 'none', md: 'block' }}
                  >
                    Pricing
                  </Text>
                </Flex>
              </Tab>
              <Tab
                _focus={{ border: '0px', boxShadow: 'unset' }}
                ref={takeawayTab}
                w={{ sm: '120px', md: '250px', lg: '300px' }}
                onClick={() =>
                  setActiveBullets({
                    product: true,
                    media: true,
                    pricing: true,
                  })
                }
              >
                <Flex
                  direction="column"
                  justify="center"
                  align="center"
                  position="relative"
                >
                  <Box
                    zIndex="1"
                    border="2px solid"
                    borderColor={activeBullets.pricing ? 'white' : 'brand.400'}
                    bgGradient="linear(to-b, brand.400, brand.600)"
                    w="16px"
                    h="16px"
                    mb="8px"
                    borderRadius="50%"
                  />
                  <Text
                    color={activeBullets.pricing ? 'white' : 'gray.300'}
                    fontWeight={activeBullets.pricing ? 'bold' : 'normal'}
                    display={{ sm: 'none', md: 'block' }}
                  >
                    Pricing
                  </Text>
                </Flex>
              </Tab>
              <Tab
                _focus={{ border: '0px', boxShadow: 'unset' }}
                ref={welcomeTab}
                w={{ sm: '120px', md: '250px', lg: '300px' }}
                onClick={() =>
                  setActiveBullets({
                    product: true,
                    media: true,
                    pricing: true,
                  })
                }
              >
                <Flex
                  direction="column"
                  justify="center"
                  align="center"
                  position="relative"
                >
                  <Box
                    zIndex="1"
                    border="2px solid"
                    borderColor={activeBullets.pricing ? 'white' : 'brand.400'}
                    bgGradient="linear(to-b, brand.400, brand.600)"
                    w="16px"
                    h="16px"
                    mb="8px"
                    borderRadius="50%"
                  />
                  <Text
                    color={activeBullets.pricing ? 'white' : 'gray.300'}
                    fontWeight={activeBullets.pricing ? 'bold' : 'normal'}
                    display={{ sm: 'none', md: 'block' }}
                  >
                    Pricing
                  </Text>
                </Flex>
              </Tab>
              <Tab
                _focus={{ border: '0px', boxShadow: 'unset' }}
                ref={thankyouTab}
                w={{ sm: '120px', md: '250px', lg: '300px' }}
                onClick={() =>
                  setActiveBullets({
                    product: true,
                    media: true,
                    pricing: true,
                  })
                }
              >
                <Flex
                  direction="column"
                  justify="center"
                  align="center"
                  position="relative"
                >
                  <Box
                    zIndex="1"
                    border="2px solid"
                    borderColor={activeBullets.pricing ? 'white' : 'brand.400'}
                    bgGradient="linear(to-b, brand.400, brand.600)"
                    w="16px"
                    h="16px"
                    mb="8px"
                    borderRadius="50%"
                  />
                  <Text
                    color={activeBullets.pricing ? 'white' : 'gray.300'}
                    fontWeight={activeBullets.pricing ? 'bold' : 'normal'}
                    display={{ sm: 'none', md: 'block' }}
                  >
                    Pricing
                  </Text>
                </Flex>
              </Tab>
            </TabList>
            <TabPanels maxW={{ md: '90%', lg: '100%' }} mx="auto">
              <TabPanel w={'100%'} p="0px" mx="auto">
                <Box>
                  <Text
                    color={textColor}
                    fontSize={'21'}
                    fontWeight="700"

                  >
                    Completion Screen
                  </Text>
                  <Text
                    color={textColor}
                    fontSize={'14'}
                    fontWeight="700"

                  >
                    This screen shows in-game score and will appear at the end of the quest
                  </Text>
                  <Flex direction="column" w="100%">
                    <SimpleGrid columns={{ base: 1, md: 2 }} gap="20px">
                      <Stack direction="column" gap="20px">
                        <Card h={'500px'}></Card>
                      </Stack>
                      <Stack direction="column" gap="20px">
                        <Card h={'500px'}>
                          {/* <Text fontSize={20} fontWeight={700}>
                          Screen Title
                        </Text>
                        <InputField
                          mb="0px"
                          id="Collection"
                          placeholder="eg. Modernary"
                          // label="Screen Title"
                        /> */}
                          <Text fontSize={18} fontWeight={700}>
                            Score
                          </Text>
                          <SimpleGrid columns={{ base: 1, md: 1 }} gap="20px" >
                            <Flex align="center">
                              <Text mr={2} fontSize="sm" fontWeight="bold" width="100px">
                                Total Score:
                              </Text>
                              <InputField
                                mb="0px"
                                id="gameTotalScore"
                                type="number"
                                placeholder="eg. 1000"
                                name="gameTotalScore"
                                w="150px" // Adjust the width as needed
                                value={formData?.gameTotalScore}
                               onChange={handleChange}
                              />
                            </Flex>
                          </SimpleGrid>


                          <SimpleGrid
                            columns={{ base: 1, md: 2 }}
                            gap="20px"
                           
                          >
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent="space-between"

                            >
                              <FormLabel
                                htmlFor="email-"
                                mb="0"
                                fontSize="sm"
                                fontWeight="bold"
                                color={textColorPrimary}
                                mr="2" // Adjust the margin to reduce space
                              >
                                Set Minimum Pass Score
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>


                            <Flex align="center">
                              <Text mr={2} fontSize="sm" fontWeight="bold" width="100px">
                                Minimum Score:
                              </Text>
                              <InputField
                                mb="0px"
                                id="gameMinScore"
                                name="gameMinScore"
                                type="number"
                                placeholder="eg. 1000"
                                w="150px" // Adjust the width as needed
                                value={formData?.gameMinScore}
                                onChange={handleChange}
                              />
                            </Flex>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                             
                            >
                              <FormLabel htmlFor="email-" mb="0" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Set Disticntion Score
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            
                            <Flex align="center">
                              <Text mr={2} fontSize="sm" fontWeight="bold" width="100px">
                              Distinction Score:
                              </Text>
                              <InputField
                                mb="0px"
                                id="gameDistinctionScore"
                                name="gameDistinctionScore"
                                type="number"
                                placeholder="eg. 1000"
                                w="150px" // Adjust the width as needed
                                value={formData?.gameDistinctionScore}
                                onChange={handleChange}
                              />
                            </Flex>
                          
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                            
                            >
                              <FormLabel htmlFor="email-" mb="0" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Skill Wise Score
                              </FormLabel>
                              <Switch
                               color="#fff"
                               colorScheme='brandScheme'
                               size='md'
                                // colorScheme="purple"
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                // onChange={handleChange}
                                // variant='main'
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                            
                            >
                              
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                            
                            >
                              <FormLabel htmlFor="email-" mb="0" fontSize='sm' fontWeight='bold' color={textColorPrimary} mt={'20px'}>
                              <Text fontSize={18} fontWeight={700}>
                              Badge
                          </Text>
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                // colorScheme="purple"
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                            
                            >
                              
                            </FormControl>
                            <Flex alignItems="center">
  <Text
    fontSize="sm"
    fontWeight="bold"
    color={textColorPrimary}
    mb="10px"
    mr="45px" // Adjust the margin to your preference
  >
    Select Badge:
  </Text>
  <Dropzone
    content={
      <Box maxW="100%" textAlign="center">
        <Icon
          as={MdOutlineCloudUpload}
          w="30px" // Adjust the width to reduce the icon size
          h="30px" // Adjust the height to reduce the icon size
          color={textColor}
        />
        {/* Other content */}
      </Box>
    }
    style={{
      border: '2px dashed #A0AEC0', // Adjust the border style
      borderRadius: '4px', // Adjust the border radius (smaller value for a more rectangular shape)
      width: '140px', // Adjust the overall width for a more horizontal shape
      height: '50px', // Adjust the overall height for a more horizontal shape
    }}
  />
</Flex>
<Flex align="center">
                              <Text mr={2} fontSize="sm" fontWeight="bold" width="100px">
                              Badge Name:
                             
                              </Text>
                              <InputField
                                mb="0px"
                                id="gameBadgeName"   
                                name="gameBadgeName"                                                           
                                placeholder="eg. Bronze"
                                w="150px" // Adjust the width as needed
                                value={formData?.gameBadgeName}
                                onChange={handleChange}
                              />
                            </Flex>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="0" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Criteria For Badge
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <Flex align="center">
                              <Text mr={2} fontSize="sm" fontWeight="bold" width="100px">
                              Score Greater Than:
                             
                              </Text>
                              <InputField
                                mb="0px"
                                id="gameAwardBadgeScore"   
                                name="gameAwardBadgeScore"                                                           
                                placeholder="eg. 200"
                                w="150px" // Adjust the width as needed
                                value={formData?.gameAwardBadgeScore}
                                onChange={handleChange}
                              />
                            </Flex>
                          </SimpleGrid>
                        </Card>
                      </Stack>
                    </SimpleGrid>
                   
                    <SimpleGrid
                      columns={{ base: 1, md: 1 }}
                      gap="20px"
                      mt={'20px'}
                    >
                      <Card>
                      <SimpleGrid
                          columns={{ base: 1, md: 3 }}
                          gap="20px"
                          mt={'10px'}
                        >
                       <Flex direction="column" >
  <Text fontSize={18} fontWeight={700}>
    Screen Title
  </Text>
  <TextField
    mb="0px"   
    placeholder="eg. Modernary"
    width={'50%'}
    id="gameScreenTitle"
    name="gameScreenTitle"
    value={formData?.gameScreenTitle}
    onChange={handleChange}
    // label="Screen Title"
  />
  {/* Additional InputField below Screen Title */}
 
</Flex>
<Flex direction="column" >
                        <Text fontSize={18} fontWeight={700}>
                          Congratulatory Message
                        </Text>
                        <FormControl
                            display="flex"
                            alignItems="center"
                            justifyContent={'space-between'}
                            mt="20px"
                          >
                            <FormLabel htmlFor="email-" mb="0" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                              Single Message
                            </FormLabel>
                            <Switch
                              color="#fff"
                              colorScheme='brandScheme'
                              size='md'
                              id="gameReplayAllowed"
                              name="gameReplayAllowed"
                              onChange={handleChange}
                            />
                          </FormControl>
                          <FormControl
                            display="flex"
                            alignItems="center"
                            justifyContent={'space-between'}
                            mt="20px"
                          >
                            <FormLabel htmlFor="email-" mb="0" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                              Score-Wise Message
                            </FormLabel>
                            <Switch
                              color="#fff"
                              colorScheme='brandScheme'
                              size='md'
                              id="gameReplayAllowed"
                              name="gameReplayAllowed"
                              onChange={handleChange}
                            />
                          </FormControl>
                        </Flex>
                        <TextField
                            mb="10px"
                            me="30px"
                            placeholder="eg. Congratulations! You have completed..."
                            mt="20px"
                            id="gameCompletedCongratsMessage"
                            name="gameCompletedCongratsMessage"
                            value={formData?.gameCompletedCongratsMessage}
                            onChange={handleChange}
                          />
                        <FormControl></FormControl>
                         
                          <FormControl></FormControl>
                         
                          <FormControl></FormControl>
                         
                          
                          <TextField
                            mb="10px"
                            me="30px"
                            label="For less than minimum score:"
                            placeholder="eg. You can do bette..."
                            id="gameMinimumScoreCongratsMessage"
                            name="gameMinimumScoreCongratsMessage"
                            value={formData?.gameMinimumScoreCongratsMessage}
                            onChange={handleChange}
                          />
                          <TextField
                            mb="10px"
                            me="30px"
                            label="For less than distinction score:"
                            placeholder="eg. Good performance! You..."
                            id="gameLessthanDistinctionScoreCongratsMessage"
                            name="gameLessthanDistinctionScoreCongratsMessage"
                            value={formData?.gameLessthanDistinctionScoreCongratsMessage}
                            onChange={handleChange}
                          />
                          <TextField
                            mb="10px"
                            me="30px"
                            label="For above distinction score:"                           
                            placeholder="eg. Fantastic performance! You..."
                            id="gameAboveDistinctionScoreCongratsMessage"
                            name="gameAboveDistinctionScoreCongratsMessage"
                            value={formData?.gameAboveDistinctionScoreCongratsMessage}
                            onChange={handleChange}
                          />
                        </SimpleGrid>
                      </Card>
                    </SimpleGrid>
                    <Flex justify="space-between" mt="24px">
                      <Button
                        
                        
                        bg="#3311db"
                        _hover={{ bg: '#3311db' }}
                        color="#fff"
                        w="80px"
                       
                        onClick={() => mediaTab.current.click()}
                      >
                        Next
                      </Button>
                    </Flex>
                  </Flex>
                </Box>
              </TabPanel>
              <TabPanel w={'100%'} p="0px" mx="auto">
                <Box p="30px">
                  <Text
                    color={textColor}
                    fontSize={'21'}
                    fontWeight="700"
                    mb="20px"
                  >
                    LeaderBoards Screen
                  </Text>
                  <Text
                    color={textColor}
                    fontSize={'14'}
                    fontWeight="700"

                  >
                   This screen encourages learners to improve their score
                  </Text>
                  <Flex direction="column" w="100%">
                    <SimpleGrid columns={{ base: 1, md: 2 }} gap="20px">
                      <Stack direction="column" gap="20px">
                        <Card h={'500px'}></Card>
                      </Stack>
                      <Stack direction="column" gap="20px">
                        <Card>
                          <FormControl
                            display="flex"
                            alignItems="center"
                            justifyContent={'space-between'}
                            mt="20px"
                          >
                            <FormLabel htmlFor="email-" mb="0" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                              Show Leaderboard to Learners
                            </FormLabel>
                            <Switch
                              color="#fff"
                              colorScheme='brandScheme'
                              size='md'
                              id="gameReplayAllowed"
                              name="gameReplayAllowed"
                              onChange={handleChange}
                            />
                          </FormControl>
                        </Card>
                      </Stack>
                    </SimpleGrid>
                    <Flex justify="space-between" mt="24px">
                      <Button
                        variant="light"
                        fontSize="sm"
                        borderRadius="16px"
                        w={{ base: '128px', md: '148px' }}
                        h="46px"
                        onClick={() => productTab.current.click()}
                      >
                        Prev
                      </Button>
                      <Button
                       bg="#3311db"
                       _hover={{ bg: '#3311db' }}
                       color="#fff"
                       w="80px"
                        onClick={() => pricingTab.current.click()}
                      >
                        Next
                      </Button>
                    </Flex>
                  </Flex>
                </Box>
              </TabPanel>
              <TabPanel w={'100%'} p="0px" mx="auto">
                <Box p="30px">
                  <Text
                    color={textColor}
                    fontSize={'21'}
                    fontWeight="700"
                    mb="20px"
                  >
                    Reflection Screen
                  </Text>
                  <Flex direction="column" w="100%">
                    <SimpleGrid columns={{ base: 1, md: 2 }} gap="20px">
                      <Stack direction="column" gap="20px">
                        <Card h={'500px'}></Card>
                      </Stack>
                      <Stack direction="column" gap="20px">
                        <Card>
                          <FormControl
                            display="flex"
                            alignItems="center"
                            justifyContent={'space-between'}
                            mt="20px"
                          >
                            <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                              Show Reflection Screen
                            </FormLabel>
                            <Switch
                              color="#fff"
                              colorScheme='brandScheme'
                              size='md'
                              id="gameReplayAllowed"
                              name="gameReplayAllowed"
                              onChange={handleChange}
                            />
                          </FormControl>
                          <InputField
                            mb="0px"
                            id="Collection"
                            type="number"
                            placeholder="eg. 10"
                            label="How many questions would you like?"
                            onChange={(e: any) => setArra(e.target.value)}
                          />
                          <FormControl
                            display="flex"
                            alignItems="center"
                            justifyContent={'space-between'}
                            mt="20px"
                          >
                            <FormLabel htmlFor="email-" mb="0" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                              Make these questions mandatory for the learner
                            </FormLabel>
                            <Switch
                              color="#fff"
                              colorScheme='brandScheme'
                              size='md'
                              id="gameReplayAllowed"
                              name="gameReplayAllowed"
                              onChange={handleChange}
                            />
                          </FormControl>
                        </Card>
                      </Stack>
                    </SimpleGrid>
                    <SimpleGrid columns={{ base: 1, md: 1 }} mt={'20px'}>
                      {arra && (
                        <Card>
                          <SimpleGrid columns={{ base: 1, md: 3 }} gap={6}>
                            {refs.map((it, i) => (
                              <Stack key={i} gap="20px">
                                <TextField
                                  key={i}
                                  mb="0px"
                                  id="Collection"
                                  placeholder="eg. How can you apply these learnings back at work?"
                                  label={`Reflection Question ${i + 1}`}
                                />
                              </Stack>
                            ))}
                          </SimpleGrid>
                        </Card>
                      )}
                    </SimpleGrid>
                    <Flex justify="space-between" mt="24px">
                      <Button
                        variant="light"
                        fontSize="sm"
                        borderRadius="16px"
                        w={{ base: '128px', md: '148px' }}
                        h="46px"
                        onClick={() => mediaTab.current.click()}
                      >
                        Prev
                      </Button>
                      <Button
                         bg="#3311db"
                         _hover={{ bg: '#3311db' }}
                         color="#fff"
                         w="80px"
                        onClick={() => takeawayTab.current.click()}
                      >
                        Next
                      </Button>
                    </Flex>
                  </Flex>
                </Box>
              </TabPanel>
              <TabPanel w={'100%'} p="0px" mx="auto">
                <Box p="30px">
                  <Text
                    color={textColor}
                    fontSize={'21'}
                    fontWeight="700"
                    mb="20px"
                  >
                    Take Aways Screen
                  </Text>

                  <Flex direction="column" w="100%">
                    <SimpleGrid columns={{ base: 1, md: 2 }} gap="20px">
                      <Stack direction="column" gap="20px">
                        <Card h={'500px'}></Card>
                      </Stack>
                      <Stack direction="column" gap="20px">
                        <Card>
                          <SimpleGrid columns={{ base: 1, md: 1 }} gap="20px">
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Show TakeAways
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <TextField
                              mb="0px"
                              placeholder="eg. Try to understand what went wrong before reacting"
                              label="TakeAways Content"
                              id="gameTakeawayContent"
                              name="gameTakeawayContent"
                              value={formData?.gameTakeawayContent}
                              onChange={handleChange}
                            />
                          </SimpleGrid>
                        </Card>
                      </Stack>
                    </SimpleGrid>
                    <Flex justify="space-between" mt="24px">
                      <Button
                        variant="light"
                        fontSize="sm"
                        borderRadius="16px"
                        w={{ base: '128px', md: '148px' }}
                        h="46px"
                        onClick={() => pricingTab.current.click()}
                      >
                        Prev
                      </Button>
                      <Button
                          bg="#3311db"
                          _hover={{ bg: '#3311db' }}
                          color="#fff"
                          w="80px"
                        onClick={() => welcomeTab.current.click()}
                      >
                        Next
                      </Button>
                    </Flex>
                  </Flex>
                </Box>
              </TabPanel>
              <TabPanel w={'100%'} p="0px" mx="auto">
                <Box p="30px">
                  <Text
                    color={textColor}
                    fontSize={'21'}
                    fontWeight="700"
                    mb="20px"
                  >
                    Welcome Screen
                  </Text>
                  <Flex direction="column" w="100%">
                    <SimpleGrid columns={{ base: 1, md: 2 }} gap="20px">
                      <Stack direction="column" gap="20px">
                        <Card h={'500px'}></Card>
                      </Stack>
                      <Stack direction="column" gap="20px">
                        <Card>
                          <SimpleGrid columns={{ base: 1, md: 2 }} gap="20px">
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Skills
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Story Line
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Learning Outcome
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Game Duration
                              </FormLabel>
                              <Switch
                               color="#fff"
                               colorScheme='brandScheme'
                               size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Author Name
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Additional Welcome Note
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                          </SimpleGrid>
                          <SimpleGrid
                            columns={{ base: 1, md: 1 }}
                            gap="20px"
                            mt={'20px'}
                          >
                            <TextField
                              mb="0px"
                              id="Collection"
                              placeholder="eg. Try to understand what went wrong before reacting"
                              label="Additional Welcome Note"
                            />
                          </SimpleGrid>
                        </Card>
                      </Stack>
                    </SimpleGrid>
                    <Flex justify="space-between" mt="24px">
                      <Button
                        variant="light"
                        fontSize="sm"
                        borderRadius="16px"
                        w={{ base: '128px', md: '148px' }}
                        h="46px"
                        onClick={() => takeawayTab.current.click()}
                      >
                        Prev
                      </Button>
                      <Button
                          bg="#3311db"
                          _hover={{ bg: '#3311db' }}
                          color="#fff"
                          w="80px"
                        onClick={() => thankyouTab.current.click()}
                      >
                        Next
                      </Button>
                    </Flex>
                  </Flex>
                </Box>
              </TabPanel>
              <TabPanel w={'100%'} p="0px" mx="auto">
                <Box p="30px">
                  <Text
                    color={textColor}
                    fontSize={'21'}
                    fontWeight="700"
                    mb="20px"
                  >
                    ThankYou Screen
                  </Text>
                  <Flex direction="column" w="100%">
                    <SimpleGrid columns={{ base: 1, md: 2 }} gap="20px">
                      <Stack direction="column" gap="20px">
                        <Card h={'500px'}></Card>
                      </Stack>
                      <Stack direction="column" gap="20px">
                        <Card>
                          <SimpleGrid columns={{ base: 1, md: 1 }} gap="20px">
                            <TextField
                              mb="0px"
                              id="Collection"
                              placeholder="eg. Thank You For Playing"
                              label="Thank You Message"
                            />
                          </SimpleGrid>
                          <SimpleGrid columns={{ base: 1, md: 2 }} gap="20px">
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Collect Learner Feedback
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Question 1
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                            <FormControl
                              display="flex"
                              alignItems="center"
                              justifyContent={'space-between'}
                              mt="20px"
                            >
                              <FormLabel htmlFor="email-" mb="10px" fontSize='sm' fontWeight='bold' color={textColorPrimary}>
                                Make Feedback Mandatory
                              </FormLabel>
                              <Switch
                                color="#fff"
                                colorScheme='brandScheme'
                                size='md'
                                id="gameReplayAllowed"
                                name="gameReplayAllowed"
                                onChange={handleChange}
                              />
                            </FormControl>
                          </SimpleGrid>
                        </Card>
                      </Stack>
                    </SimpleGrid>

                    <Flex justify="space-between" mt="24px">
                      <Button
                        variant="light"
                        fontSize="sm"
                        borderRadius="16px"
                        w={{ base: '128px', md: '148px' }}
                        h="46px"
                        onClick={() => welcomeTab.current.click()}
                      >
                        Prev
                      </Button>
                      <Button
                       bg="#3311db"
                       _hover={{ bg: '#3311db' }}
                       color="#fff"
                       w="80px"

                        
                        onClick={onOpen}
                      >
                        Submit
                      </Button>
                    </Flex>
                  </Flex>
                </Box>
              </TabPanel>
            </TabPanels>
          </Tabs>
          {/* <Box display={{base: 'block', md: 'flex', lg: 'flex'}}>
            <Card width={{sm: '100%', md:'80%', xl:'80%'}} mb={{base: '20px', xl: '20px'}} mr={{base: '0px', md: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                <Text fontSize={22} fontWeight={800} mb={'20px'}>
                  Score
                </Text>
                <SimpleGrid columns={{ base: 1, md: 1, xl: 2 }} spacing={5} mb={{base: '10px', xl: '10px'}}>              
                    <InputField
                        mb="0px"
                        me="30px"
                        id="gameMinScore"
                        label="MinScore"
                        placeholder="eg. 10"
                        name="gameMinScore"                
                        isRequired
                        value={formData?.gameMinScore}
                        onChange={handleChange}                
                    />                            
                    <InputField
                        mb="0px"
                        me="30px"
                        id="gameMaxScore"
                        label="MaxScore"
                        placeholder="eg. 200"
                        name="gameMaxScore"
                        value={formData?.gameMaxScore}
                        onChange={handleChange}                
                    />                                                                   
                </SimpleGrid>
                <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={1}>                                            
                  <InputField
                      mb="0px"
                      me="30px"                
                      id="gameTotalScore"
                      label="TotalScore"
                      placeholder="eg. 1000"
                      name="gameTotalScore"
                      value={formData?.gameTotalScore}
                      onChange={handleChange}                
                  />                             
                </SimpleGrid>
            </Card>
            <Card width={{sm: '100%', md:'20%', xl:'20%'}} mb={{base: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                <Text fontSize={22} fontWeight={500} mb={'20px'}>
                  Course Type
                </Text>
                <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={5} mb={{base: '10px', xl: '10px'}}>              
                  <FormControl>
                    <FormLabel htmlFor="alerts">Course Type</FormLabel>
                    <RadioGroup                 
                      id="alerts"
                    >
                      <Stack direction={{base: "column", xl: 'row'}} spacing={5}>
                        {options.map((option) => (
                          <Radio key={option} value={option} colorScheme="green" name="gameCourseType" onChange={handleChange}>
                            {option}
                          </Radio>
                        ))}
                      </Stack>
                    </RadioGroup>
                  </FormControl>
                </SimpleGrid>            
            </Card>
          </Box>
          <Box display={{base: 'block', md:'block', xl: 'flex'}}>                     
            <Card width={{sm: '100%', md:'100%', xl:'100%'}} mb={{base: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                <Box display={'flex'} justifyContent={'space-between'} alignItems={'center'} mb={'30px'}>
                  <Text fontSize={22} fontWeight={500}>
                    Reflection
                  </Text>
                  <Button
                      bg="#3311db"
                      color="#fff"
                      boxShadow="5px 5px 20px grey"                
                      mr="10px"                  
                      onClick={addReflection}
                    >
                      Add Reflection
                  </Button>
                </Box>
                <SimpleGrid columns={{ base: 1, md: 1, xl: 3 }} spacing={5} mb={{base: '10px', xl: '10px'}}>              
                  {reflection.map((value, index) => (                
                      <Box >
                        <TextField
                          mb="10px"
                          me="30px"
                          id="learningOutcome"                      
                          label={`Reflection Question ${index + 1}`}
                          placeholder="eg. Oliver"                      
                          value={value}                    
                        />                    
                      </Box>                
                  ))}
                </SimpleGrid>            
            </Card>                            
          </Box>  
          <Box display={{base: 'block', md:'block', xl: 'flex'}}>
            <Card width={{sm: '100%', md:'100%', xl:'50%'}} mb={{base: '20px', xl: '20px'}} mr={{base: '0px', md: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                <Text fontSize={22} fontWeight={500} mb={'20px'}>
                  Choose Image
                </Text>
                <SimpleGrid columns={{ base: 3, md: 3, xl: 3 }} spacing={5} mb={{base: '10px', xl: '10px'}}>                                
                    {img &&
                        img.map((img, i) => (
                            <Img
                            key={i}
                              src={img?.gasAssetImage}
                              onClick={() => handleSetBackground(img?.gasId)}
                              w="150px"
                              h="100px"
                              boxShadow={
                                backgroundIndex === i ? '5px 5px 20px grey' : ''
                              }
                              transform={backgroundIndex === i ?'scale(1.10)':''}
                              transition={'0.3s'}
                              borderRadius="8px"                        
                              cursor="pointer"
                            />
                        ))}                    
                </SimpleGrid>            
            </Card>

            <Box display={{base: 'block', md:'flex', xl: 'flex'}} width={{base: '100%', md: '100%', xl: '100%'}}>
              <Card width={{sm: '100%', md:'50%', xl:'50%'}} mb={{base: '20px', xl: '20px'}} mr={{base: '0px', md: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                      <Text fontSize={22} fontWeight={500} mb={'20px'}>
                        Game Audio / Upload
                      </Text>                          
                      <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={5} mb={{base: '10px', xl: '10px'}}>                                                                
                          <SelectField
                            mb="10px"
                            me="30px"
                            id="gameIntroMusic"
                            name="gameIntroMusic"
                            label="Game Intro Music"
                            options={musicOptions}
                            value={
                              musicOptions.find(
                                (option) => option.value === formData?.gameIntroMusic,
                              ) || null
                            }
                            onChange={updateHandleIntroMusic}
                          />    
                          <Box mt={'15px'} display={{base: 'flex', xl: 'flex'}} width={'100%'}>
                            <audio src={'audio'} controls />
                          </Box>                                                           
                      </SimpleGrid> 
                      <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={5}>
                        <input type='file' style={{display:'none', padding: '20px', border: '2px dashed #3311db'}}  ref={inputRef}  onChange={handleFileChange}/>  
                      </SimpleGrid>           
              </Card>
              <Card width={{sm: '100%', md:'50%', xl:'50%'}} mb={{base: '20px', xl: '20px'}} boxShadow={'1px 3px 30px #8080801d'}>
                  <Text fontSize={22} fontWeight={500} mb={'20px'}>
                    Switch On / Off
                  </Text>
                  <SimpleGrid columns={{ base: 1, md: 1, xl: 1 }} spacing={5} mb={{base: '10px', xl: '10px'}}>              
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="25px">
                        <FormLabel htmlFor="email-" mb="0">
                          Replay
                        </FormLabel>
                        <Switch colorScheme="purple" id="gameReplayAllowed" name="gameReplayAllowed" onChange={handleChange}/>
                    </FormControl>  
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="25px">
                      <FormLabel htmlFor="email-alerts" mb="0">
                        LeaderBoard
                      </FormLabel>
                      <Switch colorScheme="purple" id="gameLeaderboardAllowed" name="gameLeaderboardAllowed" onChange={handleChange}/>
                    </FormControl>   
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="25px">
                      <FormLabel htmlFor="email-alerts" mb="0">
                      Allowed Reflection
                      </FormLabel>
                      <Switch colorScheme="purple" id="gameReflectionpageAllowed" name="gameReflectionpageAllowed" onChange={handleChange} />
                    </FormControl>   
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="25px">
                      <FormLabel htmlFor="-alerts" mb="0">
                        FeedBack
                      </FormLabel>
                      <Switch colorScheme="purple" id="gameFeedbackQuestion" name="gameFeedbackQuestion" onChange={handleChange}/>
                    </FormControl>   
                    <FormControl display="flex" alignItems="center" justifyContent={'space-between'} mt="35px">
                      <FormLabel htmlFor="alerts" mb="0">
                        Shuffle
                      </FormLabel>
                      <Switch colorScheme="purple" size='lg' id="gameShuffle" name="gameShuffle" onChange={handleChange} />
                    </FormControl>                                                                                    
                  </SimpleGrid>            
              </Card> 
            </Box>
          </Box>     */}
          <AlertDialog
            motionPreset="slideInBottom"
            leastDestructiveRef={cancelRef}
            onClose={onClose}
            isOpen={isOpen}
            isCentered
          >
            <AlertDialogOverlay />
            <AlertDialogContent>
              <AlertDialogHeader>Add Another Question</AlertDialogHeader>
              <AlertDialogCloseButton />
              <AlertDialogBody>
                Would you like to add another question to this game?
              </AlertDialogBody>
              <AlertDialogFooter display={'flex'} justifyContent={'center'}>
                <Box w={'70%'} display={'flex'} justifyContent={'space-between'}>
                  <Button
                    p={'0px 30px'}
                    ref={cancelRef}
                    bg="#3311db"
                  _hover={{ bg: '#3311db' }}
                  color="#fff"
                  w="80px"
                    onClick={handleAdd}
                  >
                    Yes
                  </Button>
                  <Button
                    p={'0px 30px'}
                    bg="#3311db"
                    _hover={{ bg: '#3311db' }}
                    color="#fff"
                    w="80px"
                    onClick={() => {
                      onClose(); // Close the modal
                    setTab(6)
                      
                    }}
                    ml={3}
                  >
                    No
                  </Button>
                </Box>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
          {openQuest ? (
            <Box className="popup">
              <Flex
                _before={{
                  content: '""',
                  background: '#1b1b1c4a',
                  height: '100%',
                  width: '100%',
                  position: 'fixed',
                  top: '0',
                  left: '0',
                  right: '0',
                }}
              >
                <Card
                  position="fixed"
                  top="50%"
                  left="50%"
                  transform="translate(-50%, -50%)"
                  background="#fff"
                  marginLeft={'90px'}
                  width="500px"
                  display="flex"
                  alignItems="center"
                  boxShadow="1px 2px 17px #42414556"
                  p="20px"
                >
                  <Box w="100%" justifyContent={'center'}>
                    <Text
                      color={textColor}
                      fontSize="2xl"
                      fontWeight="700"
                      mb="20px"
                    >
                      Add Another Quest
                    </Text>
                    <Text color={textColor}>
                      How would you like to create another quest?
                    </Text>
                    <RadioGroup onChange={setValue} value={value} mt={'10px'}>
                      <Stack direction="column" spacing={5}>
                        <Radio value="1">
                          Duplicate existing question entirely
                        </Radio>
                        <Radio value="2">
                          Duplicate existing quest without story
                          <Text fontStyle={'italic'}>
                            {'(Same backgrounds, characters, overview)'}
                          </Text>
                        </Radio>
                        <Radio value="3">Create a new quest from scratch</Radio>
                      </Stack>
                    </RadioGroup>
                  </Box>
                  <Flex justify="end" w="100%" marginTop="15px" p="0 15px">
                    <Button
                      color={'#fff'}
                      bg={'#11047a'}
                      _hover={{ color: '#fff', bg: '#11047a' }}
                      mr={'10px'}
                      onClick={() => {
                        setOpenQuest(false); // Close the quest
                        setTab(6)
                      }}
                    >
                      Cancel
                    </Button>
                    <Button
                      color={'#fff'}
                      bg={'#11047a'}
                      _hover={{ color: '#fff', bg: '#11047a' }}
                    >
                      Add Question?
                    </Button>
                  </Flex>
                </Card>
              </Flex>
            </Box>
          ) : null}
        </Box>
      </>
    );
  };
export default AddScores;
