import React, { ChangeEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react'
import Card from 'components/card/Card';
import TextField from 'components/fields/TextField';
import InputField from 'components/fields/InputField';
import SelectField from 'components/fields/SelectField';
import {    
    Box,
    Text,
    Flex,
    Button,
    Icon,
    List,
    ListItem,
    Img,
  } from '@chakra-ui/react'
import { MdAdd, MdDelete } from 'react-icons/md';
import OnToast from 'components/alerts/toast';
import { Draggable } from 'react-beautiful-dnd';
import CustomAccordion from './dragNdrop/CustomAccordion';
import NoteCompo from '../blocksCompo/NoteCompo';
import DialogCompo from '../blocksCompo/DialogCompo';
import InteractionCompo from '../blocksCompo/InteractionCompo';
  

interface NDIMainProps {
    handleShowComponent?: (componentName: string) => void;
}




const NDIMain: React.FC<NDIMainProps> = () => {
    const updatedSeqRef = useRef([]);
    const [showBox, setShowBox] = useState(false),
    [alert, setAlert] = useState(false),
    [type, setType] = useState<any>(),
    [count, setCount] = useState<any>(1),
    [upNextCount, setUpNextCount] = useState<any>([]),
    [upNext, setUpNext] = useState<any>(),
    [blockInput, setBlockInput] = useState<any>(),
    [sequence, setSequence] = useState<any>([]),    
    [dummySequence, setDummySequence] = useState<any>([]),      
    [animateBtn, setAnimateBtn] = useState<any>(),
    [input, setInput] = useState<any>({}),
    [items, setItems] = useState<any>([]),
    [notify, setNotify] = useState<any>(''),
    [interactionBlock, setInteractionBlock] = useState<any>();
    
        
    
    // For Dialog Options
    const characterOption = [
        {value: 'player', label: 'Player'},
        {value: 'NPC Name', label: 'NPC_Name'},
        {value: 'narrator', label: 'Narrator'},
    ]


    // onClick Function
    const handleNDI = (NDI: any) => {
        const id = `${Math.floor(count / 10) + 1}.${count % 10 || 1}`;
        const upNext = `${Math.floor(count / 10) + 1}.${(count + 1) % 10 || 1}`;
        setUpNext(upNext);        
        setType(NDI);
        setShowBox(false);
        setItems((prevItems:any) => [
          ...prevItems,
          {
            id,
            type: NDI,
            upNext,
            input: count
          },
        ]);
        setSequence([...sequence, id]);    
        setDummySequence([...dummySequence, id]);          
        setUpNextCount([...upNextCount, upNext])
        setCount(count + 1);
    };
  
    const delSeq = (seq: any, i: any, name: any) => {       
        setItems(items.filter((_:any, index: any)=> {            
            return index !== i;
        }));       
       setSequence(sequence.filter((_:any, index: any)=> {return index !== i }))        
    };
    const getSeq = (seq: any, i: any, name: any) => {
        const id = `${Math.floor(count / 10) + 1}.${count % 10 || 1}`;
        const upNext = `${Math.floor(count / 10) + 1}.${(count + 1) % 10 || 1}`;
        setUpNext(upNext);
        const newArr = { id, type: name, upNext, input: count };
    
        setItems((prevArray: any) => {
          const nextIndex = i + 1;
          return [
            ...prevArray.slice(0, nextIndex),
            newArr,
            ...prevArray.slice(nextIndex).map((item:any) => ({ ...item, upNext: id, input: count })),
          ];
        });
    
        setCount(count + 1);
        setSequence([...sequence, id]);  
        setDummySequence([...dummySequence, id]);  
        setUpNextCount([...upNextCount, upNext])  
    };
    
    const handleSubmit = (e: any) => {
        e.preventDefault();                
        const id = `${Math.floor(count / 10) + 1}.${count % 10 || 1}`;
        const upNext = `${Math.floor(count / 10) + 1}.${(count + 1) % 10 || 1}`;                
        if(blockInput === 'N') {
            setType('Note') 
            setCount(count + 1);     
            setUpNext(upNext);                               
            setSequence([...sequence, id]);    
            setUpNextCount([...upNextCount, upNext])      
            setItems((prevItems:any) => [
                ...prevItems,
                {         
                  id,        
                  type: 'Note',   
                  upNext,
                  input: count          
                },
              ]);            
        }
        else if(blockInput === 'D') {
            setType('Dialog')
            setCount(count + 1);
            setUpNext(upNext);                               
            setSequence([...sequence, id]);    
            setUpNextCount([...upNextCount, upNext])
            setItems((prevItems:any) => [
                ...prevItems,
                {         
                  id,        
                  type: 'Dialog',   
                  upNext,               
                  input: count
                },
              ]);            
        }
        else if(blockInput === 'I') {
            setType('Interaction')
            setCount(count + 1);
            setUpNext(upNext);                               
            setSequence([...sequence, id]);    
            setUpNextCount([...upNextCount, upNext])
            setItems((prevItems:any) => [
                ...prevItems,
                {         
                  id,        
                  type: 'Interaction',   
                  upNext,
                  input: count               
                },
              ]);
        }
        else {
            return '';
        }

        setBlockInput('');
        setNotify('')    
    }
    

    // onChange Function
    const handleInput = (e: any, i?: any) => {                    
        setInput((prevInput: any)=> {    
            const noteKey = `Note${items[i]?.input}`;       
            const dialogKey = `Dialog${items[i]?.input}`;       
            const interactionKey = `Interaction${items[i]?.input}`;                           
            
            if(e.target.name == noteKey) {
                const note = e.target.id === 'Note' ?  e.target.value : prevInput[noteKey]?.note ;                
                return {
                    ...prevInput,
                    [noteKey] : {
                        ...prevInput[noteKey],
                        id: items[i]?.id, 
                        note: note ,                         
                    }
                }
            } 
            if(e.target.name == dialogKey) {
                const dialog = e.target.id === 'Dialog' ?  e.target.value : prevInput[dialogKey]?.dialog ;                
                return {
                    ...prevInput,
                    [dialogKey] : {
                        ...prevInput[dialogKey],
                        id: items[i]?.id, 
                        dialog: dialog ,                         
                    }
                }
            } 
            if(e.target.name == interactionKey) {
                const interaction = e.target.id === 'interaction' ?  e.target.value : prevInput[interactionKey]?.interaction ;
                const responseValue =  e.target.id === 'Resp' ? e.target.value : prevInput[interactionKey]?.[`Resp${items[i]?.input}`];
                const feedbackValue =  e.target.id === 'FeedBk' ? e.target.value : prevInput[interactionKey]?.[`FeedBk${items[i]?.input}`];
                return {
                    ...prevInput,
                    [interactionKey] : {
                        ...prevInput[interactionKey],
                        id: items[i]?.id, 
                        interaction: interaction , 
                        [`Resp${items[i]?.input}`]: responseValue , 
                        [`FeedBk${items[i]?.input}`]: feedbackValue , 
                    }
                }
            }       
                                   
            // return {    
            //     ...prevInput,
            //     [e.target.name]: e.target.value,                               
            // }        
        })
    }     
    const handleSelect = ( selectedOption: any, e:any) => {
        const value = selectedOption ? selectedOption : '';             
        setInput((prevInput: any)=> {
            return {
                ...prevInput,
               [e.name]: value
            }
        })
    }
    const handleFieldBlock = (e: ChangeEvent<HTMLInputElement>) => {        
        const getValue = e.target.value
        setBlockInput(e.target.value);
        if(getValue === '/') {
            setShowBox(true);
        }
        else {
            setShowBox(false);
        }

        const keyword = 'Press Enter Button on your Keyboard';
        if(getValue === 'N' || getValue === 'D' || getValue === 'I') {
            setNotify(keyword)            
        }
        else {
            setNotify('')            
        }                  
    }


    // Items will change based on sequence state
    useEffect(()=> {  
        const updatedSeq = sequence.map((item:any, index: number)=> (                       
            dummySequence[index] || item.id
        ))                        

        const updatedItems = items.map((item:any, index: number)=> ({                       
            ...item, id: updatedSeq[index] || item.id, upNext: upNextCount[index]
        }))     
        // dummySequence(updatedSeq)
        console.log('updatedSeq',updatedSeq);
        setItems(updatedItems);       
    },[sequence, dummySequence])

   
    // Console's
    console.log('items', items);                                   
    console.log('input', input);                     
  return (
    <>        
        <Box mt={{ base: '0px', xl: '0px' }} className='NDI' position={'relative'}>
            <Card mb={'20px'}>                
                <Text fontSize={22} fontWeight={800} mb={'20px'}>Story</Text>                  
                <Box className='sequence-lists' mt={'40px'} w={'100%'}>
                    <CustomAccordion items={items} setItems={setItems} sequence={sequence} upNextCount={upNextCount}>
                        {type && items.map((seq:any, i:number)=>{   
                            console.log();                                                     
                            return (   
                                <Draggable key={seq.id} draggableId={seq.id} index={i}>
                                {(provided) => (
                                    <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}                   
                                    >                   
                                        <Box key={i}>
                                            {seq.type == 'Note' ? 
                                                (<NoteCompo 
                                                    seq={seq} 
                                                    index={i} 
                                                    name={'Note'} 
                                                    getSeq={getSeq} 
                                                    delSeq={delSeq} 
                                                    input={input}                                                                                                       
                                                    handleInput={(e:any)=>handleInput(e, i)} />
                                                ) : 
                                            seq.type == 'Dialog' ? 
                                                (<DialogCompo 
                                                    seq={seq} 
                                                    index={i} 
                                                    name={'Dialog'} 
                                                    getSeq={getSeq}
                                                    delSeq={delSeq}
                                                    input={input}
                                                    handleInput={(e:any)=>handleInput(e, i)}
                                                    handleSelect={handleSelect} 
                                                    characterOption={characterOption}
                                                    animateBtn={animateBtn}
                                                    setAnimateBtn={setAnimateBtn} />
                                                ) : 
                                            seq.type == 'Interaction' ? 
                                                (<InteractionCompo                                                                                                                 
                                                    seq={seq} 
                                                    index={i} 
                                                    name={'Interaction'} 
                                                    getSeq={getSeq}
                                                    delSeq={delSeq}
                                                    input={input}
                                                    handleInput={(e:any)=>handleInput(e, i)}
                                                    handleSelect={handleSelect} 
                                                    characterOption={characterOption}
                                                    animateBtn={animateBtn}
                                                    setAnimateBtn={setAnimateBtn}
                                                    interactionBlock={interactionBlock}
                                                    setInteractionBlock={setInteractionBlock}
                                                    />) : 
                                            null } 
                                        </Box>                  
                                    </div>
                                )}
                                </Draggable>                                                       
                            )
                        })}
                    </CustomAccordion>  
                    <Box display={'flex'} alignItems={'start'}>
                        <Flex justify={'start'} mb={'20px'} position={'relative'}>                                        
                            <Button bg={'#3311db'} _hover={{bg: '#3311db'}} color={'#fff'} mr={'10px'} className='showFormBox' onClick={()=> setShowBox(!showBox)}>
                                <Icon as={MdAdd}  />
                            </Button> 
                            { showBox  ? 
                                <Box position={'absolute'} background={'#fff'} p={'10px'} top={'55px'} left={'0px'} boxShadow={'1px 1px 17px #69627914'} borderRadius={'8px'} zIndex={9} className='showBox'>
                                    <List cursor={'pointer'}>
                                        <ListItem onClick={()=>handleNDI('Note')} p={'10px'}>Note</ListItem> 
                                        <ListItem onClick={()=>handleNDI('Dialog')}  p={'10px'}>Dialog</ListItem> 
                                        <ListItem onClick={()=>handleNDI('Interaction')}  p={'10px'}>Interaction</ListItem> 
                                    </List>
                                </Box>   : null }                   
                        </Flex>
                        <Box className='up-next-count' mr={'10px'}>{upNext}</Box>
                        <Box mr={'10px'} display={'flex'}>
                            <form onSubmit={(e:any)=>handleSubmit(e)}>
                                <Box display={'flex'}>
                                    <InputField onChange={(e: any)=>handleFieldBlock(e)} value={blockInput} placeholder='Type "/" to insert Blocks' />
                                    <Text color={'#bcbcbc'}>{notify}</Text>
                                </Box>
                            </form>
                        </Box>
                    </Box>
                </Box>                
            </Card>
        </Box>                

        <OnToast msg={'Drag Your Accordion'} status={'info'} setAlert={setAlert} position={'top-right'} />
    </>
  )
}




export default NDIMain;