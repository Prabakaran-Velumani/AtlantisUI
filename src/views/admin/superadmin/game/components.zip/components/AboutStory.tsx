import { Box, Button, FormControl, FormLabel, Grid, GridItem, Icon, Img, SimpleGrid, Text, useColorModeValue } from "@chakra-ui/react"
import InputField from "components/fields/InputField"
import TextField from "components/fields/TextField"
import React, { useState } from "react"
import Card from 'components/card/Card'
import TagsField from "components/fields/TagsField"
import { MdAdd, MdAddCircle } from "react-icons/md"
import AddCourse from "./AddCourse"
import narrator from 'assets/img/games/meeting_room.png';
import back from 'assets/img/games/narrator.png';
 

const AboutStory : React.FC<{handleChange:(e:any)=>void,formData:any}>= ({handleChange,formData}) => {
  const [openCourse,setOpenCourse] = useState(false),
        [skills,setSkills] = useState([]);
     
  const iconColor = useColorModeValue('brand.500', 'white');
  const bgButton = useColorModeValue('secondaryGray.300', 'whiteAlpha.100');
  const textColorPrimary = useColorModeValue('secondaryGray.900', 'white');
  const bgHover = useColorModeValue(
    { bg: 'secondaryGray.400' },
    { bg: 'whiteAlpha.50' },
  );
  const bgFocus = useColorModeValue(
    { bg: 'secondaryGray.400' },
    { bg: 'whiteAlpha.100' },
  );
   let previousLength = 0;
  const handleInput = (event:any) => {
    const bullet = "\u2022";
    const newLength = event.target.value.length;
    const characterCode = event.target.value.substr(-1).charCodeAt(0);
  
    if (newLength > previousLength) {
      if (characterCode === 10) {
        event.target.value = `${event.target.value}${bullet} `;
      } else if (newLength === 1) {
        event.target.value = `${bullet} ${event.target.value}`;
      }
    }
    previousLength = newLength;
  }
   console.log('skills :',skills);
    return (
      <>
        <Card mb={{ base: '0px', xl: '20px', sm: '20px' }}>
          <Text fontSize={20} fontWeight={800} mb={'20px'}>
            Game Overview
          </Text>
          <Box>
            {/* <Grid
              templateColumns={{ sm: 'repeat(1, 1fr)', md: 'repeat(2, 1fr)' }}
              templateRows="repeat(4, 1fr)"
              gap={2}
            > */}
              <SimpleGrid columns={{base:1,md:1}} >

                <InputField
                  mb="0px"
                  // mt={'20px'}
                  me="30px"
                  id="title"
                  label="Title"
                  placeholder="eg. Oliver"
                  name="gameTitle"
                  value={formData?.gameTitle}
                  onChange={handleChange}
                  isRequired
                />
              </SimpleGrid>
              {/* <GridItem rowSpan={1} colSpan={2}>
              </GridItem> */}
                <SimpleGrid columns={{base:1,md:2}} gap={6}  mt={'20px'}>

              {/* <GridItem rowSpan={1} colSpan={1}> */}
                <TextField
                  me="30px"
                  mb="0px"
                  id="storyline"
                  label="Story Line"
                  placeholder="eg. Fight Me"
                  name="gameStoryLine"
                  value={formData?.gameStoryLine}
                  onChange={handleChange}
                  isRequired
                />
              {/* </GridItem> */}
              {/* <GridItem rowSpan={1} colSpan={1}> */}
                <TextField
                  mb="0px"
                  me="30px"
                  id="learningOutcome"
                  label="Learning Outcome"
                  placeholder="eg. Oliver"
                  name="gameLearningOutcome"
                  onChange={handleInput}
                />
             {/* /</SimpleGrid> </GridItem> */}
              {/* <GridItem rowSpan={1} colSpan={1}> */}
                <Box>
                  <FormControl>
                    <Box
                      width={'100%'}
                      justifyContent={'space-between'}
                      display={'flex'}
                    >
                      <FormLabel
                        ms="10px"
                        fontSize="sm"
                        fontWeight={'bold'}
                        color={textColorPrimary}
                      >
                        Category<span style={{ color: 'red' }}>*</span>
                      </FormLabel>
                    
                      <Icon
                        onClick={() => setOpenCourse(true)}
                        as={MdAddCircle}
                        color={iconColor}
                        cursor={'pointer'}
                        w="20px"
                        h="20px"
                      />
                    </Box>
                    <Box border={'1px solid #e0e5f2'} borderRadius={'15px'}  h="80px" overflow={'auto'}>
                    <TagsField                      
                      id="description"                  
                      border={'none'}
                      mb="0px"
                      placeholderTags={[
                        {
                          name: 'War',
                          id: 1,
                        },
                      ]}
                    />
                    </Box>                   
                  </FormControl>
                </Box>
              {/* </GridItem> */}
              {/* <GridItem rowSpan={1} colSpan={1}> */}
                <FormControl>
                  <FormLabel
                    ms="10px"
                    fontSize="sm"
                    fontWeight={'bold'}
                    color={textColorPrimary}
                    
                  >
                    Skills<span style={{ color: 'red' }}>*</span>
                  </FormLabel>
                  <Box border={'1px solid #e0e5f2'} borderRadius={'15px'}  h="80px" overflow={'auto'}>
                    <TagsField
                      setValue={setSkills}
                      id="description"
                      border={'none'}
                      mb="0px"
                      placeholderTags={[
                        {
                          name: 'sleeping',
                          id: 1,
                        },
                      ]}
                    />
                  </Box>
                </FormControl>
              {/* </GridItem> */}
                </SimpleGrid>
                <SimpleGrid columns={{base:1,md:1}}  mt={'20px'}>  
              {/* <GridItem rowSpan={1} colSpan={2}> */}
                <InputField
                  mb="0px"
                  me="30px"
                  id="author"
                  label="Author"
                  placeholder="eg. Admin"
                  name="gameAuthorName"
                  value={formData?.gameAuthorName}
                  onChange={handleChange}
                />
                </SimpleGrid>
              {/* </GridItem> */}
            {/* </Grid> */}
          </Box>
        </Card>
        {openCourse ? <AddCourse setOpenCourse={setOpenCourse} /> : null}
      </>
    );
}
export default AboutStory;