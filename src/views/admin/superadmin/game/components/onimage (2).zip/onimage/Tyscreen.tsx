import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogCloseButton,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  Box,
  Button,
  Flex,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  HStack,
  Icon,
  Img,
  Radio,
  RadioGroup,
  SimpleGrid,
  Stack,
  Switch,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  useColorModeValue,
  useDisclosure,
  useTheme,
  useToast,
  // brindha start
  Select,
  Textarea,
  Link,
  Slider,
  Image,
  IconButton,
  Center,
  // brindha end
} from '@chakra-ui/react';
import React, { useEffect, useRef, useState } from 'react';
import {
  gameDuplicateQuestionEntirely,
  getImages,
  updateGame,
} from 'utils/game/gameService';
import Card from 'components/card/Card';
import InputField from 'components/fields/InputField';
import BadgeImages from '../BadgeImages';
import { MdClose, MdOutlineCloudUpload } from 'react-icons/md';
import { ImHappy   } from "react-icons/im";
import { TfiFaceSad } from "react-icons/tfi";
import { BsEmojiSunglasses } from "react-icons/bs";
import { FaRegFaceMehBlank } from "react-icons/fa6";
import { IoIosThumbsUp } from "react-icons/io";
import { IoIosThumbsDown } from "react-icons/io";
import { BsQuestionSquare } from "react-icons/bs";
import { BsEmojiNeutral } from "react-icons/bs";
import { RiEmotionHappyLine } from "react-icons/ri";
import { FaRegTired } from "react-icons/fa";
import { FaComment } from "react-icons/fa";

import TextField from 'components/fields/TextField';
interface Badge {
  gasId: number;
  gasAssetImage: string;
  gasAssetName: string;
}

const TyScreen: React.FC<{ formData: any; imageSrc: any }> = ({
  formData,
  imageSrc,
}) => {
  return (
    <>
      {imageSrc && (
        <Box className='thankyou-screen'>
          <Box className='thankyou-screen-box'>       
            <Img src={imageSrc} className='bg-img' />          
          </Box>
          <Box
            w={'100%'}
            fontFamily={'content'}
            display={'flex'}
            justifyContent={'center'}
            alignItems={'center'}
            className='tq-msg'
          >
            <Box
              h={'100px'}
              w={'80%'}
              mt={{ base: '0px', sm: '0px', md: '20px', lg: '20px' }}
              lineHeight={1}
              textAlign={'center'}
              color="#D9C7A2"
            >
              {formData.gameThankYouMessage}
            </Box>
          </Box>

          {formData.gameIsCollectLearnerFeedback === 'true' && (
            <>
            <Text className='about-experience' fontSize={18} fontWeight="bold" textAlign="center">              
              How do you feel about the experience?
            </Text>
              <Box className='collect-learner-feedback'>   
                <Box className='grid'>                 
                    {formData.gameContent === 'true' && (
                    <div className='content-box'>
                      <Text fontSize={18} fontWeight="bold" textAlign="center">
                        Content
                      </Text>
                      <div className='content-div' style={{ display: 'flex', justifyContent: 'space-between' }}>
                        <div>
                          <Icon as={ImHappy  } />
                          <p>I learned something useful</p>
                        </div>
                        <div>
                        <Icon as={TfiFaceSad   } />
                          <p>It wasn't useful</p>
                        </div>
                      </div>
                    </div>
                    )}
                    {formData.gameBehaviour === 'true' && (
                      <div className='content-box'>
                        <Text fontSize={18} fontWeight="bold" textAlign="center">
                          Behaviour

                        </Text>
                        <div className='content-div' style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div>
                          <Icon as={BsEmojiSunglasses   } />
                            <p>I understood what I can do differentl</p>
                          </div>
                          <div>
                          <Icon as={FaRegFaceMehBlank   } />
                            <p>I am not sure

                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                    {formData.gameGamification === 'true' && (
                      <div className='content-box'>
                        <Text fontSize={18} fontWeight="bold" textAlign="center">
                          Gamification

                        </Text>
                        <div className='content-div' style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div>
                          <Icon as={IoIosThumbsUp   } />
                            <p>I would like to learn via games</p>
                          </div>
                          <div>
                          <Icon as={IoIosThumbsDown   } />
                            <p>I don't like this format</p>
                          </div>
                        </div>
                      </div>
                    )}
                    {formData.gameRelevance === 'true' && (
                      <div className='content-box'>
                        <Text fontSize={18} fontWeight="bold" textAlign="center">
                          Relevance
                        </Text>
                        <div className='content-div' style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div>
                          <Icon as={BsQuestionSquare   } />
                            <p>I'll apply what I learned
                            </p>
                          </div>
                          <div>
                          <Icon as={BsEmojiNeutral   } />
                            <p>It's not relevant to me
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                    {formData.gameRecommendation === 'true' && (
                      <div className='content-box'>
                        <Text fontSize={18} fontWeight="bold" textAlign="center">
                          Recommendation
                        </Text>
                        <div className='content-div' style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div>
                          <Icon as={RiEmotionHappyLine   } />
                            <p>I would recommend this game to others
                            </p>
                          </div>
                          <div>
                          <Icon as={FaRegTired    } />
                            <p>I wouldn't recommend
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                    {formData.gameOthers === 'true' && (
                      <div className='content-box last'>
                        <Text fontSize={18} fontWeight="bold" textAlign="center">
                        <Icon as={FaComment     } />
                          Anything else you'd like to share

                        </Text>
                        <div className='content-div' style={{ display: 'flex', justifyContent: 'space-between' }}>
                          <div>
                            <p>
                            </p>
                          </div>
                          <div>
                            <p>
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                    {formData.gameFeedBack === 'true' && ( 
                      <>  
                      <Box display={'flex'} justifyContent={'center'} width={'200%'} textAlign={'center'}>                   
                        <div className='content-box' >
                          <p>Could you please share your feedback with us on the below link:
                          </p>
                          <p>www.forms.google.com
                          </p>
                        </div>   
                        </Box>  
                      </>                 
                    )}                  
                </Box>
              </Box>
            </>
          )}
        </Box>
      )}
    </>
 

  );
};
export default TyScreen;
